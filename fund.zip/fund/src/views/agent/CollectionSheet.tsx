import React, { useEffect, useState, useCallback } from 'react';
import { Receipt, Download, Phone, AlertCircle, Banknote, CheckCircle2 } from 'lucide-react';
import type { AgentReceipt, PayableCustomer } from '../../types/agent';
import { agentApi, AGENT_ID, formatAmount, formatDate, downloadCollectionSheetCsv } from '../../services/agentApi';
import { toLocalDateStr } from './agentDateHelpers';
import { CollectionFilters } from './CollectionFilters';
import { CollectPaymentModal } from './CollectPaymentModal';
import { AgentReceiptModal } from './AgentReceiptModal';
import { AgentStatusBadge } from './AgentStatusBadge';
import type { AgentCollectionFilters, CollectionSheetItem } from '../../types/agent';

interface CollectionSheetProps {
  agentName: string;
  onNotify: (message: string, type?: 'success' | 'error' | 'info') => void;
}

function defaultFilters(): AgentCollectionFilters {
  return {
    dateType: 'today',
    customDate: '',
    status: 'all',
    search: ''
  };
}

function toPayableCustomer(item: CollectionSheetItem): PayableCustomer {
  return {
    customerId: item.customerId,
    customerName: item.customerName,
    phone: item.phone,
    chitGroupCode: item.chitGroupCode,
    ticketNumber: item.ticketNumber,
    dueDate: item.dueDate,
    dueAmount: item.dueInstallmentAmount,
    outstandingBalance: item.pendingBalance
  };
}

export const CollectionSheet: React.FC<CollectionSheetProps> = ({ agentName, onNotify }) => {
  const [filters, setFilters] = useState<AgentCollectionFilters>(defaultFilters);
  const [items, setItems] = useState<CollectionSheetItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [exported, setExported] = useState(false);
  const [paymentTarget, setPaymentTarget] = useState<PayableCustomer | null>(null);
  const [receipt, setReceipt] = useState<AgentReceipt | null>(null);

  const safeItems = Array.isArray(items) ? items : [];

  const loadData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const sheet = await agentApi.getAgentCollectionSheet(AGENT_ID, filters);
      setItems(Array.isArray(sheet) ? sheet : []);
    } catch (err: any) {
      setError(err.message || 'Unable to load collection data. Please try again.');
      setItems([]);
    } finally {
      setLoading(false);
    }
  }, [filters]);

  useEffect(() => {
    const timer = setTimeout(() => {
      loadData();
    }, filters.search ? 400 : 0);
    return () => clearTimeout(timer);
  }, [filters, loadData]);

  const handleExportCSV = () => {
    if (!safeItems.length) {
      onNotify('No records to export.', 'error');
      return;
    }
    downloadCollectionSheetCsv(safeItems);
    setExported(true);
    window.setTimeout(() => setExported(false), 3000);
    onNotify('Collection sheet exported successfully.');
  };

  const handlePaymentSuccess = (result: { payment: unknown; receipt: AgentReceipt }) => {
    setReceipt(result.receipt);
    setPaymentTarget(null);
    onNotify('Payment collected successfully.');
    loadData();
  };

  const viewLabel =
    filters.dateType === 'custom' && filters.customDate
      ? formatDate(filters.customDate)
      : formatDate(toLocalDateStr(new Date()));

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900 flex items-center gap-2">
            <Receipt className="w-6 h-6 text-emerald-600" />
            Collection Sheet
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Field collection desk for <span className="font-semibold text-slate-700">{agentName}</span>{' '}
            &middot; {viewLabel}
          </p>
        </div>
        <button
          onClick={handleExportCSV}
          disabled={loading || safeItems.length === 0}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white hover:bg-slate-50 border border-slate-300 text-slate-700 text-xs font-semibold rounded-lg shadow-xs transition disabled:opacity-60"
        >
          {exported ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          ) : (
            <Download className="w-4 h-4" />
          )}
          {exported ? 'Exported' : 'Download Collection Sheet'}
        </button>
      </div>

      <CollectionFilters filters={filters} onChange={setFilters} />

      {/* Sheet table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="px-4 sm:px-5 py-3 border-b border-slate-200 flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-900">
            Daily Entries <span className="ml-1 text-[11px] font-medium text-slate-400">({safeItems.length} records)</span>
          </h3>
          <span className="text-[11px] text-slate-400 hidden sm:block">Tap Collect to record a payment</span>
        </div>

        {loading ? (
          <div className="p-8 flex items-center justify-center">
            <div className="text-center space-y-3">
              <div className="w-8 h-8 border-2 border-amber-600 border-t-transparent rounded-full animate-spin mx-auto" />
              <p className="text-xs text-slate-500 font-medium">Loading collection data...</p>
            </div>
          </div>
        ) : error ? (
          <div className="p-6">
            <div className="bg-rose-50 border border-rose-200 text-rose-800 p-4 rounded-xl text-sm flex items-center justify-between gap-4">
              <span className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
                {error}
              </span>
              <button onClick={() => loadData()} className="text-xs font-bold underline ml-4 shrink-0">
                Retry
              </button>
            </div>
          </div>
        ) : safeItems.length === 0 ? (
          <div className="p-10 text-center">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-slate-100 flex items-center justify-center mb-3">
              <Receipt className="w-6 h-6 text-slate-400" />
            </div>
            <p className="text-sm font-semibold text-slate-700">No collection records found.</p>
            <p className="text-xs text-slate-400 mt-1">Try changing the date, status or search filter.</p>
          </div>
        ) : (
          <>
            {/* Desktop table */}
            <div className="hidden lg:block overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/80 text-slate-500 text-[11px] uppercase tracking-wider">
                    <th className="py-2.5 px-4">Customer</th>
                    <th className="py-2.5 px-3">Group / Ticket</th>
                    <th className="py-2.5 px-3">Due Date</th>
                    <th className="py-2.5 px-3 text-right">Due Installment</th>
                    <th className="py-2.5 px-3 text-right">Paid</th>
                    <th className="py-2.5 px-3 text-right">Balance</th>
                    <th className="py-2.5 px-3">Status</th>
                    <th className="py-2.5 px-4 text-right">Quick Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {safeItems.map((item) => (
                    <tr key={item.id} className="hover:bg-slate-50/60 transition">
                      <td className="py-3 px-4">
                        <p className="font-semibold text-slate-900">{item.customerName}</p>
                        <p className="text-[11px] text-slate-400 font-mono flex items-center gap-1">
                          <Phone className="w-3 h-3" />
                          {item.phone}
                        </p>
                      </td>
                      <td className="py-3 px-3">
                        <p className="font-mono text-slate-700">{item.chitGroupCode}</p>
                        <p className="text-[11px] text-amber-800 font-semibold">Ticket #{item.ticketNumber}</p>
                      </td>
                      <td className="py-3 px-3 text-slate-600">{formatDate(item.dueDate)}</td>
                      <td className="py-3 px-3 text-right font-semibold text-slate-900">{formatAmount(item.dueInstallmentAmount)}</td>
                      <td className="py-3 px-3 text-right text-emerald-700 font-medium">{formatAmount(item.paidAmount)}</td>
                      <td className={`py-3 px-3 text-right font-semibold ${item.pendingBalance > 0 ? 'text-rose-700' : 'text-slate-400'}`}>
                        {formatAmount(item.pendingBalance)}
                      </td>
                      <td className="py-3 px-3">
                        <AgentStatusBadge status={item.status} />
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={() => setPaymentTarget(toPayableCustomer(item))}
                          disabled={item.status === 'paid'}
                          className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                            item.status === 'paid'
                              ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                              : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs'
                          }`}
                        >
                          <Banknote className="w-3.5 h-3.5" />
                          Collect Payment
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile / tablet cards */}
            <div className="lg:hidden divide-y divide-slate-100">
              {safeItems.map((item) => (
                <div key={item.id} className="p-4 space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="text-sm font-bold text-slate-900 truncate">{item.customerName}</p>
                      <p className="text-[11px] text-slate-400 font-mono">{item.phone}</p>
                    </div>
                    <AgentStatusBadge status={item.status} />
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-[11px]">
                    <div>
                      <span className="text-slate-400 block">Group / Ticket</span>
                      <span className="font-mono text-slate-700">{item.chitGroupCode} <span className="text-amber-800">#{item.ticketNumber}</span></span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Due Date</span>
                      <span className="text-slate-700">{formatDate(item.dueDate)}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Balance</span>
                      <span className={`font-semibold ${item.pendingBalance > 0 ? 'text-rose-700' : 'text-slate-400'}`}>
                        {formatAmount(item.pendingBalance)}
                      </span>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-[11px]">
                    <div className="bg-slate-50 rounded-lg p-2 border border-slate-100">
                      <span className="text-slate-400 block">Due Installment</span>
                      <span className="font-semibold text-slate-800">{formatAmount(item.dueInstallmentAmount)}</span>
                    </div>
                    <div className="bg-slate-50 rounded-lg p-2 border border-slate-100">
                      <span className="text-slate-400 block">Paid</span>
                      <span className="font-semibold text-emerald-700">{formatAmount(item.paidAmount)}</span>
                    </div>
                  </div>
                  <button
                    onClick={() => setPaymentTarget(toPayableCustomer(item))}
                    disabled={item.status === 'paid'}
                    className={`w-full flex items-center justify-center gap-1.5 py-2.5 rounded-lg text-xs font-semibold transition min-h-[44px] ${
                      item.status === 'paid'
                        ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                        : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs'
                    }`}
                  >
                    <Banknote className="w-4 h-4" />
                    {item.status === 'paid' ? 'Already Collected' : 'Collect Payment'}
                  </button>
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Payment modal */}
      {paymentTarget && (
        <CollectPaymentModal
          item={paymentTarget}
          onClose={() => setPaymentTarget(null)}
          onSubmit={(input) => agentApi.collectAgentPayment(input)}
          onSuccess={handlePaymentSuccess}
        />
      )}

      {/* Receipt modal */}
      {receipt && <AgentReceiptModal receipt={receipt} onClose={() => setReceipt(null)} />}
    </div>
  );
};