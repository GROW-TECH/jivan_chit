import React from 'react';
import { X, Printer, CheckCircle2, Building2 } from 'lucide-react';
import type { PaymentReceipt } from '../types';

interface PaymentReceiptModalProps {
  receipt: PaymentReceipt | null;
  onClose: () => void;
}

export const PaymentReceiptModal: React.FC<PaymentReceiptModalProps> = ({ receipt, onClose }) => {
  if (!receipt) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div id="receipt-modal-backdrop" className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
      <div className="relative w-full max-w-xl bg-white rounded-xl shadow-2xl overflow-hidden border border-slate-200 my-auto max-h-[92vh] flex flex-col">
        {/* Modal Actions Header (Hidden on Print) */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-3 bg-slate-50 border-b border-slate-200 print:hidden shrink-0">
          <div className="flex items-center gap-2 text-emerald-700 font-medium text-xs sm:text-sm min-w-0">
            <CheckCircle2 className="w-4 h-4 sm:w-5 sm:h-5 text-emerald-600 shrink-0" />
            <span className="truncate">Payment Recorded</span>
          </div>
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            <button
              id="print-receipt-btn"
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition shadow-xs min-h-[36px]"
            >
              <Printer className="w-3.5 h-3.5 text-slate-500" />
              <span>Print</span>
            </button>
            <button
              id="close-receipt-btn"
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition min-h-[36px] min-w-[36px] flex items-center justify-center"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Receipt Body */}
        <div id="printable-receipt" className="p-4 sm:p-8 bg-white text-slate-800 space-y-5 overflow-y-auto flex-1">
          {/* Header */}
          <div className="text-center border-b border-slate-200 pb-4">
            <div className="flex items-center justify-center gap-2 mb-1">
              <Building2 className="w-5 h-5 text-amber-700" />
              <h2 className="text-lg sm:text-xl font-bold tracking-tight text-slate-900">{receipt.companyName}</h2>
            </div>
            <p className="text-[11px] sm:text-xs text-slate-500 max-w-md mx-auto leading-relaxed">{receipt.companyAddress}</p>
            <div className="flex items-center justify-center gap-3 text-[11px] text-slate-500 mt-1 font-mono">
              <span>Ph: {receipt.companyPhone}</span>
              <span>•</span>
              <span>Email: {receipt.companyEmail}</span>
            </div>
            <div className="mt-2.5 inline-block bg-amber-50 text-amber-900 border border-amber-200 px-2.5 py-0.5 rounded text-[11px] font-semibold uppercase tracking-wider">
              Official Chit Installment Receipt
            </div>
          </div>

          {/* Receipt Meta Bar */}
          <div className="grid grid-cols-2 gap-3 bg-slate-50 p-3 rounded-lg border border-slate-200/80 text-xs">
            <div>
              <span className="text-slate-500 block text-[11px]">Receipt Number</span>
              <span className="font-bold text-slate-900 font-mono text-xs sm:text-sm">{receipt.receiptNumber}</span>
            </div>
            <div className="text-right">
              <span className="text-slate-500 block text-[11px]">Date & Time</span>
              <span className="font-medium text-slate-900 text-xs">{receipt.paymentDate}</span>
            </div>
          </div>

          {/* Subscriber & Group Info */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-3 text-xs border-b border-slate-200 pb-4">
            <div>
              <span className="text-slate-500 block text-[10px] uppercase tracking-wider font-semibold">Subscriber Details</span>
              <p className="font-bold text-slate-900 text-sm mt-0.5">{receipt.customerName}</p>
              <p className="text-slate-600 font-mono text-[11px]">ID: {receipt.customerId}</p>
              <p className="text-slate-600 font-mono text-[11px]">Mob: {receipt.customerMobile}</p>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px] uppercase tracking-wider font-semibold">Chit Membership</span>
              <p className="font-bold text-slate-900 text-sm mt-0.5">{receipt.groupName}</p>
              <p className="text-slate-600 font-mono text-[11px]">Group ID: {receipt.groupId}</p>
              <p className="text-amber-800 font-semibold font-mono text-[11px] mt-0.5">
                Ticket No: <span className="text-xs bg-amber-100 text-amber-900 px-1.5 py-0.2 rounded font-bold">#{receipt.ticketNumber}</span>
              </p>
            </div>
          </div>

          {/* Installment Breakdown Table */}
          <div>
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 text-[11px] uppercase">
                  <th className="py-2">Description</th>
                  <th className="py-2 text-right">Amount ({receipt.currencySymbol})</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                <tr>
                  <td className="py-2 text-slate-700">Installment Month #{receipt.monthNumber} (Gross)</td>
                  <td className="py-2 text-right font-medium">{receipt.currencySymbol}{receipt.installmentAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                </tr>
                {receipt.dividendDeduction > 0 && (
                  <tr>
                    <td className="py-2 text-emerald-700">Less: Auction Dividend Credit</td>
                    <td className="py-2 text-right font-medium text-emerald-700">-{receipt.currencySymbol}{receipt.dividendDeduction.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                  </tr>
                )}
                <tr className="bg-slate-50/70 font-semibold text-slate-800">
                  <td className="py-2.5 px-2">Net Due Amount</td>
                  <td className="py-2.5 px-2 text-right">{receipt.currencySymbol}{receipt.netDueAmount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                </tr>
                <tr className="border-t-2 border-slate-800 text-slate-900 font-bold text-sm bg-emerald-50/50">
                  <td className="py-3 px-2 text-emerald-950 font-sans">Total Amount Paid</td>
                  <td className="py-3 px-2 text-right text-emerald-800 text-base">{receipt.currencySymbol}{receipt.amountPaid.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Payment Mode & Balances */}
          <div className="grid grid-cols-2 gap-4 bg-slate-50/80 p-3.5 rounded-lg border border-slate-200 text-xs">
            <div>
              <span className="text-slate-500 block">Payment Mode</span>
              <span className="font-semibold text-slate-900">{receipt.paymentMode}</span>
              {receipt.transactionReference && (
                <span className="text-slate-500 block text-[11px] font-mono mt-0.5 truncate">Ref: {receipt.transactionReference}</span>
              )}
            </div>
            <div className="text-right">
              <span className="text-slate-500 block">Remaining Installment Balance</span>
              <span className={`font-bold font-mono text-sm ${receipt.remainingBalance > 0 ? 'text-amber-700' : 'text-emerald-700'}`}>
                {receipt.currencySymbol}{receipt.remainingBalance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              </span>
            </div>
          </div>

          {receipt.remarks && (
            <div className="text-xs text-slate-500 italic bg-slate-50 p-2.5 rounded border border-slate-100">
              Note: {receipt.remarks}
            </div>
          )}

          {/* Signatures Footer */}
          <div className="pt-6 border-t border-slate-200 grid grid-cols-2 gap-8 text-center text-xs">
            <div>
              <div className="h-10 border-b border-dashed border-slate-300"></div>
              <span className="text-slate-500 mt-1 block">Subscriber Signature</span>
            </div>
            <div>
              <div className="h-10 border-b border-dashed border-slate-300 flex items-end justify-center pb-1">
                <span className="text-[11px] text-slate-700 font-medium">{receipt.collectedByName}</span>
              </div>
              <span className="text-slate-500 mt-1 block">Cashier / Authorized Signatory</span>
            </div>
          </div>

          <div className="text-center text-[10px] text-slate-400 font-mono pt-2">
            Computer generated receipt • Registered with Registrar of Chits • Subject to terms of Chit Agreement
          </div>
        </div>
      </div>
    </div>
  );
};
