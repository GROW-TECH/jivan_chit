<?php
// ============================================================
// MEMBERSHIPS API
// ============================================================
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/helpers.php';

setCorsHeaders();
$pdo    = Database::getInstance();
$method = getMethod();
$id     = $_GET['id'] ?? null;

switch ($method) {
    case 'GET':
        if ($id) {
            $stmt = $pdo->prepare("
                SELECT m.*, c.full_name AS customer_name, c.mobile_number AS customer_mobile,
                       cg.group_name, cg.chit_value
                FROM memberships m
                LEFT JOIN customers c ON m.customer_id = c.customer_id
                LEFT JOIN chit_groups cg ON m.group_id = cg.group_id
                WHERE m.membership_id = ?
            ");
            $stmt->execute([$id]);
            $row = $stmt->fetch();
            if (!$row) jsonResponse(false, 'Membership not found', null, 404);
            jsonResponse(true, '', ['membership' => mapMembership($row)]);
        }
        $sql    = "
            SELECT m.*, c.full_name AS customer_name, c.mobile_number AS customer_mobile,
                   cg.group_name, cg.chit_value
            FROM memberships m
            LEFT JOIN customers c ON m.customer_id = c.customer_id
            LEFT JOIN chit_groups cg ON m.group_id = cg.group_id
            WHERE 1=1
        ";
        $params = [];
        if (!empty($_GET['customerId'])) { $sql .= " AND m.customer_id=?"; $params[] = $_GET['customerId']; }
        if (!empty($_GET['groupId']))    { $sql .= " AND m.group_id=?";    $params[] = $_GET['groupId'];    }
        $sql .= " ORDER BY m.created_at DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        jsonResponse(true, '', ['memberships' => array_map('mapMembership', $stmt->fetchAll())]);
        break;

    case 'POST':
        $b = getRequestBody();
        $stmt  = $pdo->query("SELECT COUNT(*) FROM memberships");
        $count = (int)$stmt->fetchColumn() + 1;
        $mid   = 'MEM' . str_pad($count, 5, '0', STR_PAD_LEFT);
        $pending = (int)$b['totalInstallments'] - 0;
        $pdo->prepare("
            INSERT INTO memberships
              (membership_id, customer_id, group_id, ticket_number, joining_date,
               installment_amount, total_installments, paid_installments, pending_installments,
               total_paid, total_pending, status)
            VALUES (?,?,?,?,?,?,?,0,?,0.00,?,?)
        ")->execute([
            $mid, $b['customerId'], $b['groupId'], $b['ticketNumber'], $b['joiningDate'],
            $b['installmentAmount'], $b['totalInstallments'],
            $b['totalInstallments'], // pending starts at total
            $b['installmentAmount'] * $b['totalInstallments'], // total_pending
            $b['status'] ?? 'active'
        ]);
        $stmt = $pdo->prepare("SELECT m.*, c.full_name AS customer_name, c.mobile_number AS customer_mobile, cg.group_name, cg.chit_value FROM memberships m LEFT JOIN customers c ON m.customer_id=c.customer_id LEFT JOIN chit_groups cg ON m.group_id=cg.group_id WHERE m.membership_id=?");
        $stmt->execute([$mid]);
        jsonResponse(true, 'Membership created', ['membership' => mapMembership($stmt->fetch())], 201);
        break;

    case 'PUT':
        if (!$id) jsonResponse(false, 'Membership ID required', null, 400);
        $b = getRequestBody();
        $pdo->prepare("UPDATE memberships SET status=? WHERE membership_id=?")->execute([$b['status'], $id]);
        jsonResponse(true, 'Membership updated');
        break;

    default:
        jsonResponse(false, 'Method not allowed', null, 405);
}

function mapMembership(array $r): array {
    return [
        'id'                  => (int)$r['id'],
        'membershipId'        => $r['membership_id'],
        'customerId'          => $r['customer_id'],
        'customerName'        => $r['customer_name'] ?? null,
        'customerMobile'      => $r['customer_mobile'] ?? null,
        'groupId'             => $r['group_id'],
        'groupName'           => $r['group_name'] ?? null,
        'chitValue'           => isset($r['chit_value']) ? (float)$r['chit_value'] : null,
        'ticketNumber'        => (int)$r['ticket_number'],
        'joiningDate'         => $r['joining_date'],
        'installmentAmount'   => (float)$r['installment_amount'],
        'totalInstallments'   => (int)$r['total_installments'],
        'paidInstallments'    => (int)$r['paid_installments'],
        'pendingInstallments' => (int)$r['pending_installments'],
        'totalPaid'           => (float)$r['total_paid'],
        'totalPending'        => (float)$r['total_pending'],
        'status'              => $r['status'],
        'createdAt'           => $r['created_at'],
        'updatedAt'           => $r['updated_at'],
    ];
}
