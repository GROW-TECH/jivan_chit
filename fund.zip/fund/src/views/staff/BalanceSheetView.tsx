import React, { useState, useEffect } from 'react';
import { RefreshCw, Scale, AlertTriangle, AlertCircle, FileText } from 'lucide-react';
import { api } from '../../api/client';

export const BalanceSheetView: React.FC<{ userRole: string }> = ({ userRole }) => {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await api.getBalanceSheet();
      setData(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Balance Sheet</h1>
          <p className="text-sm text-slate-500">Live outstanding targets, arrears, and overdues</p>
        </div>
        <button onClick={fetchData} className="flex items-center gap-2 px-4 py-2 bg-slate-900 text-white rounded-lg hover:bg-slate-800 transition">
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Sheet</span>
        </button>
      </div>

      {loading ? (
        <div className="flex justify-center py-20"><RefreshCw className="w-8 h-8 text-amber-500 animate-spin" /></div>
      ) : data ? (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-slate-500 uppercase tracking-wider">Total Outstanding Balance</p>
                <p className="text-4xl font-bold text-slate-900 mt-2">₹{data.totalOutstanding?.toLocaleString()}</p>
              </div>
              <div className="w-16 h-16 rounded-2xl bg-amber-100 flex items-center justify-center text-amber-600">
                <Scale className="w-8 h-8" />
              </div>
            </div>
            <div className="bg-rose-50 p-6 rounded-xl border border-rose-200 shadow-sm flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-rose-600 uppercase tracking-wider">Total Arrears (Overdue)</p>
                <p className="text-4xl font-bold text-rose-700 mt-2">₹{data.totalArrears?.toLocaleString()}</p>
              </div>
              <div className="w-16 h-16 rounded-2xl bg-rose-200 flex items-center justify-center text-rose-700">
                <AlertTriangle className="w-8 h-8" />
              </div>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
            <div className="p-4 border-b border-slate-200 bg-slate-50 font-semibold text-slate-800 flex justify-between items-center">
              <span>Pending Installments</span>
              <span className="bg-slate-200 text-slate-700 py-0.5 px-2 rounded-full text-xs">{data.records?.length || 0} Records</span>
            </div>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-slate-200 text-sm">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="px-4 py-3 text-left font-medium text-slate-500">Customer & Group</th>
                    <th className="px-4 py-3 text-left font-medium text-slate-500">Due Date</th>
                    <th className="px-4 py-3 text-right font-medium text-slate-500">Target Amount</th>
                    <th className="px-4 py-3 text-right font-medium text-slate-500">Outstanding / Arrears</th>
                    <th className="px-4 py-3 text-center font-medium text-slate-500">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 bg-white">
                  {data.records?.map((r: any) => (
                    <tr key={r.id} className="hover:bg-slate-50 transition">
                      <td className="px-4 py-3">
                        <p className="font-medium text-slate-900">{r.customerName}</p>
                        <p className="text-xs text-slate-500">{r.groupName}</p>
                      </td>
                      <td className="px-4 py-3">
                        <p className={`font-medium ${r.isOverdue ? 'text-rose-600' : 'text-slate-700'}`}>{String(r.dueDate).slice(0, 10)}</p>
                        <p className="text-xs text-slate-500">{r.day}</p>
                      </td>
                      <td className="px-4 py-3 text-right text-slate-600">₹{r.dueAmount?.toLocaleString()}</td>
                      <td className="px-4 py-3 text-right">
                        <p className={`font-medium ${r.isOverdue ? 'text-rose-600' : 'text-amber-600'}`}>
                          ₹{r.outstandingBalance?.toLocaleString()}
                        </p>
                      </td>
                      <td className="px-4 py-3 text-center">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold ${
                          r.isOverdue ? 'bg-rose-100 text-rose-800' : 'bg-amber-100 text-amber-800'
                        }`}>
                          {r.isOverdue ? <AlertTriangle className="w-3 h-3" /> : <AlertCircle className="w-3 h-3" />}
                          {r.overdueStatus}
                        </span>
                      </td>
                    </tr>
                  ))}
                  {!data.records?.length && (
                    <tr>
                      <td colSpan={5} className="px-4 py-8 text-center text-slate-500">No pending balances or arrears.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : (
        <div className="text-center py-12 text-slate-500">Failed to load data</div>
      )}
    </div>
  );
};
