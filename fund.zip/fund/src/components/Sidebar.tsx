import React from 'react';
import {
  LayoutDashboard, Users, Coins, Ticket, CalendarDays, Receipt, Gavel,
  PieChart, Award, Wallet, FileBarChart, ShieldCheck, Settings, History,
  Building2, Bell, Scale, FileText, FileWarning, X
} from 'lucide-react';
import type { UserRole } from '../types';

interface SidebarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  userRole: UserRole;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

interface NavItem {
  id: string;
  label: string;
  icon: React.ElementType;
  roles?: string[]; // only used for admin/staff list
}

const ADMIN_STAFF_ITEMS: NavItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: ['admin', 'staff'] },
  { id: 'customers', label: 'Customers', icon: Users, roles: ['admin', 'staff'] },
  { id: 'chit-groups', label: 'Chit Groups', icon: Coins, roles: ['admin', 'staff'] },
  { id: 'members', label: 'Members', icon: Ticket, roles: ['admin', 'staff'] },
  { id: 'installments', label: 'Installments', icon: CalendarDays, roles: ['admin', 'staff'] },
  { id: 'payments', label: 'Payments', icon: Receipt, roles: ['admin', 'staff'] },
  { id: 'auctions', label: 'Auctions', icon: Gavel, roles: ['admin', 'staff'] },
  { id: 'dividends', label: 'Dividends', icon: PieChart, roles: ['admin', 'staff'] },
  { id: 'prize-payments', label: 'Prize Payments', icon: Award, roles: ['admin', 'staff'] },
  { id: 'expenses', label: 'Expenses', icon: Wallet, roles: ['admin', 'staff'] },
  { id: 'reports', label: 'Reports', icon: FileBarChart, roles: ['admin', 'staff'] },
  { id: 'daily-collection', label: 'Daily Collection', icon: CalendarDays, roles: ['admin', 'staff'] },
  { id: 'monthly-collection', label: 'Monthly Collection', icon: Receipt, roles: ['admin', 'staff'] },
  { id: 'balance-sheet', label: 'Balance Sheet', icon: Scale, roles: ['admin', 'staff'] },
  { id: 'users', label: 'User Management', icon: ShieldCheck, roles: ['admin'] },
  { id: 'settings', label: 'Settings', icon: Settings, roles: ['admin', 'staff'] },
  { id: 'audit-logs', label: 'Audit Log', icon: History, roles: ['admin'] },
];

const AGENT_ITEMS: NavItem[] = [
  { id: 'agent-dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'agent-customers', label: 'My Customers', icon: Users },
  { id: 'daily-collection', label: 'Daily Collection', icon: CalendarDays },
  { id: 'monthly-collection', label: 'Monthly Collection', icon: Receipt },
  { id: 'balance-sheet', label: 'Balance Sheet', icon: Scale },
  { id: 'agent-collection', label: 'Collection Sheet', icon: FileText },
  { id: 'agent-balance', label: 'Balance Due', icon: FileWarning },
  { id: 'agent-commission', label: 'Commission', icon: Award },
  { id: 'agent-receipts', label: 'Receipts', icon: History },
  { id: 'agent-notifications', label: 'Notifications', icon: Bell },
  { id: 'agent-settings', label: 'Profile/Settings', icon: Settings },
];

const normalizeRole = (role: unknown): 'admin' | 'staff' | 'agent' | null => {
  const v = String(role ?? '').toLowerCase().trim();
  if (v.includes('agent')) return 'agent';
  if (v === 'admin' || v === 'staff') return v;
  return null;
};

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onNavigate,
  userRole,
  isOpenMobile,
  onCloseMobile
}) => {
  const role = normalizeRole(userRole);

  const items: NavItem[] =
    role === 'agent'
      ? AGENT_ITEMS
      : role
        ? ADMIN_STAFF_ITEMS.filter((i) => i.roles?.includes(role))
        : [];

  const isItemActive = (id: string) =>
    currentView === id || (id === 'agent-customers' && currentView === 'customers');

  return (
    <>
      {isOpenMobile && (
        <div
          className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-40 lg:hidden"
          onClick={onCloseMobile}
        />
      )}

      <aside
        id="app-sidebar"
        className={`fixed inset-y-0 left-0 z-50 w-72 max-w-[85vw] bg-slate-900 text-slate-300 flex flex-col transition-transform duration-200 ease-in-out border-r border-slate-800 lg:static lg:w-64 lg:z-auto lg:translate-x-0 shrink-0 ${isOpenMobile ? 'translate-x-0 shadow-2xl' : '-translate-x-full'
          }`}
      >
        <div className="h-16 flex items-center justify-between px-5 border-b border-slate-800 bg-slate-950/60 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-sm font-bold text-white tracking-wide">SRI CHIT FUNDS</h1>
              <p className="text-[10px] text-slate-400 tracking-wider uppercase font-semibold">Fund Management</p>
            </div>
          </div>
          <button
            onClick={onCloseMobile}
            className="p-2 min-h-[44px] min-w-[44px] flex items-center justify-center rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 lg:hidden"
            aria-label="Close menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto py-3 px-3 space-y-1">
          {items.map((item) => {
            const Icon = item.icon;
            const active = isItemActive(item.id);
            return (
              <button
                key={item.id}
                id={`nav-${item.id}`}
                onClick={() => {
                  onNavigate(item.id);
                  onCloseMobile();
                }}
                className={`w-full flex items-center gap-3 px-3 py-3 sm:py-2.5 min-h-[44px] rounded-lg text-xs font-medium transition-all ${active
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-sm shadow-amber-500/20'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                  }`}
              >
                <Icon className={`w-4 h-4 shrink-0 ${active ? 'text-slate-950' : 'text-slate-400'}`} />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-3 border-t border-slate-800 bg-slate-950/30">
          <div className="flex items-center justify-between px-3 py-2 bg-slate-800/60 rounded-lg text-xs border border-slate-700/60">
            <div className="flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full ${role === 'admin' ? 'bg-amber-400' : role === 'agent' ? 'bg-teal-400' : 'bg-sky-400'}`} />
              <span className="text-slate-200 capitalize font-medium">
                {role === 'agent' ? 'Agent Mode' : `${role ?? 'Unknown'} Mode`}
              </span>
            </div>
            <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-slate-700 text-slate-300">
              {role === 'admin' ? 'Full Access' : role === 'agent' ? 'RESTRICTED' : 'Restricted'}
            </span>
          </div>
        </div>
      </aside>
    </>
  );
};