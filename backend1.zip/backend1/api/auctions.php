<?php
// ============================================================
// AUCTIONS API
// ============================================================
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/helpers.php';

setCorsHeaders();
$pdo    = Database::getInstance();
$method = getMethod();
$id     = $_GET['id'] ?? null;

switch ($method) {
    case 'GET':
        $sql    = "
            SELECT a.*, cg.group_name, c.full_name AS winner_customer_name
            FROM auctions a
            LEFT JOIN chit_groups cg ON a.group_id = cg.group_id
            LEFT JOIN customers c ON a.winner_customer_id = c.customer_id
            WHERE 1=1
        ";
        $params = [];
        if ($id) { $sql .= " AND a.auction_id=?"; $params[] = $id; }
        if (!empty($_GET['groupId'])) { $sql .= " AND a.group_id=?"; $params[] = $_GET['groupId']; }
        $sql .= " ORDER BY a.auction_date DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();
        if ($id) jsonResponse(true, '', ['auction' => mapAuction($rows[0] ?? null)]);
        jsonResponse(true, '', ['auctions' => array_map('mapAuction', $rows)]);
        break;

    case 'POST':
        $b     = getRequestBody();
        $stmt  = $pdo->query("SELECT COUNT(*) FROM auctions");
        $count = (int)$stmt->fetchColumn() + 1;
        $aid   = 'AUC' . date('Ym') . str_pad($count, 4, '0', STR_PAD_LEFT);
        $pdo->prepare("
            INSERT INTO auctions
              (auction_id, group_id, auction_number, auction_date, chit_value,
               bid_discount_amount, prize_amount, foreman_commission, dividend_amount,
               dividend_per_member, winner_membership_id, winner_customer_id, ticket_number, status, remarks)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        ")->execute([
            $aid, $b['groupId'], $b['auctionNumber'], $b['auctionDate'], $b['chitValue'],
            $b['bidDiscountAmount'], $b['prizeAmount'], $b['foremanCommission'],
            $b['dividendAmount'], $b['dividendPerMember'],
            $b['winnerMembershipId'], $b['winnerCustomerId'], $b['ticketNumber'],
            $b['status'] ?? 'Completed', $b['remarks'] ?? null
        ]);
        jsonResponse(true, 'Auction recorded', ['auctionId' => $aid], 201);
        break;

    default:
        jsonResponse(false, 'Method not allowed', null, 405);
}

function mapAuction(array $r): array {
    return [
        'id'                  => (int)$r['id'],
        'auctionId'           => $r['auction_id'],
        'groupId'             => $r['group_id'],
        'groupName'           => $r['group_name'] ?? null,
        'auctionNumber'       => (int)$r['auction_number'],
        'auctionDate'         => $r['auction_date'],
        'chitValue'           => (float)$r['chit_value'],
        'bidDiscountAmount'   => (float)$r['bid_discount_amount'],
        'prizeAmount'         => (float)$r['prize_amount'],
        'foremanCommission'   => (float)$r['foreman_commission'],
        'dividendAmount'      => (float)$r['dividend_amount'],
        'dividendPerMember'   => (float)$r['dividend_per_member'],
        'winnerMembershipId'  => $r['winner_membership_id'],
        'winnerCustomerId'    => $r['winner_customer_id'],
        'winnerCustomerName'  => $r['winner_customer_name'] ?? null,
        'ticketNumber'        => (int)$r['ticket_number'],
        'status'              => $r['status'],
        'remarks'             => $r['remarks'],
        'createdAt'           => $r['created_at'],
        'updatedAt'           => $r['updated_at'],
    ];
}
