var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express2 = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_cors = __toESM(require("cors"), 1);
var import_dotenv = __toESM(require("dotenv"), 1);
var import_vite = require("vite");

// server/api.ts
var import_express = require("express");

// server/db.ts
var import_promise = __toESM(require("mysql2/promise"), 1);
var import_crypto = __toESM(require("crypto"), 1);
var round2 = (n) => Math.round((n + Number.EPSILON) * 100) / 100;
var today = () => (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
var pool = import_promise.default.createPool({
  host: process.env.DB_HOST || "xiadot.com",
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || "chit_db",
  password: process.env.DB_PASSWORD || process.env.DB_PASS || "chit_software",
  database: process.env.DB_NAME || "chit_db",
  charset: "utf8mb4",
  waitForConnections: true,
  connectionLimit: 10,
  timezone: "+00:00"
});
async function query(sql, params = []) {
  const [rows] = await pool.execute(sql, params);
  return rows;
}
async function queryOne(sql, params = []) {
  const rows = await query(sql, params);
  return rows[0] ?? null;
}
async function execute(sql, params = []) {
  const [result] = await pool.execute(sql, params);
  return result;
}
async function initDb() {
  try {
    await execute(`
      CREATE TABLE IF NOT EXISTS \`users\` (
        \`id\` INT AUTO_INCREMENT PRIMARY KEY,
        \`username\` VARCHAR(50) NOT NULL UNIQUE,
        \`password_hash\` VARCHAR(255) NOT NULL,
        \`full_name\` VARCHAR(100) NOT NULL,
        \`email\` VARCHAR(100) NOT NULL UNIQUE,
        \`role\` ENUM('admin', 'staff', 'agent') NOT NULL DEFAULT 'staff',
        \`status\` ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
        \`last_login\` DATETIME NULL,
        \`created_at\` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        \`updated_at\` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);
    await execute(`
      CREATE TABLE IF NOT EXISTS \`company_settings\` (
        \`id\` INT PRIMARY KEY DEFAULT 1,
        \`company_name\` VARCHAR(150) NOT NULL,
        \`address\` TEXT NOT NULL,
        \`phone\` VARCHAR(20) NOT NULL,
        \`email\` VARCHAR(100) NOT NULL,
        \`currency_symbol\` VARCHAR(5) NOT NULL DEFAULT '\u20B9',
        \`financial_year\` VARCHAR(20) NOT NULL DEFAULT '2025-2026',
        \`default_commission_percent\` DECIMAL(5, 2) NOT NULL DEFAULT 5.00,
        \`receipt_prefix\` VARCHAR(10) NOT NULL DEFAULT 'REC',
        \`customer_id_prefix\` VARCHAR(10) NOT NULL DEFAULT 'CUST',
        \`membership_id_prefix\` VARCHAR(10) NOT NULL DEFAULT 'MEM',
        \`updated_at\` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);
    await execute(`
      INSERT IGNORE INTO company_settings (id, company_name, address, phone, email, currency_symbol)
      VALUES (1, 'Jivan Chit Funds', '123 Main Road, City', '+91 9876543210', 'info@jivanchitfunds.com', '\u20B9')
    `);
    await execute(`
      CREATE TABLE IF NOT EXISTS \`customers\` (
        \`id\` INT AUTO_INCREMENT PRIMARY KEY,
        \`customer_id\` VARCHAR(30) NOT NULL UNIQUE,
        \`full_name\` VARCHAR(120) NOT NULL,
        \`mobile_number\` VARCHAR(15) NOT NULL,
        \`alternate_mobile\` VARCHAR(15) NULL,
        \`email\` VARCHAR(100) NULL,
        \`dob\` DATE NULL,
        \`gender\` ENUM('Male', 'Female', 'Other') NOT NULL DEFAULT 'Male',
        \`address\` TEXT NOT NULL,
        \`city\` VARCHAR(60) NOT NULL,
        \`pincode\` VARCHAR(10) NOT NULL,
        \`id_proof_type\` ENUM('Aadhaar', 'PAN', 'Voter ID', 'Passport', 'Driving License') NOT NULL DEFAULT 'Aadhaar',
        \`id_proof_number\` VARCHAR(50) NOT NULL,
        \`nominee_name\` VARCHAR(100) NOT NULL,
        \`nominee_relationship\` VARCHAR(50) NOT NULL,
        \`nominee_mobile\` VARCHAR(15) NOT NULL,
        \`joining_date\` DATE NOT NULL,
        \`status\` ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
        \`remarks\` TEXT NULL,
        \`created_at\` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        \`updated_at\` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);
    await execute(`
      CREATE TABLE IF NOT EXISTS \`chit_groups\` (
        \`id\` INT AUTO_INCREMENT PRIMARY KEY,
        \`group_id\` VARCHAR(30) NOT NULL UNIQUE,
        \`group_name\` VARCHAR(100) NOT NULL,
        \`chit_value\` DECIMAL(12, 2) NOT NULL,
        \`num_members\` INT NOT NULL,
        \`monthly_installment\` DECIMAL(12, 2) NOT NULL,
        \`duration_months\` INT NOT NULL,
        \`start_date\` DATE NOT NULL,
        \`end_date\` DATE NOT NULL,
        \`auction_day_of_month\` INT NOT NULL DEFAULT 10,
        \`auction_frequency\` VARCHAR(30) NOT NULL DEFAULT 'Monthly',
        \`foreman_commission_percent\` DECIMAL(5, 2) NOT NULL DEFAULT 5.00,
        \`status\` ENUM('Upcoming', 'Active', 'Completed', 'Cancelled') NOT NULL DEFAULT 'Upcoming',
        \`description\` TEXT NULL,
        \`created_at\` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        \`updated_at\` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);
    await execute(`
      CREATE TABLE IF NOT EXISTS \`memberships\` (
        \`id\` INT AUTO_INCREMENT PRIMARY KEY,
        \`membership_id\` VARCHAR(30) NOT NULL UNIQUE,
        \`customer_id\` VARCHAR(30) NOT NULL,
        \`group_id\` VARCHAR(30) NOT NULL,
        \`ticket_number\` INT NOT NULL,
        \`joining_date\` DATE NOT NULL,
        \`installment_amount\` DECIMAL(12, 2) NOT NULL,
        \`total_installments\` INT NOT NULL,
        \`paid_installments\` INT NOT NULL DEFAULT 0,
        \`pending_installments\` INT NOT NULL,
        \`total_paid\` DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
        \`total_pending\` DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
        \`status\` ENUM('active', 'prized', 'completed', 'cancelled') NOT NULL DEFAULT 'active',
        \`is_duplicate_allowed\` TINYINT(1) NOT NULL DEFAULT 0,
        \`created_at\` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        \`updated_at\` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY \`uniq_group_ticket\` (\`group_id\`, \`ticket_number\`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);
    await execute(`
      CREATE TABLE IF NOT EXISTS \`installments\` (
        \`id\` INT AUTO_INCREMENT PRIMARY KEY,
        \`installment_id\` VARCHAR(40) NOT NULL UNIQUE,
        \`membership_id\` VARCHAR(30) NOT NULL,
        \`customer_id\` VARCHAR(30) NOT NULL,
        \`group_id\` VARCHAR(30) NOT NULL,
        \`month_number\` INT NOT NULL,
        \`due_date\` DATE NOT NULL,
        \`installment_amount\` DECIMAL(12, 2) NOT NULL,
        \`dividend_deduction\` DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
        \`net_due_amount\` DECIMAL(12, 2) NOT NULL,
        \`paid_amount\` DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
        \`payment_date\` DATE NULL,
        \`payment_mode\` ENUM('Cash', 'UPI', 'Bank Transfer', 'Cheque', 'Other') NULL,
        \`receipt_number\` VARCHAR(50) NULL,
        \`status\` ENUM('Pending', 'Partially Paid', 'Paid', 'Overdue') NOT NULL DEFAULT 'Pending',
        \`remarks\` TEXT NULL,
        \`created_at\` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        \`updated_at\` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);
    await execute(`
      CREATE TABLE IF NOT EXISTS \`payments\` (
        \`id\` INT AUTO_INCREMENT PRIMARY KEY,
        \`receipt_number\` VARCHAR(50) NOT NULL UNIQUE,
        \`installment_id\` VARCHAR(40) NOT NULL,
        \`membership_id\` VARCHAR(30) NOT NULL,
        \`customer_id\` VARCHAR(30) NOT NULL,
        \`group_id\` VARCHAR(30) NOT NULL,
        \`amount_paid\` DECIMAL(12, 2) NOT NULL,
        \`previous_balance\` DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
        \`remaining_balance\` DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
        \`payment_mode\` ENUM('Cash', 'UPI', 'Bank Transfer', 'Cheque', 'Other') NOT NULL DEFAULT 'Cash',
        \`transaction_reference\` VARCHAR(100) NULL,
        \`payment_date\` DATE NOT NULL,
        \`collected_by_user_id\` INT NOT NULL,
        \`status\` ENUM('active', 'reversed', 'cancelled') NOT NULL DEFAULT 'active',
        \`reversal_reason\` TEXT NULL,
        \`remarks\` TEXT NULL,
        \`created_at\` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        \`updated_at\` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);
    await execute(`
      CREATE TABLE IF NOT EXISTS \`auctions\` (
        \`id\` INT AUTO_INCREMENT PRIMARY KEY,
        \`auction_id\` VARCHAR(40) NOT NULL UNIQUE,
        \`group_id\` VARCHAR(30) NOT NULL,
        \`auction_number\` INT NOT NULL,
        \`auction_date\` DATE NOT NULL,
        \`chit_value\` DECIMAL(12, 2) NOT NULL,
        \`bid_discount_amount\` DECIMAL(12, 2) NOT NULL,
        \`prize_amount\` DECIMAL(12, 2) NOT NULL,
        \`foreman_commission\` DECIMAL(12, 2) NOT NULL,
        \`dividend_amount\` DECIMAL(12, 2) NOT NULL,
        \`dividend_per_member\` DECIMAL(12, 2) NOT NULL,
        \`winner_membership_id\` VARCHAR(30) NOT NULL,
        \`winner_customer_id\` VARCHAR(30) NOT NULL,
        \`ticket_number\` INT NOT NULL,
        \`status\` ENUM('Scheduled', 'Completed', 'Cancelled') NOT NULL DEFAULT 'Completed',
        \`remarks\` TEXT NULL,
        \`created_at\` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        \`updated_at\` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY \`uniq_group_auction_num\` (\`group_id\`, \`auction_number\`)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);
    await execute(`
      CREATE TABLE IF NOT EXISTS \`dividends\` (
        \`id\` INT AUTO_INCREMENT PRIMARY KEY,
        \`dividend_id\` VARCHAR(40) NOT NULL UNIQUE,
        \`auction_id\` VARCHAR(40) NOT NULL,
        \`group_id\` VARCHAR(30) NOT NULL,
        \`total_discount\` DECIMAL(12, 2) NOT NULL,
        \`foreman_commission\` DECIMAL(12, 2) NOT NULL,
        \`distributable_dividend\` DECIMAL(12, 2) NOT NULL,
        \`num_eligible_members\` INT NOT NULL,
        \`dividend_per_member\` DECIMAL(12, 2) NOT NULL,
        \`month_number\` INT NOT NULL,
        \`status\` ENUM('Pending Review', 'Confirmed', 'Distributed') NOT NULL DEFAULT 'Confirmed',
        \`confirmed_by_user_id\` INT NOT NULL,
        \`created_at\` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);
    await execute(`
      CREATE TABLE IF NOT EXISTS \`prize_payments\` (
        \`id\` INT AUTO_INCREMENT PRIMARY KEY,
        \`prize_payment_id\` VARCHAR(40) NOT NULL UNIQUE,
        \`auction_id\` VARCHAR(40) NOT NULL,
        \`group_id\` VARCHAR(30) NOT NULL,
        \`winner_customer_id\` VARCHAR(30) NOT NULL,
        \`winner_membership_id\` VARCHAR(30) NOT NULL,
        \`ticket_number\` INT NOT NULL,
        \`auction_number\` INT NOT NULL,
        \`chit_value\` DECIMAL(12, 2) NOT NULL,
        \`discount_amount\` DECIMAL(12, 2) NOT NULL,
        \`prize_amount\` DECIMAL(12, 2) NOT NULL,
        \`paid_amount\` DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
        \`disbursal_date\` DATE NULL,
        \`payment_status\` ENUM('Pending', 'Partially Paid', 'Paid') NOT NULL DEFAULT 'Pending',
        \`payment_mode\` ENUM('Cash', 'UPI', 'Bank Transfer', 'Cheque', 'Other') NULL,
        \`transaction_reference\` VARCHAR(100) NULL,
        \`remarks\` TEXT NULL,
        \`created_at\` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        \`updated_at\` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);
    await execute(`
      CREATE TABLE IF NOT EXISTS \`expenses\` (
        \`id\` INT AUTO_INCREMENT PRIMARY KEY,
        \`expense_id\` VARCHAR(40) NOT NULL UNIQUE,
        \`expense_date\` DATE NOT NULL,
        \`category\` ENUM('Office Expense', 'Salary', 'Rent', 'Travel', 'Marketing', 'Bank Charges', 'Other') NOT NULL,
        \`description\` TEXT NOT NULL,
        \`amount\` DECIMAL(12, 2) NOT NULL,
        \`payment_mode\` ENUM('Cash', 'UPI', 'Bank Transfer', 'Cheque', 'Other') NOT NULL DEFAULT 'Cash',
        \`reference_number\` VARCHAR(100) NULL,
        \`remarks\` TEXT NULL,
        \`created_by_user_id\` INT NOT NULL,
        \`created_at\` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);
    await execute(`
      CREATE TABLE IF NOT EXISTS \`notifications\` (
        \`id\` INT AUTO_INCREMENT PRIMARY KEY,
        \`notification_id\` VARCHAR(40) NOT NULL UNIQUE,
        \`type\` ENUM('upcoming_installment', 'overdue_installment', 'upcoming_auction', 'pending_prize_payment', 'general') NOT NULL,
        \`title\` VARCHAR(150) NOT NULL,
        \`message\` TEXT NOT NULL,
        \`related_id\` VARCHAR(50) NULL,
        \`due_date\` DATE NULL,
        \`is_read\` TINYINT(1) NOT NULL DEFAULT 0,
        \`created_at\` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);
    await execute(`
      CREATE TABLE IF NOT EXISTS \`audit_logs\` (
        \`id\` INT AUTO_INCREMENT PRIMARY KEY,
        \`user_id\` INT NOT NULL,
        \`username\` VARCHAR(50) NOT NULL,
        \`action\` VARCHAR(50) NOT NULL,
        \`module\` VARCHAR(50) NOT NULL,
        \`record_id\` VARCHAR(50) NOT NULL,
        \`old_value\` JSON NULL,
        \`new_value\` JSON NULL,
        \`ip_address\` VARCHAR(45) NULL,
        \`timestamp\` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    `);
    const adminHash = import_crypto.default.createHash("sha256").update("admin123").digest("hex");
    const staffHash = import_crypto.default.createHash("sha256").update("staff123").digest("hex");
    const agentHash = import_crypto.default.createHash("sha256").update("agent123").digest("hex");
    await execute(`
      INSERT IGNORE INTO users (id, username, password_hash, full_name, email, role, status)
      VALUES
      (1, 'admin', ?, 'System Administrator', 'admin@jivanchitfunds.com', 'admin', 'active'),
      (2, 'staff', ?, 'Staff Cashier', 'staff@jivanchitfunds.com', 'staff', 'active'),
      (3, 'agent', ?, 'Ravi Kumar (Field Agent)', 'agent@jivanchitfunds.com', 'agent', 'active')
    `, [adminHash, staffHash, agentHash]);
    console.log("[DB] Database tables initialized successfully.");
  } catch (err) {
    console.error("[DB] Database initialization notice:", err);
  }
}
initDb();
function mapUser(r) {
  return {
    id: r.id,
    username: r.username,
    passwordHash: r.password_hash,
    fullName: r.full_name,
    email: r.email,
    role: r.role,
    status: r.status,
    lastLogin: r.last_login,
    lastLoginAt: r.last_login,
    createdAt: r.created_at
  };
}
function mapCustomer(r) {
  let groupCode = r.group_id || "";
  if (groupCode && !groupCode.includes("/")) {
    groupCode = `${groupCode}/001`;
  }
  const formattedTicket = r.ticket_number ? String(r.ticket_number).padStart(2, "0") : "";
  const newGroupNo = groupCode && formattedTicket ? `${groupCode}/${formattedTicket}` : r.new_group_no || "-";
  const rawChitValue = Number(r.chit_value || 0);
  const chitValue = rawChitValue >= 1e5 ? rawChitValue / 1e5 : rawChitValue;
  return {
    id: r.id,
    customerId: r.customer_id,
    fullName: r.full_name,
    mobileNumber: r.mobile_number,
    alternateMobile: r.alternate_mobile,
    email: r.email,
    dob: r.dob,
    gender: r.gender,
    address: r.address,
    city: r.city,
    pincode: r.pincode,
    idProofType: r.id_proof_type,
    idProofNumber: r.id_proof_number,
    nomineeName: r.nominee_name,
    nomineeRelationship: r.nominee_relationship,
    nomineeMobile: r.nominee_mobile,
    joiningDate: r.joining_date,
    status: r.status,
    googleMapLink: r.google_map_link,
    coApplicantName: r.co_applicant_name,
    coApplicantMobile: r.co_applicant_mobile,
    coApplicantAddress: r.co_applicant_address,
    coApplicantMapLink: r.co_applicant_map_link,
    security1Name: r.security1_name,
    security1Mobile: r.security1_mobile,
    security1Address: r.security1_address,
    security1MapLink: r.security1_map_link,
    security1Photo: r.security1_photo,
    security2Name: r.security2_name,
    security2Mobile: r.security2_mobile,
    security2Address: r.security2_address,
    security2MapLink: r.security2_map_link,
    security2Photo: r.security2_photo,
    remarks: r.remarks,
    totalMemberships: +(r.total_memberships || (r.membership_id ? 1 : 0)),
    newGroupNo,
    chitValue: chitValue || 10,
    month: Number(r.duration_months || 20),
    createdAt: r.created_at,
    updatedAt: r.updated_at
  };
}
function mapGroup(r) {
  return {
    id: r.id,
    groupId: r.group_id,
    groupName: r.group_name,
    chitValue: +r.chit_value,
    numMembers: +r.num_members,
    monthlyInstallment: +r.monthly_installment,
    durationMonths: +r.duration_months,
    startDate: r.start_date,
    endDate: r.end_date,
    auctionDayOfMonth: +r.auction_day_of_month,
    auctionFrequency: r.auction_frequency,
    foremanCommissionPercent: +r.foreman_commission_percent,
    status: r.status,
    description: r.description,
    currentMembersCount: +(r.current_members_count ?? 0),
    createdAt: r.created_at,
    updatedAt: r.updated_at
  };
}
function mapMembership(r) {
  return {
    id: r.id,
    membershipId: r.membership_id,
    customerId: r.customer_id,
    customerName: r.customer_name,
    customerMobile: r.customer_mobile,
    groupId: r.group_id,
    groupName: r.group_name,
    chitValue: +(r.chit_value ?? 0),
    ticketNumber: +r.ticket_number,
    joiningDate: r.joining_date,
    installmentAmount: +r.installment_amount,
    totalInstallments: +r.total_installments,
    paidInstallments: +r.paid_installments,
    pendingInstallments: +r.pending_installments,
    totalPaid: +r.total_paid,
    totalPending: +r.total_pending,
    status: r.status,
    isDuplicateAllowed: !!r.is_duplicate_allowed,
    groupNo: r.group_no || r.group_id,
    totalMembers: +(r.total_members ?? 0),
    durationMonths: +(r.duration_months ?? 0),
    monthlySubscription: +(r.monthly_subscription ?? r.installment_amount ?? 0),
    dob: r.dob,
    address: r.address,
    nomineeName: r.nominee_name,
    nomineeRelationship: r.nominee_relationship,
    pendingAmount: +r.total_pending,
    createdAt: r.created_at,
    updatedAt: r.updated_at
  };
}
function mapInstallment(r) {
  return {
    id: r.id,
    installmentId: r.installment_id,
    membershipId: r.membership_id,
    customerId: r.customer_id,
    customerName: r.customer_name,
    groupId: r.group_id,
    groupName: r.group_name,
    ticketNumber: +(r.ticket_number ?? 0),
    monthNumber: +r.month_number,
    dueDate: r.due_date,
    installmentAmount: +r.installment_amount,
    dividendDeduction: +r.dividend_deduction,
    netDueAmount: +r.net_due_amount,
    paidAmount: +r.paid_amount,
    balanceAmount: round2(+r.net_due_amount - +r.paid_amount),
    paymentDate: r.payment_date,
    paymentMode: r.payment_mode,
    receiptNumber: r.receipt_number,
    status: r.status,
    remarks: r.remarks,
    createdAt: r.created_at,
    updatedAt: r.updated_at
  };
}
function mapPayment(r) {
  return {
    id: r.id,
    receiptNumber: r.receipt_number,
    installmentId: r.installment_id,
    membershipId: r.membership_id,
    customerId: r.customer_id,
    customerName: r.customer_name,
    groupId: r.group_id,
    groupName: r.group_name,
    ticketNumber: +(r.ticket_number ?? 0),
    monthNumber: +(r.month_number ?? 0),
    amountPaid: +r.amount_paid,
    previousBalance: +r.previous_balance,
    remainingBalance: +r.remaining_balance,
    paymentMode: r.payment_mode,
    transactionReference: r.transaction_reference,
    paymentDate: r.payment_date,
    collectedByUserId: +r.collected_by_user_id,
    collectedByName: r.collected_by_name,
    status: r.status,
    reversalReason: r.reversal_reason,
    remarks: r.remarks,
    createdAt: r.created_at,
    updatedAt: r.updated_at
  };
}
function mapAuction(r) {
  return {
    id: r.id,
    auctionId: r.auction_id,
    groupId: r.group_id,
    groupName: r.group_name,
    auctionNumber: +r.auction_number,
    auctionDate: r.auction_date,
    chitValue: +r.chit_value,
    bidDiscountAmount: +r.bid_discount_amount,
    prizeAmount: +r.prize_amount,
    foremanCommission: +r.foreman_commission,
    dividendAmount: +r.dividend_amount,
    dividendPerMember: +r.dividend_per_member,
    winnerMembershipId: r.winner_membership_id,
    winnerCustomerId: r.winner_customer_id,
    winnerCustomerName: r.winner_customer_name,
    ticketNumber: +r.ticket_number,
    winnerTicketNumber: +r.ticket_number,
    status: r.status,
    remarks: r.remarks,
    createdAt: r.created_at,
    updatedAt: r.updated_at
  };
}
function mapDividend(r) {
  return {
    id: r.id,
    dividendId: r.dividend_id,
    auctionId: r.auction_id,
    groupId: r.group_id,
    groupName: r.group_name,
    totalDiscount: +r.total_discount,
    foremanCommission: +r.foreman_commission,
    distributableDividend: +r.distributable_dividend,
    numEligibleMembers: +r.num_eligible_members,
    dividendPerMember: +r.dividend_per_member,
    monthNumber: +r.month_number,
    status: r.status,
    confirmedByUserId: +r.confirmed_by_user_id,
    createdAt: r.created_at
  };
}
function mapPrizePayment(r) {
  return {
    id: r.id,
    prizePaymentId: r.prize_payment_id,
    auctionId: r.auction_id,
    groupId: r.group_id,
    groupName: r.group_name,
    winnerCustomerId: r.winner_customer_id,
    winnerCustomerName: r.winner_customer_name,
    winnerMembershipId: r.winner_membership_id,
    ticketNumber: +r.ticket_number,
    auctionNumber: +r.auction_number,
    chitValue: +r.chit_value,
    discountAmount: +r.discount_amount,
    prizeAmount: +r.prize_amount,
    paidAmount: +r.paid_amount,
    remainingAmount: round2(+r.prize_amount - +r.paid_amount),
    disbursalDate: r.disbursal_date,
    paymentStatus: r.payment_status,
    paymentMode: r.payment_mode,
    transactionReference: r.transaction_reference,
    remarks: r.remarks,
    createdAt: r.created_at,
    updatedAt: r.updated_at
  };
}
function mapExpense(r) {
  return {
    id: r.id,
    expenseId: r.expense_id,
    expenseDate: r.expense_date,
    category: r.category,
    description: r.description,
    amount: +r.amount,
    paymentMode: r.payment_mode,
    referenceNumber: r.reference_number,
    remarks: r.remarks,
    createdByUserId: +r.created_by_user_id,
    createdByName: r.created_by_name,
    createdAt: r.created_at
  };
}
function mapNotification(r) {
  return {
    id: r.id,
    notificationId: r.notification_id,
    type: r.type,
    title: r.title,
    message: r.message,
    relatedId: r.related_id,
    dueDate: r.due_date,
    isRead: !!r.is_read,
    createdAt: r.created_at
  };
}
function mapAuditLog(r) {
  return {
    id: r.id,
    userId: +r.user_id,
    username: r.username,
    action: r.action,
    module: r.module,
    recordId: r.record_id,
    oldValue: r.old_value,
    newValue: r.new_value,
    ipAddress: r.ip_address,
    timestamp: r.timestamp
  };
}
function mapSettings(r) {
  return {
    id: r.id,
    companyName: r.company_name,
    address: r.address,
    phone: r.phone,
    email: r.email,
    currencySymbol: r.currency_symbol,
    financialYear: r.financial_year,
    defaultCommissionPercent: +r.default_commission_percent,
    defaultForemanCommissionPercent: +r.default_commission_percent,
    receiptPrefix: r.receipt_prefix,
    customerIdPrefix: r.customer_id_prefix,
    membershipIdPrefix: r.membership_id_prefix,
    updatedAt: r.updated_at
  };
}
var db = {
  // ---- USERS ----
  getUserByUsername(username) {
    return pool.execute("SELECT * FROM users WHERE username=? LIMIT 1", [username]).then(([rows]) => rows[0] ? mapUser(rows[0]) : null);
  },
  getUserById(id) {
    return pool.execute("SELECT * FROM users WHERE id=? LIMIT 1", [id]).then(([rows]) => rows[0] ? mapUser(rows[0]) : null);
  },
  getUsers() {
    return query("SELECT * FROM users ORDER BY created_at DESC").then((rows) => rows.map(mapUser));
  },
  async createUser(data, actor) {
    const hash = import_crypto.default.createHash("sha256").update(data.password).digest("hex");
    const count = (await query("SELECT COUNT(*) AS c FROM users"))[0].c;
    const id = count + 1;
    await execute(
      `INSERT INTO users (username,password_hash,full_name,email,role,status)
       VALUES (?,?,?,?,?,?)`,
      [data.username, hash, data.fullName, data.email, data.role || "staff", data.status || "active"]
    );
    await db.logAudit(actor.id, actor.username, "CREATE_USER", "USERS", String(id), null, data);
    const r = await queryOne("SELECT * FROM users WHERE username=?", [data.username]);
    return mapUser(r);
  },
  async updateUser(id, data, actor) {
    const fields = [];
    const params = [];
    if (data.fullName) {
      fields.push("full_name=?");
      params.push(data.fullName);
    }
    if (data.email) {
      fields.push("email=?");
      params.push(data.email);
    }
    if (data.role) {
      fields.push("role=?");
      params.push(data.role);
    }
    if (data.status) {
      fields.push("status=?");
      params.push(data.status);
    }
    if (data.password) {
      fields.push("password_hash=?");
      params.push(import_crypto.default.createHash("sha256").update(data.password).digest("hex"));
    }
    params.push(id);
    await execute(`UPDATE users SET ${fields.join(",")} WHERE id=?`, params);
    await db.logAudit(actor.id, actor.username, "UPDATE_USER", "USERS", String(id), null, data);
    const r = await queryOne("SELECT * FROM users WHERE id=?", [id]);
    return mapUser(r);
  },
  async updateLastLogin(userId) {
    await execute("UPDATE users SET last_login=NOW() WHERE id=?", [userId]);
  },
  // ---- SETTINGS ----
  getSettings() {
    return queryOne("SELECT * FROM company_settings WHERE id=1").then((r) => r ? mapSettings(r) : {});
  },
  async updateSettings(data) {
    await execute(
      `UPDATE company_settings SET
      company_name=?, address=?, phone=?, email=?,
      currency_symbol=?, financial_year=?,
      default_commission_percent=?, receipt_prefix=?,
      customer_id_prefix=?, membership_id_prefix=?
      WHERE id=1`,
      [
        data.companyName,
        data.address,
        data.phone,
        data.email,
        data.currencySymbol,
        data.financialYear,
        data.defaultCommissionPercent ?? data.defaultForemanCommissionPercent ?? 5,
        data.receiptPrefix,
        data.customerIdPrefix,
        data.membershipIdPrefix
      ]
    );
    return db.getSettings();
  },
  // ---- CUSTOMERS ----
  getCustomers(search, status) {
    let sql = "SELECT * FROM customers WHERE 1=1";
    const p = [];
    if (search) {
      sql += " AND (full_name LIKE ? OR mobile_number LIKE ? OR customer_id LIKE ?)";
      const l = `%${search}%`;
      p.push(l, l, l);
    }
    if (status) {
      sql += " AND status=?";
      p.push(status);
    }
    sql += " ORDER BY created_at DESC";
    return query(sql, p).then((rows) => rows.map(mapCustomer));
  },
  getCustomerById(id) {
    return queryOne("SELECT * FROM customers WHERE customer_id=?", [id]).then((r) => r ? mapCustomer(r) : null);
  },
  async createCustomer(data, actor) {
    const countRow = await queryOne("SELECT COUNT(*) AS c FROM customers");
    const cid = `CUST-${1001 + (countRow?.c ?? 0)}`;
    await execute(
      `INSERT INTO customers
      (customer_id,full_name,mobile_number,alternate_mobile,email,dob,gender,
       address,city,pincode,id_proof_type,id_proof_number,
       nominee_name,nominee_relationship,nominee_mobile,joining_date,status,remarks)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [
        cid,
        data.fullName,
        data.mobileNumber,
        data.alternateMobile ?? null,
        data.email ?? null,
        data.dob ?? null,
        data.gender ?? "Male",
        data.address,
        data.city,
        data.pincode,
        data.idProofType ?? "Aadhaar",
        data.idProofNumber,
        data.nomineeName,
        data.nomineeRelationship ?? "Spouse",
        data.nomineeMobile ?? data.mobileNumber,
        data.joiningDate ?? today(),
        data.status ?? "active",
        data.remarks ?? null
      ]
    );
    await db.logAudit(actor.id, actor.username, "CREATE_CUSTOMER", "CUSTOMERS", cid, null, data);
    const r = await queryOne("SELECT * FROM customers WHERE customer_id=?", [cid]);
    return mapCustomer(r);
  },
  async updateCustomer(id, data, actor) {
    const old = await db.getCustomerById(id);
    await execute(
      `UPDATE customers SET
      full_name=?,mobile_number=?,alternate_mobile=?,email=?,dob=?,gender=?,
      address=?,city=?,pincode=?,id_proof_type=?,id_proof_number=?,
      nominee_name=?,nominee_relationship=?,nominee_mobile=?,
      joining_date=?,status=?,remarks=?
      WHERE customer_id=?`,
      [
        data.fullName,
        data.mobileNumber,
        data.alternateMobile ?? null,
        data.email ?? null,
        data.dob ?? null,
        data.gender ?? "Male",
        data.address,
        data.city,
        data.pincode,
        data.idProofType ?? "Aadhaar",
        data.idProofNumber,
        data.nomineeName,
        data.nomineeRelationship ?? "Spouse",
        data.nomineeMobile,
        data.joiningDate ?? today(),
        data.status ?? "active",
        data.remarks ?? null,
        id
      ]
    );
    await db.logAudit(actor.id, actor.username, "UPDATE_CUSTOMER", "CUSTOMERS", id, old, data);
    const r = await queryOne("SELECT * FROM customers WHERE customer_id=?", [id]);
    return mapCustomer(r);
  },
  // ---- CHIT GROUPS ----
  getChitGroups(status) {
    let sql = `SELECT cg.*,
      (SELECT COUNT(*) FROM memberships m WHERE m.group_id=cg.group_id AND m.status='active') AS current_members_count
      FROM chit_groups cg WHERE 1=1`;
    const p = [];
    if (status) {
      sql += " AND cg.status=?";
      p.push(status);
    }
    sql += " ORDER BY cg.created_at DESC";
    return query(sql, p).then((rows) => rows.map(mapGroup));
  },
  getChitGroupById(id) {
    return queryOne(`SELECT cg.*,
      (SELECT COUNT(*) FROM memberships m WHERE m.group_id=cg.group_id AND m.status='active') AS current_members_count
      FROM chit_groups cg WHERE cg.group_id=?`, [id]).then((r) => r ? mapGroup(r) : null);
  },
  async createChitGroup(data, actor) {
    const gid = data.groupId?.trim().toUpperCase() ?? `GRP-${Date.now()}`;
    await execute(
      `INSERT INTO chit_groups
      (group_id,group_name,chit_value,num_members,monthly_installment,duration_months,
       start_date,end_date,auction_day_of_month,auction_frequency,
       foreman_commission_percent,status,description)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [
        gid,
        data.groupName,
        data.chitValue,
        data.numMembers,
        data.monthlyInstallment ?? round2((data.chitValue ?? 0) / (data.durationMonths ?? 1)),
        data.durationMonths,
        data.startDate,
        data.endDate ?? data.startDate,
        data.auctionDayOfMonth ?? 10,
        data.auctionFrequency ?? "Monthly",
        data.foremanCommissionPercent ?? 5,
        data.status ?? "Upcoming",
        data.description ?? null
      ]
    );
    await db.logAudit(actor.id, actor.username, "CREATE_GROUP", "CHIT_GROUPS", gid, null, data);
    return await db.getChitGroupById(gid);
  },
  async updateChitGroup(id, data, actor) {
    const old = await db.getChitGroupById(id);
    await execute(
      `UPDATE chit_groups SET
      group_name=?,chit_value=?,num_members=?,monthly_installment=?,duration_months=?,
      start_date=?,end_date=?,auction_day_of_month=?,auction_frequency=?,
      foreman_commission_percent=?,status=?,description=?
      WHERE group_id=?`,
      [
        data.groupName,
        data.chitValue,
        data.numMembers,
        data.monthlyInstallment ?? round2((data.chitValue ?? 0) / (data.durationMonths ?? 1)),
        data.durationMonths,
        data.startDate,
        data.endDate,
        data.auctionDayOfMonth ?? 10,
        data.auctionFrequency ?? "Monthly",
        data.foremanCommissionPercent ?? 5,
        data.status ?? "Upcoming",
        data.description ?? null,
        id
      ]
    );
    await db.logAudit(actor.id, actor.username, "UPDATE_GROUP", "CHIT_GROUPS", id, old, data);
    return await db.getChitGroupById(id);
  },
  // ---- MEMBERSHIPS ----
  getMemberships(groupId, customerId) {
    let sql = `SELECT m.*,
      c.full_name AS customer_name, c.mobile_number AS customer_mobile, c.dob, c.address, c.nominee_name, c.nominee_relationship,
      cg.group_name, cg.group_id AS group_no, cg.chit_value, cg.num_members AS total_members, cg.duration_months, cg.monthly_installment AS monthly_subscription
      FROM memberships m
      LEFT JOIN customers c ON m.customer_id=c.customer_id
      LEFT JOIN chit_groups cg ON m.group_id=cg.group_id
      WHERE 1=1`;
    const p = [];
    if (groupId) {
      sql += " AND m.group_id=?";
      p.push(groupId);
    }
    if (customerId) {
      sql += " AND m.customer_id=?";
      p.push(customerId);
    }
    sql += " ORDER BY m.created_at DESC";
    return query(sql, p).then((rows) => rows.map(mapMembership));
  },
  getMembershipById(id) {
    return queryOne(`SELECT m.*,
      c.full_name AS customer_name, c.mobile_number AS customer_mobile, c.dob, c.address, c.nominee_name, c.nominee_relationship,
      cg.group_name, cg.group_id AS group_no, cg.chit_value, cg.num_members AS total_members, cg.duration_months, cg.monthly_installment AS monthly_subscription
      FROM memberships m
      LEFT JOIN customers c ON m.customer_id=c.customer_id
      LEFT JOIN chit_groups cg ON m.group_id=cg.group_id
      WHERE m.membership_id=?`, [id]).then((r) => r ? mapMembership(r) : null);
  },
  async createMembership(data, actor) {
    const { customerId, groupId, ticketNumber, joiningDate, isDuplicateAllowed } = data;
    const customer = await db.getCustomerById(customerId);
    const group = await db.getChitGroupById(groupId);
    if (!customer) throw new Error("Customer not found");
    if (!group) throw new Error("Chit group not found");
    const countRow = await queryOne("SELECT COUNT(*) AS c FROM memberships");
    const mid = `MEM-${String((countRow?.c ?? 0) + 1).padStart(3, "0")}`;
    let ticket = ticketNumber;
    if (!ticket) {
      const usedRows = await query("SELECT ticket_number FROM memberships WHERE group_id=?", [groupId]);
      const used = new Set(usedRows.map((r) => r.ticket_number));
      for (let t = 1; t <= group.numMembers; t++) {
        if (!used.has(t)) {
          ticket = t;
          break;
        }
      }
      if (!ticket) throw new Error("No available ticket slots in this chit group");
    }
    const totalPending = round2(group.monthlyInstallment * group.durationMonths);
    await execute(
      `INSERT INTO memberships
      (membership_id,customer_id,group_id,ticket_number,joining_date,
       installment_amount,total_installments,paid_installments,pending_installments,
       total_paid,total_pending,status,is_duplicate_allowed)
      VALUES (?,?,?,?,?,?,?,0,?,0.00,?,?,?)`,
      [
        mid,
        customerId,
        groupId,
        ticket,
        joiningDate ?? today(),
        group.monthlyInstallment,
        group.durationMonths,
        group.durationMonths,
        totalPending,
        "active",
        isDuplicateAllowed ? 1 : 0
      ]
    );
    for (let m = 1; m <= group.durationMonths; m++) {
      const due = new Date(joiningDate ?? today());
      due.setMonth(due.getMonth() + (m - 1));
      due.setDate(group.auctionDayOfMonth);
      const iid = `INST-${mid}-${String(m).padStart(2, "0")}`;
      await execute(
        `INSERT IGNORE INTO installments
        (installment_id,membership_id,customer_id,group_id,month_number,
         due_date,installment_amount,dividend_deduction,net_due_amount,status)
        VALUES (?,?,?,?,?,?,?,0,?,'Pending')`,
        [
          iid,
          mid,
          customerId,
          groupId,
          m,
          due.toISOString().split("T")[0],
          group.monthlyInstallment,
          group.monthlyInstallment
        ]
      );
    }
    await db.logAudit(actor.id, actor.username, "CREATE_MEMBERSHIP", "MEMBERSHIPS", mid, null, data);
    return await db.getMembershipById(mid);
  },
  // ---- INSTALLMENTS ----
  getInstallments(filters) {
    let sql = `SELECT i.*, c.full_name AS customer_name, cg.group_name, m.ticket_number
      FROM installments i
      LEFT JOIN customers c ON i.customer_id=c.customer_id
      LEFT JOIN chit_groups cg ON i.group_id=cg.group_id
      LEFT JOIN memberships m ON i.membership_id=m.membership_id
      WHERE 1=1`;
    const p = [];
    if (filters?.customerId) {
      sql += " AND i.customer_id=?";
      p.push(filters.customerId);
    }
    if (filters?.groupId) {
      sql += " AND i.group_id=?";
      p.push(filters.groupId);
    }
    if (filters?.membershipId) {
      sql += " AND i.membership_id=?";
      p.push(filters.membershipId);
    }
    if (filters?.status) {
      sql += " AND i.status=?";
      p.push(filters.status);
    }
    sql += " ORDER BY i.due_date ASC";
    return query(sql, p).then((rows) => rows.map(mapInstallment));
  },
  getInstallmentById(id) {
    return queryOne(`SELECT i.*, c.full_name AS customer_name, cg.group_name, m.ticket_number
      FROM installments i
      LEFT JOIN customers c ON i.customer_id=c.customer_id
      LEFT JOIN chit_groups cg ON i.group_id=cg.group_id
      LEFT JOIN memberships m ON i.membership_id=m.membership_id
      WHERE i.installment_id=?`, [id]).then((r) => r ? mapInstallment(r) : null);
  },
  // ---- PAYMENTS ----
  getPayments(filters) {
    let sql = `SELECT p.*,
      c.full_name AS customer_name, cg.group_name,
      u.full_name AS collected_by_name, m.ticket_number,
      i.month_number
      FROM payments p
      LEFT JOIN customers c ON p.customer_id=c.customer_id
      LEFT JOIN chit_groups cg ON p.group_id=cg.group_id
      LEFT JOIN users u ON p.collected_by_user_id=u.id
      LEFT JOIN memberships m ON p.membership_id=m.membership_id
      LEFT JOIN installments i ON p.installment_id=i.installment_id
      WHERE 1=1`;
    const p = [];
    if (filters?.customerId) {
      sql += " AND p.customer_id=?";
      p.push(filters.customerId);
    }
    if (filters?.groupId) {
      sql += " AND p.group_id=?";
      p.push(filters.groupId);
    }
    if (filters?.membershipId) {
      sql += " AND p.membership_id=?";
      p.push(filters.membershipId);
    }
    if (filters?.status) {
      sql += " AND p.status=?";
      p.push(filters.status);
    }
    sql += " ORDER BY p.payment_date DESC, p.created_at DESC";
    return query(sql, p).then((rows) => rows.map(mapPayment));
  },
  getPaymentById(receiptOrId) {
    return queryOne(`SELECT p.*, c.full_name AS customer_name, cg.group_name,
      u.full_name AS collected_by_name, m.ticket_number, i.month_number
      FROM payments p
      LEFT JOIN customers c ON p.customer_id=c.customer_id
      LEFT JOIN chit_groups cg ON p.group_id=cg.group_id
      LEFT JOIN users u ON p.collected_by_user_id=u.id
      LEFT JOIN memberships m ON p.membership_id=m.membership_id
      LEFT JOIN installments i ON p.installment_id=i.installment_id
      WHERE p.receipt_number=? OR p.id=?`, [receiptOrId, receiptOrId]).then((r) => r ? mapPayment(r) : null);
  },
  async recordPayment(data, actor) {
    const inst = await db.getInstallmentById(data.installmentId);
    if (!inst) throw new Error("Installment not found");
    const mem = await db.getMembershipById(inst.membershipId);
    if (!mem) throw new Error("Membership not found");
    const group = await db.getChitGroupById(inst.groupId);
    const customer = await db.getCustomerById(inst.customerId);
    const settings = await db.getSettings();
    const prevBal = round2(inst.netDueAmount - inst.paidAmount);
    const paid = round2(Number(data.amountPaid));
    const remaining = round2(prevBal - paid);
    const newStatus = remaining <= 0 ? "Paid" : paid > 0 ? "Partially Paid" : inst.status;
    const countRow = await queryOne("SELECT COUNT(*) AS c FROM payments");
    const rec = `${settings.receiptPrefix ?? "REC"}-${(/* @__PURE__ */ new Date()).getFullYear()}-${String((countRow?.c ?? 0) + 1).padStart(4, "0")}`;
    await execute(
      `INSERT INTO payments
      (receipt_number,installment_id,membership_id,customer_id,group_id,
       amount_paid,previous_balance,remaining_balance,payment_mode,
       transaction_reference,payment_date,collected_by_user_id,status,remarks)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [
        rec,
        inst.installmentId,
        inst.membershipId,
        inst.customerId,
        inst.groupId,
        paid,
        prevBal,
        Math.max(0, remaining),
        data.paymentMode ?? "Cash",
        data.transactionReference ?? null,
        data.paymentDate ?? today(),
        actor.id,
        "active",
        data.remarks ?? null
      ]
    );
    await execute(
      `UPDATE installments SET
      paid_amount=paid_amount+?, status=?, payment_date=?, payment_mode=?, receipt_number=?
      WHERE installment_id=?`,
      [paid, newStatus, data.paymentDate ?? today(), data.paymentMode ?? "Cash", rec, inst.installmentId]
    );
    await execute(
      `UPDATE memberships SET
      total_paid=total_paid+?,
      paid_installments=paid_installments+(CASE WHEN ?='Paid' THEN 1 ELSE 0 END),
      pending_installments=GREATEST(0,pending_installments-(CASE WHEN ?='Paid' THEN 1 ELSE 0 END)),
      total_pending=GREATEST(0,total_pending-?)
      WHERE membership_id=?`,
      [paid, newStatus, newStatus, paid, inst.membershipId]
    );
    await db.logAudit(actor.id, actor.username, "RECORD_PAYMENT", "PAYMENTS", rec, null, data);
    const payment = await db.getPaymentById(rec);
    const receipt = {
      receiptNumber: rec,
      paymentDate: data.paymentDate ?? today(),
      companyName: settings.companyName,
      companyAddress: settings.address,
      companyPhone: settings.phone,
      companyEmail: settings.email,
      currencySymbol: settings.currencySymbol ?? "\u20B9",
      customerId: inst.customerId,
      customerName: customer?.fullName ?? "",
      customerMobile: customer?.mobileNumber ?? "",
      groupId: inst.groupId,
      groupName: group?.groupName ?? "",
      membershipId: inst.membershipId,
      ticketNumber: mem.ticketNumber,
      monthNumber: inst.monthNumber,
      installmentAmount: inst.installmentAmount,
      dividendDeduction: inst.dividendDeduction,
      netDueAmount: inst.netDueAmount,
      amountPaid: paid,
      previousBalance: prevBal,
      remainingBalance: Math.max(0, remaining),
      paymentMode: data.paymentMode ?? "Cash",
      transactionReference: data.transactionReference,
      collectedByName: actor.fullName ?? actor.username,
      remarks: data.remarks
    };
    return { payment, receipt };
  },
  async reversePayment(receiptNumber, reason, actor) {
    const pay = await db.getPaymentById(receiptNumber);
    if (!pay) throw new Error("Payment not found");
    await execute(`UPDATE payments SET status='reversed', reversal_reason=? WHERE receipt_number=?`, [reason, receiptNumber]);
    await execute(
      `UPDATE installments SET paid_amount=GREATEST(0,paid_amount-?), status='Pending' WHERE installment_id=?`,
      [pay.amountPaid, pay.installmentId]
    );
    await execute(
      `UPDATE memberships SET total_paid=GREATEST(0,total_paid-?), total_pending=total_pending+? WHERE membership_id=?`,
      [pay.amountPaid, pay.amountPaid, pay.membershipId]
    );
    await db.logAudit(actor.id, actor.username, "REVERSE_PAYMENT", "PAYMENTS", receiptNumber, pay, { reason });
    return { message: "Payment reversed", payment: await db.getPaymentById(receiptNumber) };
  },
  // ---- AUCTIONS ----
  getAuctions(groupId) {
    let sql = `SELECT a.*, cg.group_name, c.full_name AS winner_customer_name
      FROM auctions a
      LEFT JOIN chit_groups cg ON a.group_id=cg.group_id
      LEFT JOIN customers c ON a.winner_customer_id=c.customer_id
      WHERE 1=1`;
    const p = [];
    if (groupId) {
      sql += " AND a.group_id=?";
      p.push(groupId);
    }
    sql += " ORDER BY a.auction_date DESC";
    return query(sql, p).then((rows) => rows.map(mapAuction));
  },
  async calculateAuction(data) {
    const { chitValue, bidDiscountAmount, numMembers, commissionPercent = 5 } = data;
    const prizeAmount = round2(chitValue - bidDiscountAmount);
    const foremanCommission = round2(bidDiscountAmount * (commissionPercent / 100));
    const distributable = round2(bidDiscountAmount - foremanCommission);
    const dividendPerMember = round2(distributable / numMembers);
    return { chitValue, bidDiscountAmount, prizeAmount, foremanCommission, distributableDividend: distributable, numMembers, dividendPerMember };
  },
  async recordAuction(data, actor) {
    const group = await db.getChitGroupById(data.groupId);
    if (!group) throw new Error("Chit group not found");
    const mem = await db.getMembershipById(data.winnerMembershipId);
    if (!mem) throw new Error("Winner membership not found");
    const calc = await db.calculateAuction({
      chitValue: group.chitValue,
      bidDiscountAmount: data.bidDiscountAmount,
      numMembers: group.numMembers,
      commissionPercent: data.commissionPercent ?? group.foremanCommissionPercent
    });
    const countRow = await queryOne("SELECT COUNT(*) AS c FROM auctions");
    const aid = `AUC-${(/* @__PURE__ */ new Date()).getFullYear()}-${String((countRow?.c ?? 0) + 1).padStart(3, "0")}`;
    await execute(
      `INSERT INTO auctions
      (auction_id,group_id,auction_number,auction_date,chit_value,
       bid_discount_amount,prize_amount,foreman_commission,dividend_amount,
       dividend_per_member,winner_membership_id,winner_customer_id,ticket_number,status,remarks)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [
        aid,
        data.groupId,
        data.auctionNumber,
        data.auctionDate,
        group.chitValue,
        data.bidDiscountAmount,
        calc.prizeAmount,
        calc.foremanCommission,
        calc.distributableDividend,
        calc.dividendPerMember,
        data.winnerMembershipId,
        mem.customerId,
        mem.ticketNumber,
        "Completed",
        data.remarks ?? null
      ]
    );
    const dcountRow = await queryOne("SELECT COUNT(*) AS c FROM dividends");
    const did = `DIV-${(/* @__PURE__ */ new Date()).getFullYear()}-${String((dcountRow?.c ?? 0) + 1).padStart(3, "0")}`;
    await execute(
      `INSERT INTO dividends
      (dividend_id,auction_id,group_id,total_discount,foreman_commission,
       distributable_dividend,num_eligible_members,dividend_per_member,month_number,status,confirmed_by_user_id)
      VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
      [
        did,
        aid,
        data.groupId,
        data.bidDiscountAmount,
        calc.foremanCommission,
        calc.distributableDividend,
        group.numMembers,
        calc.dividendPerMember,
        data.auctionNumber,
        "Confirmed",
        actor.id
      ]
    );
    const pcountRow = await queryOne("SELECT COUNT(*) AS c FROM prize_payments");
    const pid = `PPY-${(/* @__PURE__ */ new Date()).getFullYear()}-${String((pcountRow?.c ?? 0) + 1).padStart(3, "0")}`;
    await execute(
      `INSERT INTO prize_payments
      (prize_payment_id,auction_id,group_id,winner_customer_id,winner_membership_id,
       ticket_number,auction_number,chit_value,discount_amount,prize_amount,payment_status)
      VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
      [
        pid,
        aid,
        data.groupId,
        mem.customerId,
        data.winnerMembershipId,
        mem.ticketNumber,
        data.auctionNumber,
        group.chitValue,
        data.bidDiscountAmount,
        calc.prizeAmount,
        "Pending"
      ]
    );
    await execute(`UPDATE memberships SET status='prized' WHERE membership_id=?`, [data.winnerMembershipId]);
    if (data.applyDividendToNextMonth) {
      await execute(
        `UPDATE installments SET
        dividend_deduction=?, net_due_amount=GREATEST(0,installment_amount-?)
        WHERE group_id=? AND month_number=? AND status='Pending'`,
        [calc.dividendPerMember, calc.dividendPerMember, data.groupId, data.auctionNumber + 1]
      );
    }
    await db.logAudit(actor.id, actor.username, "RECORD_AUCTION", "AUCTIONS", aid, null, data);
    const auction = (await db.getAuctions(data.groupId)).find((a) => a.auctionId === aid);
    const dividendRec = (await db.getDividends(data.groupId)).find((d) => d.dividendId === did);
    const prizePayment = (await db.getPrizePayments()).find((p) => p.prizePaymentId === pid);
    return { auction, dividend: dividendRec, prizePayment };
  },
  // ---- DIVIDENDS ----
  getDividends(groupId) {
    let sql = `SELECT d.*, cg.group_name
      FROM dividends d LEFT JOIN chit_groups cg ON d.group_id=cg.group_id WHERE 1=1`;
    const p = [];
    if (groupId) {
      sql += " AND d.group_id=?";
      p.push(groupId);
    }
    sql += " ORDER BY d.created_at DESC";
    return query(sql, p).then((rows) => rows.map(mapDividend));
  },
  // ---- PRIZE PAYMENTS ----
  getPrizePayments(status) {
    let sql = `SELECT pp.*, cg.group_name, c.full_name AS winner_customer_name
      FROM prize_payments pp
      LEFT JOIN chit_groups cg ON pp.group_id=cg.group_id
      LEFT JOIN customers c ON pp.winner_customer_id=c.customer_id
      WHERE 1=1`;
    const p = [];
    if (status) {
      sql += " AND pp.payment_status=?";
      p.push(status);
    }
    sql += " ORDER BY pp.created_at DESC";
    return query(sql, p).then((rows) => rows.map(mapPrizePayment));
  },
  async disbursePrize(prizePaymentId, data, actor) {
    await execute(
      `UPDATE prize_payments SET
      paid_amount=paid_amount+?,disbursal_date=?,
      payment_mode=?,transaction_reference=?,remarks=?,
      payment_status=CASE WHEN paid_amount+?>= prize_amount THEN 'Paid' ELSE 'Partially Paid' END
      WHERE prize_payment_id=?`,
      [
        data.amountToDisburse,
        data.disbursalDate ?? today(),
        data.paymentMode,
        data.transactionReference ?? null,
        data.remarks ?? null,
        data.amountToDisburse,
        prizePaymentId
      ]
    );
    await db.logAudit(actor.id, actor.username, "DISBURSE_PRIZE", "PRIZE_PAYMENTS", prizePaymentId, null, data);
    const r = await queryOne(`SELECT pp.*, cg.group_name, c.full_name AS winner_customer_name
      FROM prize_payments pp
      LEFT JOIN chit_groups cg ON pp.group_id=cg.group_id
      LEFT JOIN customers c ON pp.winner_customer_id=c.customer_id
      WHERE pp.prize_payment_id=?`, [prizePaymentId]);
    return mapPrizePayment(r);
  },
  // ---- EXPENSES ----
  getExpenses(category, startDate, endDate) {
    let sql = `SELECT e.*, u.full_name AS created_by_name
      FROM expenses e LEFT JOIN users u ON e.created_by_user_id=u.id WHERE 1=1`;
    const p = [];
    if (category) {
      sql += " AND e.category=?";
      p.push(category);
    }
    if (startDate) {
      sql += " AND e.expense_date>=?";
      p.push(startDate);
    }
    if (endDate) {
      sql += " AND e.expense_date<=?";
      p.push(endDate);
    }
    sql += " ORDER BY e.expense_date DESC";
    return query(sql, p).then((rows) => rows.map(mapExpense));
  },
  async createExpense(data, actor) {
    const countRow = await queryOne("SELECT COUNT(*) AS c FROM expenses");
    const eid = `EXP-${(/* @__PURE__ */ new Date()).getFullYear()}-${String((countRow?.c ?? 0) + 1).padStart(4, "0")}`;
    await execute(
      `INSERT INTO expenses
      (expense_id,expense_date,category,description,amount,payment_mode,reference_number,remarks,created_by_user_id)
      VALUES (?,?,?,?,?,?,?,?,?)`,
      [
        eid,
        data.expenseDate ?? today(),
        data.category,
        data.description,
        data.amount,
        data.paymentMode ?? "Cash",
        data.referenceNumber ?? null,
        data.remarks ?? null,
        actor.id
      ]
    );
    await db.logAudit(actor.id, actor.username, "CREATE_EXPENSE", "EXPENSES", eid, null, data);
    const r = await queryOne(`SELECT e.*, u.full_name AS created_by_name
      FROM expenses e LEFT JOIN users u ON e.created_by_user_id=u.id WHERE e.expense_id=?`, [eid]);
    return mapExpense(r);
  },
  // ---- REPORTS ----
  async getCollectionReport(filters) {
    let sql = `SELECT p.*, c.full_name AS customer_name, cg.group_name,
      u.full_name AS collected_by_name, m.ticket_number, i.month_number
      FROM payments p
      LEFT JOIN customers c ON p.customer_id=c.customer_id
      LEFT JOIN chit_groups cg ON p.group_id=cg.group_id
      LEFT JOIN users u ON p.collected_by_user_id=u.id
      LEFT JOIN memberships m ON p.membership_id=m.membership_id
      LEFT JOIN installments i ON p.installment_id=i.installment_id
      WHERE p.status='active'`;
    const p = [];
    if (filters.startDate) {
      sql += " AND p.payment_date>=?";
      p.push(filters.startDate);
    }
    if (filters.endDate) {
      sql += " AND p.payment_date<=?";
      p.push(filters.endDate);
    }
    if (filters.paymentMode) {
      sql += " AND p.payment_mode=?";
      p.push(filters.paymentMode);
    }
    if (filters.groupId) {
      sql += " AND p.group_id=?";
      p.push(filters.groupId);
    }
    sql += " ORDER BY p.payment_date DESC";
    const rows = await query(sql, p);
    const payments = rows.map(mapPayment);
    const totalCollected = payments.reduce((s, r) => s + r.amountPaid, 0);
    const byMode = {};
    payments.forEach((py) => {
      byMode[py.paymentMode] = (byMode[py.paymentMode] ?? 0) + py.amountPaid;
    });
    return { totalCount: payments.length, totalCollected: round2(totalCollected), byMode, payments };
  },
  async getOutstandingReport(groupId) {
    let sql = `SELECT i.*, c.full_name AS customer_name, c.mobile_number, cg.group_name, m.ticket_number
      FROM installments i
      LEFT JOIN customers c ON i.customer_id=c.customer_id
      LEFT JOIN chit_groups cg ON i.group_id=cg.group_id
      LEFT JOIN memberships m ON i.membership_id=m.membership_id
      WHERE i.status IN ('Pending','Partially Paid','Overdue') AND (i.net_due_amount - i.paid_amount) > 0`;
    const p = [];
    if (groupId && groupId !== "all") {
      sql += " AND i.group_id=?";
      p.push(groupId);
    }
    sql += " ORDER BY i.due_date ASC";
    const rows = await query(sql, p);
    const todayStr = today();
    const defaulters = rows.map((r) => {
      const isOverdue = String(r.due_date).slice(0, 10) < todayStr;
      const balanceAmount = round2(Number(r.net_due_amount || 0) - Number(r.paid_amount || 0));
      return {
        installmentId: r.installment_id,
        id: r.installment_id,
        customerId: r.customer_id,
        customerName: r.customer_name || "Subscriber",
        mobileNumber: r.mobile_number || "",
        groupName: r.group_name || r.group_id,
        ticketNumber: r.ticket_number || 1,
        monthNumber: r.month_number || 1,
        dueDate: r.due_date ? String(r.due_date).slice(0, 10) : todayStr,
        netDueAmount: Number(r.net_due_amount || 0),
        balanceAmount,
        status: isOverdue ? "Overdue" : r.status || "Pending"
      };
    });
    const totalOutstanding = round2(defaulters.reduce((s, d) => s + d.balanceAmount, 0));
    const overdueList = defaulters.filter((d) => d.status === "Overdue");
    const overdueAmount = round2(overdueList.reduce((s, d) => s + d.balanceAmount, 0));
    return {
      totalOutstanding,
      installmentsCount: defaulters.length,
      overdueCount: overdueList.length,
      overdueAmount,
      defaulters,
      records: defaulters
    };
  },
  async getChitGroupsReport() {
    const groups = await db.getChitGroups();
    return Promise.all(groups.map(async (g) => {
      const expected = await queryOne("SELECT COALESCE(SUM(net_due_amount),0) AS v FROM installments WHERE group_id=?", [g.groupId]);
      const collected = await queryOne("SELECT COALESCE(SUM(paid_amount),0) AS v FROM payments WHERE group_id=? AND status='active'", [g.groupId]);
      return { ...g, totalExpected: +(expected?.v ?? 0), totalCollected: +(collected?.v ?? 0), totalPending: round2(+(expected?.v ?? 0) - +(collected?.v ?? 0)) };
    }));
  },
  async getAuctionsReport(groupId) {
    const auctions = await db.getAuctions(groupId);
    return {
      auctions,
      totalPrizeDisbursed: round2(auctions.reduce((s, a) => s + a.prizeAmount, 0)),
      totalForemanCommission: round2(auctions.reduce((s, a) => s + a.foremanCommission, 0)),
      totalDividendDistributed: round2(auctions.reduce((s, a) => s + a.dividendAmount, 0))
    };
  },
  // ---- DASHBOARD ----
  async getDashboardStats() {
    const [
      custRow,
      groupRow,
      chitValRow,
      collectedRow,
      pendingRow,
      auctionRow,
      recentPays,
      recentCusts,
      trendRows,
      groupSummary
    ] = await Promise.all([
      queryOne("SELECT COUNT(*) AS c FROM customers WHERE status='active'"),
      queryOne("SELECT COUNT(*) AS c FROM chit_groups WHERE status='Active'"),
      queryOne("SELECT COALESCE(SUM(chit_value),0) AS v FROM chit_groups WHERE status='Active'"),
      queryOne("SELECT COALESCE(SUM(amount_paid),0) AS v FROM payments WHERE status='active'"),
      queryOne("SELECT COALESCE(SUM(net_due_amount-paid_amount),0) AS v FROM installments WHERE status IN ('Pending','Partially Paid','Overdue')"),
      queryOne("SELECT COUNT(*) AS c FROM auctions WHERE status='Scheduled'"),
      query(`SELECT p.receipt_number,p.amount_paid,p.payment_date,p.payment_mode,
        c.full_name AS customer_name, cg.group_name,
        u.full_name AS collected_by_name, m.ticket_number, i.month_number
        FROM payments p
        LEFT JOIN customers c ON p.customer_id=c.customer_id
        LEFT JOIN chit_groups cg ON p.group_id=cg.group_id
        LEFT JOIN users u ON p.collected_by_user_id=u.id
        LEFT JOIN memberships m ON p.membership_id=m.membership_id
        LEFT JOIN installments i ON p.installment_id=i.installment_id
        WHERE p.status='active' ORDER BY p.created_at DESC LIMIT 5`),
      query("SELECT * FROM customers ORDER BY created_at DESC LIMIT 5"),
      query(`SELECT DATE_FORMAT(payment_date,'%b %Y') AS month,
        SUM(amount_paid) AS collected
        FROM payments WHERE status='active' AND payment_date>=DATE_SUB(CURDATE(),INTERVAL 6 MONTH)
        GROUP BY DATE_FORMAT(payment_date,'%Y-%m') ORDER BY MIN(payment_date)`),
      query(`SELECT cg.group_name,
        COALESCE(SUM(CASE WHEN i.status='Paid' THEN i.paid_amount ELSE 0 END),0) AS collected,
        COALESCE(SUM(CASE WHEN i.status IN ('Pending','Overdue','Partially Paid') THEN (i.net_due_amount-i.paid_amount) ELSE 0 END),0) AS pending
        FROM chit_groups cg
        LEFT JOIN installments i ON cg.group_id=i.group_id
        WHERE cg.status='Active'
        GROUP BY cg.group_id,cg.group_name LIMIT 5`)
    ]);
    return {
      totalCustomers: +(custRow?.c ?? 0),
      activeChitGroups: +(groupRow?.c ?? 0),
      totalChitValue: +(chitValRow?.v ?? 0),
      monthlyCollectionExpected: 0,
      totalCollectedAmount: +(collectedRow?.v ?? 0),
      pendingAmount: +(pendingRow?.v ?? 0),
      upcomingAuctionsCount: +(auctionRow?.c ?? 0),
      recentPayments: recentPays.map(mapPayment),
      recentCustomers: recentCusts.map(mapCustomer),
      monthlyCollectionTrend: trendRows.map((r) => ({ month: r.month, collected: +(r.collected ?? 0), target: 0 })),
      pendingCollectionByGroup: groupSummary.map((r) => ({ groupName: r.group_name, pending: +(r.pending ?? 0), collected: +(r.collected ?? 0) })),
      groupPerformance: []
    };
  },
  // ---- NOTIFICATIONS ----
  // Auto-generate smart notifications from live DB data, then return all unread
  async generateNotifications() {
    const todayStr = today();
    const in3Days = /* @__PURE__ */ new Date();
    in3Days.setDate(in3Days.getDate() + 3);
    const in3DaysStr = in3Days.toISOString().split("T")[0];
    const upsertNotif = async (type, title, message, relatedId, dueDate) => {
      const existing = await queryOne(
        "SELECT id FROM notifications WHERE type=? AND related_id=? AND is_read=0",
        [type, relatedId]
      );
      if (!existing) {
        const nid = `NOTIF-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
        await execute(
          `INSERT IGNORE INTO notifications (notification_id,type,title,message,related_id,due_date,is_read)
           VALUES (?,?,?,?,?,?,0)`,
          [nid, type, title, message, relatedId, dueDate ?? null]
        );
      }
    };
    const overdueRows = await query(`
      SELECT i.installment_id, i.due_date, i.net_due_amount, i.paid_amount,
             c.full_name AS customer_name, c.mobile_number,
             cg.group_name, m.ticket_number, i.month_number
      FROM installments i
      LEFT JOIN customers c ON i.customer_id = c.customer_id
      LEFT JOIN chit_groups cg ON i.group_id = cg.group_id
      LEFT JOIN memberships m ON i.membership_id = m.membership_id
      WHERE i.status IN ('Pending','Partially Paid')
        AND i.due_date < ?
      ORDER BY i.due_date ASC
      LIMIT 30`, [todayStr]);
    for (const r of overdueRows) {
      const balance = round2(+(r.net_due_amount ?? 0) - +(r.paid_amount ?? 0));
      await upsertNotif(
        "overdue_installment",
        `Overdue: ${r.customer_name}`,
        `${r.customer_name} (${r.group_name} | Ticket #${r.ticket_number}) has overdue installment for Month #${r.month_number}. Balance \u20B9${balance.toLocaleString()} due since ${r.due_date}.`,
        r.installment_id,
        r.due_date
      );
    }
    const upcomingRows = await query(`
      SELECT i.installment_id, i.due_date, i.net_due_amount,
             c.full_name AS customer_name, c.mobile_number,
             cg.group_name, m.ticket_number, i.month_number
      FROM installments i
      LEFT JOIN customers c ON i.customer_id = c.customer_id
      LEFT JOIN chit_groups cg ON i.group_id = cg.group_id
      LEFT JOIN memberships m ON i.membership_id = m.membership_id
      WHERE i.status = 'Pending'
        AND i.due_date BETWEEN ? AND ?
      ORDER BY i.due_date ASC
      LIMIT 20`, [todayStr, in3DaysStr]);
    for (const r of upcomingRows) {
      await upsertNotif(
        "upcoming_installment",
        `Due Soon: ${r.customer_name}`,
        `${r.customer_name} (${r.group_name} | Ticket #${r.ticket_number}) has installment of \u20B9${(+(r.net_due_amount ?? 0)).toLocaleString()} due on ${r.due_date} for Month #${r.month_number}.`,
        `upcoming-${r.installment_id}`,
        r.due_date
      );
    }
    const prizeRows = await query(`
      SELECT pp.prize_payment_id, pp.prize_amount, pp.auction_number,
             c.full_name AS winner_name, cg.group_name
      FROM prize_payments pp
      LEFT JOIN customers c ON pp.winner_customer_id = c.customer_id
      LEFT JOIN chit_groups cg ON pp.group_id = cg.group_id
      WHERE pp.payment_status IN ('Pending','Partially Paid')
      LIMIT 10`);
    for (const r of prizeRows) {
      await upsertNotif(
        "pending_prize",
        `Prize Pending: ${r.winner_name}`,
        `${r.winner_name} won \u20B9${(+(r.prize_amount ?? 0)).toLocaleString()} in Auction #${r.auction_number} (${r.group_name}). Prize disbursement is pending.`,
        r.prize_payment_id
      );
    }
    const in7Days = /* @__PURE__ */ new Date();
    in7Days.setDate(in7Days.getDate() + 7);
    const auctionRows = await query(`
      SELECT cg.group_id, cg.group_name, cg.auction_day_of_month, cg.chit_value
      FROM chit_groups cg
      WHERE cg.status = 'Active'
        AND DAY(?) >= cg.auction_day_of_month - 3
      LIMIT 10`, [in7Days.toISOString().split("T")[0]]);
    for (const r of auctionRows) {
      const auctionDate = /* @__PURE__ */ new Date();
      auctionDate.setDate(r.auction_day_of_month);
      const aDateStr = auctionDate.toISOString().split("T")[0];
      await upsertNotif(
        "upcoming_auction",
        `Auction Due: ${r.group_name}`,
        `${r.group_name} has an auction scheduled around ${aDateStr} for chit value \u20B9${(+(r.chit_value ?? 0)).toLocaleString()}.`,
        `auction-${r.group_id}-${aDateStr}`,
        aDateStr
      );
    }
  },
  async getNotifications() {
    try {
      await db.generateNotifications();
    } catch {
    }
    return query("SELECT * FROM notifications ORDER BY created_at DESC LIMIT 50").then((rows) => rows.map(mapNotification));
  },
  async markNotificationRead(id) {
    await execute("UPDATE notifications SET is_read=1 WHERE id=?", [id]);
    const r = await queryOne("SELECT * FROM notifications WHERE id=?", [id]);
    return mapNotification(r);
  },
  // ---- AUDIT LOGS ----
  getAuditLogs() {
    return query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 200").then((rows) => rows.map(mapAuditLog));
  },
  async logAudit(userId, username, action, module2, recordId, oldVal, newVal) {
    try {
      await execute(
        `INSERT INTO audit_logs (user_id,username,action,module,record_id,old_value,new_value)
        VALUES (?,?,?,?,?,?,?)`,
        [
          userId,
          username,
          action,
          module2,
          recordId,
          oldVal ? JSON.stringify(oldVal) : null,
          newVal ? JSON.stringify(newVal) : null
        ]
      );
    } catch {
    }
  },
  // ---- SEARCH ----
  async search(q) {
    const like = `%${q}%`;
    const [customers, groups, memberships, payments] = await Promise.all([
      query("SELECT * FROM customers WHERE full_name LIKE ? OR mobile_number LIKE ? OR customer_id LIKE ? LIMIT 10", [like, like, like]),
      query("SELECT * FROM chit_groups WHERE group_name LIKE ? OR group_id LIKE ? LIMIT 10", [like, like]),
      query(`SELECT m.*, c.full_name AS customer_name, cg.group_name FROM memberships m
        LEFT JOIN customers c ON m.customer_id=c.customer_id
        LEFT JOIN chit_groups cg ON m.group_id=cg.group_id
        WHERE m.membership_id LIKE ? LIMIT 10`, [like]),
      query(`SELECT p.*, c.full_name AS customer_name, cg.group_name FROM payments p
        LEFT JOIN customers c ON p.customer_id=c.customer_id
        LEFT JOIN chit_groups cg ON p.group_id=cg.group_id
        WHERE p.receipt_number LIKE ? LIMIT 10`, [like])
    ]);
    return {
      customers: customers.map(mapCustomer),
      groups: groups.map(mapGroup),
      memberships: memberships.map(mapMembership),
      payments: payments.map(mapPayment)
    };
  },
  // ---- AGENT PANEL ----
  async getAgentProfile(userId) {
    let user = null;
    if (userId) {
      user = await queryOne("SELECT * FROM users WHERE id=? OR username=?", [userId, userId]);
    }
    if (!user) {
      user = await queryOne('SELECT * FROM users WHERE role="staff" OR role="admin" ORDER BY id ASC LIMIT 1');
    }
    const custRow = await queryOne('SELECT COUNT(DISTINCT customer_id) as c FROM memberships WHERE status="active"');
    const assignedCount = custRow?.c ? Number(custRow.c) : 0;
    return {
      id: user ? `agent-${user.id}` : "agent-001",
      name: user?.full_name || user?.username || "Field Agent",
      phone: "+91 98765 43210",
      area: "North Zone & Regional Field",
      assignedCustomers: assignedCount || 26
    };
  },
  async getAgentSummary(monthStr, userId, role) {
    const curDate = today();
    const curMonth = monthStr || curDate.slice(0, 7);
    const todayPay = await queryOne(`
      SELECT
        COALESCE(SUM(CASE WHEN LOWER(payment_mode) = 'cash' THEN amount_paid ELSE 0 END), 0) AS cash,
        COALESCE(SUM(CASE WHEN LOWER(payment_mode) != 'cash' THEN amount_paid ELSE 0 END), 0) AS online,
        COALESCE(SUM(amount_paid), 0) AS total,
        COUNT(DISTINCT customer_id) AS customers_collected
      FROM payments
      WHERE DATE(payment_date) = CURDATE() AND status = 'active'
    `);
    const todayInst = await queryOne(`
      SELECT
        COUNT(CASE WHEN DATE(due_date) = CURDATE() AND status != 'Paid' THEN 1 END) AS pending_today,
        COUNT(CASE WHEN DATE(due_date) < CURDATE() AND status != 'Paid' THEN 1 END) AS overdue_today
      FROM installments
    `);
    const monthPay = await queryOne(`
      SELECT COALESCE(SUM(amount_paid), 0) AS collected
      FROM payments
      WHERE DATE_FORMAT(payment_date, '%Y-%m') = ? AND status = 'active'
    `, [curMonth]);
    const monthInst = await queryOne(`
      SELECT
        COALESCE(SUM(net_due_amount), 0) AS target,
        COALESCE(SUM(CASE WHEN status != 'Paid' THEN (net_due_amount - paid_amount) ELSE 0 END), 0) AS pending_balance,
        COUNT(DISTINCT CASE WHEN status != 'Paid' THEN customer_id END) AS pending_customers,
        COUNT(CASE WHEN status = 'Paid' THEN 1 END) AS collected_inst,
        COUNT(CASE WHEN status = 'Pending' AND due_date >= CURDATE() THEN 1 END) AS pending_inst,
        COUNT(CASE WHEN status = 'Overdue' OR (status != 'Paid' AND due_date < CURDATE()) THEN 1 END) AS overdue_inst
      FROM installments
      WHERE DATE_FORMAT(due_date, '%Y-%m') = ?
    `, [curMonth]);
    const collected = Number(monthPay?.collected || 0);
    const target = Number(monthInst?.target || 0) > 0 ? Number(monthInst.target) : 35e4;
    const targetAchievedPercent = target > 0 ? Math.min(100, Math.round(collected / target * 100)) : 0;
    const remainingTargetAmount = Math.max(0, target - collected);
    const commissionRate = 0.05;
    const commissionEarned = round2(collected * commissionRate);
    return {
      todayCashCollection: Number(todayPay?.cash || 0),
      todayOnlineCollection: Number(todayPay?.online || 0),
      todayTotalCollection: Number(todayPay?.total || 0),
      todayCustomersCollected: Number(todayPay?.customers_collected || 0),
      todayPendingCollections: Number(todayInst?.pending_today || 0),
      todayOverdueCollections: Number(todayInst?.overdue_today || 0),
      monthlyCollection: collected,
      monthlyTarget: target,
      pendingBalance: Number(monthInst?.pending_balance || 0),
      pendingCustomersCount: Number(monthInst?.pending_customers || 0),
      commissionEarned,
      commissionRate,
      collectedInstallments: Number(monthInst?.collected_inst || 0),
      pendingInstallments: Number(monthInst?.pending_inst || 0),
      overdueInstallments: Number(monthInst?.overdue_inst || 0),
      remainingTargetAmount,
      targetAchievedPercent,
      month: curMonth
    };
  },
  async getAgentMonthlyTrend(userId, role) {
    const months = [];
    const nowD = /* @__PURE__ */ new Date();
    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    for (let i = 5; i >= 0; i--) {
      const d = new Date(nowD.getFullYear(), nowD.getMonth() - i, 1);
      const k = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      months.push({ key: k, label: monthNames[d.getMonth()] });
    }
    const trend = await Promise.all(
      months.map(async (m) => {
        const payRow = await queryOne(`
          SELECT COALESCE(SUM(amount_paid), 0) AS collected
          FROM payments
          WHERE DATE_FORMAT(payment_date, '%Y-%m') = ? AND status = 'active'
        `, [m.key]);
        const instRow = await queryOne(`
          SELECT COALESCE(SUM(net_due_amount), 0) AS target
          FROM installments
          WHERE DATE_FORMAT(due_date, '%Y-%m') = ?
        `, [m.key]);
        const coll = Number(payRow?.collected || 0);
        const tgt = Number(instRow?.target || 0) > 0 ? Number(instRow.target) : 35e4;
        return {
          month: m.key,
          label: m.label,
          collected: coll,
          target: tgt
        };
      })
    );
    return trend;
  },
  async getAgentCollectionSheet(filters, userId, role) {
    let sql = `
      SELECT
        i.installment_id,
        i.customer_id,
        c.full_name AS customer_name,
        COALESCE(c.mobile_number, '') AS phone,
        COALESCE(cg.group_name, i.group_id) AS chit_group_code,
        COALESCE(m.ticket_number, 1) AS ticket_number,
        i.due_date,
        i.net_due_amount AS due_installment_amount,
        i.paid_amount,
        GREATEST(0, (i.net_due_amount - i.paid_amount)) AS pending_balance,
        i.status AS raw_status,
        i.month_number AS current_installment
      FROM installments i
      LEFT JOIN customers c ON i.customer_id = c.customer_id
      LEFT JOIN memberships m ON i.membership_id = m.membership_id
      LEFT JOIN chit_groups cg ON i.group_id = cg.group_id
      WHERE 1=1
    `;
    const params = [];
    if (filters?.dateType === "today") {
      sql += ' AND (i.due_date = CURDATE() OR (i.due_date < CURDATE() AND i.status != "Paid"))';
    } else if (filters?.dateType === "custom" && filters.customDate) {
      sql += " AND i.due_date = ?";
      params.push(filters.customDate);
    }
    if (filters?.status === "paid") {
      sql += ' AND (i.status = "Paid" OR i.paid_amount >= i.net_due_amount)';
    } else if (filters?.status === "pending") {
      sql += ' AND i.status != "Paid" AND i.paid_amount < i.net_due_amount AND i.due_date >= CURDATE()';
    } else if (filters?.status === "overdue") {
      sql += ' AND i.status != "Paid" AND i.paid_amount < i.net_due_amount AND i.due_date < CURDATE()';
    }
    if (filters?.search?.trim()) {
      const q = `%${filters.search.trim()}%`;
      sql += " AND (c.full_name LIKE ? OR c.mobile_number LIKE ? OR cg.group_name LIKE ? OR i.customer_id LIKE ?)";
      params.push(q, q, q, q);
    }
    sql += " ORDER BY i.due_date DESC, i.month_number ASC LIMIT 200";
    const rows = await query(sql, params);
    const todayStr = today();
    return rows.map((r) => {
      const isPaid = r.raw_status === "Paid" || Number(r.pending_balance) <= 0;
      const isOverdue = !isPaid && String(r.due_date) < todayStr;
      const status = isPaid ? "paid" : isOverdue ? "overdue" : "pending";
      return {
        id: r.installment_id,
        customerId: r.customer_id,
        customerName: r.customer_name || "Customer",
        phone: r.phone || "",
        chitGroupCode: r.chit_group_code,
        ticketNumber: String(r.ticket_number),
        dueDate: r.due_date ? String(r.due_date).slice(0, 10) : todayStr,
        dueInstallmentAmount: Number(r.due_installment_amount || 0),
        paidAmount: Number(r.paid_amount || 0),
        pendingBalance: round2(Number(r.pending_balance || 0)),
        status,
        currentInstallment: Number(r.current_installment || 1)
      };
    });
  },
  async getAgentDueBills(userId, role) {
    const sql = `
      SELECT
        i.installment_id,
        i.customer_id,
        c.full_name AS customer_name,
        COALESCE(c.mobile_number, '') AS phone,
        COALESCE(cg.group_name, i.group_id) AS chit_group_code,
        COALESCE(m.ticket_number, 1) AS ticket_number,
        i.month_number AS current_installment,
        i.net_due_amount AS due_amount,
        i.paid_amount,
        GREATEST(0, (i.net_due_amount - i.paid_amount)) AS outstanding_balance,
        i.due_date,
        i.status AS raw_status
      FROM installments i
      LEFT JOIN customers c ON i.customer_id = c.customer_id
      LEFT JOIN memberships m ON i.membership_id = m.membership_id
      LEFT JOIN chit_groups cg ON i.group_id = cg.group_id
      WHERE i.status != 'Paid' AND (i.net_due_amount - i.paid_amount) > 0
      ORDER BY i.due_date ASC, i.month_number ASC
      LIMIT 150
    `;
    const rows = await query(sql);
    const todayStr = today();
    return rows.map((r) => {
      const isOverdue = String(r.due_date) < todayStr;
      const status = isOverdue ? "overdue" : "pending";
      const arrears = isOverdue ? round2(Number(r.outstanding_balance)) : 0;
      return {
        id: r.installment_id,
        customerId: r.customer_id,
        customerName: r.customer_name || "Customer",
        phone: r.phone || "",
        chitGroupCode: r.chit_group_code,
        ticketNumber: String(r.ticket_number),
        currentInstallment: Number(r.current_installment || 1),
        dueAmount: Number(r.due_amount || 0),
        paidAmount: Number(r.paid_amount || 0),
        outstandingBalance: round2(Number(r.outstanding_balance || 0)),
        arrears,
        dueDate: r.due_date ? String(r.due_date).slice(0, 10) : todayStr,
        status
      };
    });
  },
  async getAgentReceipts(userId, role) {
    const sql = `
      SELECT
        p.receipt_number,
        p.customer_id,
        c.full_name AS customer_name,
        COALESCE(c.mobile_number, '') AS phone,
        COALESCE(cg.group_name, p.group_id) AS chit_group_code,
        COALESCE(m.ticket_number, 1) AS ticket_number,
        p.amount_paid,
        p.payment_mode,
        p.payment_date,
        p.created_at,
        u.full_name AS agent_name,
        p.remaining_balance,
        p.remarks
      FROM payments p
      LEFT JOIN customers c ON p.customer_id = c.customer_id
      LEFT JOIN chit_groups cg ON p.group_id = cg.group_id
      LEFT JOIN memberships m ON p.membership_id = m.membership_id
      LEFT JOIN users u ON p.collected_by_user_id = u.id
      ORDER BY p.payment_date DESC, p.created_at DESC
      LIMIT 150
    `;
    const rows = await query(sql);
    return rows.map((r) => ({
      receiptNumber: r.receipt_number,
      customerId: r.customer_id,
      customerName: r.customer_name || "Customer",
      phone: r.phone || "",
      chitGroupCode: r.chit_group_code,
      ticketNumber: String(r.ticket_number),
      amountCollected: Number(r.amount_paid),
      paymentMethod: String(r.payment_mode || "").toLowerCase() === "cash" ? "cash" : "online",
      collectedAt: r.created_at ? new Date(r.created_at).toISOString() : `${r.payment_date}T12:00:00`,
      agentName: r.agent_name || "Field Agent",
      remainingBalance: Number(r.remaining_balance || 0),
      notes: r.remarks || void 0
    }));
  },
  async collectAgentPayment(data, actor) {
    let installment = null;
    if (data.installmentId) {
      installment = await db.getInstallmentById(data.installmentId);
    }
    if (!installment) {
      const row = await queryOne(`
        SELECT installment_id FROM installments
        WHERE customer_id = ? AND (status != 'Paid' OR paid_amount < net_due_amount)
        ORDER BY due_date ASC, month_number ASC
        LIMIT 1
      `, [data.customerId]);
      if (row?.installment_id) {
        installment = await db.getInstallmentById(row.installment_id);
      }
    }
    if (!installment) {
      const row = await queryOne(`
        SELECT installment_id FROM installments WHERE customer_id = ? ORDER BY due_date DESC LIMIT 1
      `, [data.customerId]);
      if (row?.installment_id) {
        installment = await db.getInstallmentById(row.installment_id);
      }
    }
    if (!installment) {
      throw new Error("No active membership or installment found for customer.");
    }
    const paymentResult = await db.recordPayment(
      {
        installmentId: installment.installmentId,
        amountPaid: data.amount,
        paymentMode: data.paymentMethod === "online" ? "Online" : "Cash",
        paymentDate: today(),
        remarks: data.notes || "Field collection by agent"
      },
      actor
    );
    const customer = await db.getCustomerById(data.customerId);
    const agentReceipt = {
      receiptNumber: paymentResult.payment.receiptNumber,
      customerId: data.customerId,
      customerName: paymentResult.payment.customerName || customer?.fullName || "Customer",
      phone: customer?.mobileNumber || "",
      chitGroupCode: paymentResult.payment.groupName || paymentResult.payment.groupId,
      ticketNumber: String(paymentResult.payment.ticketNumber || 1),
      amountCollected: Number(paymentResult.payment.amountPaid),
      paymentMethod: paymentResult.payment.paymentMode?.toLowerCase() === "cash" ? "cash" : "online",
      collectedAt: (/* @__PURE__ */ new Date()).toISOString(),
      agentName: actor.fullName || actor.username || "Field Agent",
      remainingBalance: Number(paymentResult.payment.remainingBalance || 0),
      notes: data.notes || void 0
    };
    return {
      payment: {
        id: paymentResult.payment.receiptNumber,
        customerId: data.customerId,
        amount: Number(paymentResult.payment.amountPaid),
        paymentMethod: agentReceipt.paymentMethod,
        collectedAt: agentReceipt.collectedAt,
        receiptNumber: agentReceipt.receiptNumber,
        notes: data.notes
      },
      receipt: agentReceipt
    };
  },
  // ---- NEW MODULES: DAILY, MONTHLY, BALANCE SHEET ----
  async getDailyCollection(dateStr, userId, role) {
    const targetDate = dateStr || today();
    let sql = `
      SELECT 
        p.receipt_number,
        p.amount_paid,
        p.payment_mode,
        p.payment_date,
        p.created_at,
        c.customer_id,
        c.full_name AS customer_name,
        cg.group_name,
        u.full_name AS agent_name,
        u.id AS agent_id
      FROM payments p
      LEFT JOIN customers c ON p.customer_id = c.customer_id
      LEFT JOIN chit_groups cg ON p.group_id = cg.group_id
      LEFT JOIN users u ON p.collected_by_user_id = u.id
      WHERE (LEFT(p.payment_date, 10) = ? OR LEFT(p.created_at, 10) = ? OR DATE(p.payment_date) = ?) AND p.status = 'active'
    `;
    const params = [targetDate, targetDate, targetDate];
    if (role === "agent" && userId) {
      sql += ` AND (p.collected_by_user_id = ? OR c.assigned_agent_id = ?)`;
      params.push(userId, userId);
    }
    sql += ` ORDER BY p.created_at DESC`;
    const rows = await query(sql, params);
    let totalCash = 0;
    let totalOnline = 0;
    const transactions = rows.map((r) => {
      const amt = Number(r.amount_paid || 0);
      const isCash = String(r.payment_mode || "").toLowerCase() === "cash";
      if (isCash) totalCash += amt;
      else totalOnline += amt;
      const dateObj = new Date(r.created_at || r.payment_date);
      const commission = round2(amt * 0.05);
      return {
        id: r.receipt_number,
        customerId: r.customer_id,
        customerName: r.customer_name || "Unknown",
        groupName: r.group_name || "Unknown",
        amount: amt,
        paymentMode: r.payment_mode,
        date: dateObj.toISOString().split("T")[0],
        time: dateObj.toTimeString().split(" ")[0],
        day: dateObj.toLocaleDateString("en-US", { weekday: "long" }),
        agentName: r.agent_name || "N/A",
        commission
      };
    });
    return {
      date: targetDate,
      totalCollected: totalCash + totalOnline,
      totalCash,
      totalOnline,
      transactions,
      commissionEarned: round2((totalCash + totalOnline) * 0.05)
    };
  },
  async getMonthlyCollection(monthStr, userId, role) {
    const targetMonth = monthStr || today().slice(0, 7);
    let sql = `
      SELECT 
        p.receipt_number,
        p.amount_paid,
        p.payment_mode,
        p.payment_date,
        p.created_at,
        c.customer_id,
        c.full_name AS customer_name,
        cg.group_name,
        u.full_name AS agent_name,
        i.net_due_amount,
        (i.net_due_amount - i.paid_amount) AS outstanding
      FROM payments p
      LEFT JOIN customers c ON p.customer_id = c.customer_id
      LEFT JOIN chit_groups cg ON p.group_id = cg.group_id
      LEFT JOIN users u ON p.collected_by_user_id = u.id
      LEFT JOIN installments i ON p.installment_id = i.installment_id
      WHERE (LEFT(p.payment_date, 7) = ? OR LEFT(p.created_at, 7) = ? OR DATE_FORMAT(p.payment_date, '%Y-%m') = ?) AND p.status = 'active'
    `;
    const params = [targetMonth, targetMonth, targetMonth];
    if (role === "agent" && userId) {
      sql += ` AND (p.collected_by_user_id = ? OR c.assigned_agent_id = ?)`;
      params.push(userId, userId);
    }
    sql += ` ORDER BY p.payment_date DESC`;
    const rows = await query(sql, params);
    let totalCollected = 0;
    const transactions = rows.map((r) => {
      const amt = Number(r.amount_paid || 0);
      totalCollected += amt;
      const dateObj = new Date(r.created_at || r.payment_date);
      return {
        id: r.receipt_number,
        customerId: r.customer_id,
        customerName: r.customer_name || "Unknown",
        groupName: r.group_name || "Unknown",
        amountPaid: amt,
        paymentMode: r.payment_mode,
        date: dateObj.toISOString().split("T")[0],
        time: dateObj.toTimeString().split(" ")[0],
        day: dateObj.toLocaleDateString("en-US", { weekday: "long" }),
        agentName: r.agent_name || "N/A",
        dueAmount: Number(r.net_due_amount || 0),
        outstandingBalance: Math.max(0, Number(r.outstanding || 0)),
        commission: round2(amt * 0.05)
      };
    });
    return {
      month: targetMonth,
      totalCollected,
      transactions,
      commissionEarned: round2(totalCollected * 0.05)
    };
  },
  async getBalanceSheet(userId, role) {
    let sql = `
      SELECT 
        i.installment_id,
        i.customer_id,
        c.full_name AS customer_name,
        cg.group_name,
        i.net_due_amount,
        i.paid_amount,
        i.due_date,
        i.status
      FROM installments i
      LEFT JOIN customers c ON i.customer_id = c.customer_id
      LEFT JOIN chit_groups cg ON i.group_id = cg.group_id
      WHERE i.status != 'Paid'
    `;
    const params = [];
    if (role === "agent" && userId) {
      sql += ` AND c.assigned_agent_id = ?`;
      params.push(userId);
    }
    sql += ` ORDER BY i.due_date ASC`;
    const rows = await query(sql, params);
    let totalOutstanding = 0;
    let totalArrears = 0;
    const todayStr = today();
    const pendingInstallments = rows.map((r) => {
      const due = Number(r.net_due_amount || 0);
      const paid = Number(r.paid_amount || 0);
      const outstanding = Math.max(0, due - paid);
      const isOverdue = String(r.due_date).slice(0, 10) < todayStr;
      totalOutstanding += outstanding;
      if (isOverdue) totalArrears += outstanding;
      return {
        id: r.installment_id,
        customerId: r.customer_id,
        customerName: r.customer_name || "Unknown",
        groupName: r.group_name || "Unknown",
        dueAmount: due,
        paidAmount: paid,
        outstandingBalance: outstanding,
        dueDate: r.due_date,
        isOverdue,
        overdueStatus: isOverdue ? "Overdue" : "Pending",
        arrears: isOverdue ? outstanding : 0,
        day: new Date(r.due_date).toLocaleDateString("en-US", { weekday: "long" })
      };
    });
    return {
      totalOutstanding: round2(totalOutstanding),
      totalArrears: round2(totalArrears),
      records: pendingInstallments
    };
  },
  // ---- DELETE & UPDATE HELPERS ----
  async deleteCustomer(id, operator) {
    await execute(`DELETE FROM customers WHERE customer_id = ? OR id = ?`, [id, id]);
    if (operator) {
      await this.logAudit(operator.id, operator.username, "DELETE_CUSTOMER", "CUSTOMERS", id, null, { customerId: id });
    }
    return { message: "Customer deleted successfully" };
  },
  async deleteChitGroup(id, operator) {
    await execute(`DELETE FROM chit_groups WHERE group_id = ? OR id = ?`, [id, id]);
    if (operator) {
      await this.logAudit(operator.id, operator.username, "DELETE_CHIT_GROUP", "CHIT_GROUPS", id, null, { groupId: id });
    }
    return { message: "Chit group deleted successfully" };
  },
  async updateMembership(id, data, operator) {
    if (data.ticketNumber !== void 0) {
      await execute(`UPDATE memberships SET ticket_number = ? WHERE membership_id = ? OR id = ?`, [data.ticketNumber, id, id]);
    }
    if (data.status !== void 0) {
      await execute(`UPDATE memberships SET status = ? WHERE membership_id = ? OR id = ?`, [data.status, id, id]);
    }
    if (operator) {
      await this.logAudit(operator.id, operator.username, "UPDATE_MEMBERSHIP", "MEMBERSHIPS", id, null, data);
    }
    return { message: "Membership updated successfully" };
  },
  async deleteMembership(id, operator) {
    await execute(`DELETE FROM memberships WHERE membership_id = ? OR id = ?`, [id, id]);
    if (operator) {
      await this.logAudit(operator.id, operator.username, "DELETE_MEMBERSHIP", "MEMBERSHIPS", id, null, { membershipId: id });
    }
    return { message: "Membership deleted successfully" };
  },
  async updateInstallment(id, data, operator) {
    const fields = [];
    const params = [];
    if (data.installmentAmount !== void 0) {
      fields.push("installment_amount = ?");
      params.push(data.installmentAmount);
    }
    if (data.dividendDeduction !== void 0) {
      fields.push("dividend_deduction = ?");
      params.push(data.dividendDeduction);
    }
    if (data.netDueAmount !== void 0) {
      fields.push("net_due_amount = ?");
      params.push(data.netDueAmount);
    }
    if (data.paidAmount !== void 0) {
      fields.push("paid_amount = ?");
      params.push(data.paidAmount);
    }
    if (data.dueDate !== void 0) {
      fields.push("due_date = ?");
      params.push(data.dueDate);
    }
    if (data.status !== void 0) {
      fields.push("status = ?");
      params.push(data.status);
    }
    if (data.remarks !== void 0) {
      fields.push("remarks = ?");
      params.push(data.remarks);
    }
    if (fields.length > 0) {
      params.push(id, id);
      await execute(`UPDATE installments SET ${fields.join(", ")} WHERE installment_id = ? OR id = ?`, params);
    }
    if (operator) {
      await this.logAudit(operator.id, operator.username, "UPDATE_INSTALLMENT", "INSTALLMENTS", id, null, data);
    }
    return { message: "Installment updated successfully" };
  },
  async deleteInstallment(id, operator) {
    await execute(`DELETE FROM installments WHERE installment_id = ? OR id = ?`, [id, id]);
    if (operator) {
      await this.logAudit(operator.id, operator.username, "DELETE_INSTALLMENT", "INSTALLMENTS", id, null, { installmentId: id });
    }
    return { message: "Installment deleted successfully" };
  },
  async updatePayment(id, data, operator) {
    const fields = [];
    const params = [];
    if (data.amountPaid !== void 0) {
      fields.push("amount_paid = ?");
      params.push(data.amountPaid);
    }
    if (data.paymentMode !== void 0) {
      fields.push("payment_mode = ?");
      params.push(data.paymentMode);
    }
    if (data.transactionReference !== void 0) {
      fields.push("transaction_reference = ?");
      params.push(data.transactionReference);
    }
    if (data.paymentDate !== void 0) {
      fields.push("payment_date = ?");
      params.push(data.paymentDate);
    }
    if (data.remarks !== void 0) {
      fields.push("remarks = ?");
      params.push(data.remarks);
    }
    if (data.status !== void 0) {
      fields.push("status = ?");
      params.push(data.status);
    }
    if (fields.length > 0) {
      params.push(id, id);
      await execute(`UPDATE payments SET ${fields.join(", ")} WHERE receipt_number = ? OR id = ?`, params);
    }
    if (operator) {
      await this.logAudit(operator.id, operator.username, "UPDATE_PAYMENT", "PAYMENTS", id, null, data);
    }
    return { message: "Payment updated successfully" };
  },
  async deletePayment(id, operator) {
    await execute(`DELETE FROM payments WHERE receipt_number = ? OR id = ?`, [id, id]);
    if (operator) {
      await this.logAudit(operator.id, operator.username, "DELETE_PAYMENT", "PAYMENTS", id, null, { receiptNumber: id });
    }
    return { message: "Payment deleted successfully" };
  },
  async updateAuction(id, data, operator) {
    const fields = [];
    const params = [];
    if (data.auctionDate !== void 0) {
      fields.push("auction_date = ?");
      params.push(data.auctionDate);
    }
    if (data.bidDiscountAmount !== void 0) {
      fields.push("bid_discount_amount = ?");
      params.push(data.bidDiscountAmount);
    }
    if (data.prizeAmount !== void 0) {
      fields.push("prize_amount = ?");
      params.push(data.prizeAmount);
    }
    if (data.foremanCommission !== void 0) {
      fields.push("foreman_commission = ?");
      params.push(data.foremanCommission);
    }
    if (data.winnerMembershipId !== void 0) {
      fields.push("winner_membership_id = ?");
      params.push(data.winnerMembershipId);
    }
    if (data.remarks !== void 0) {
      fields.push("remarks = ?");
      params.push(data.remarks);
    }
    if (fields.length > 0) {
      params.push(id, id);
      await execute(`UPDATE auctions SET ${fields.join(", ")} WHERE auction_id = ? OR id = ?`, params);
    }
    if (operator) {
      await this.logAudit(operator.id, operator.username, "UPDATE_AUCTION", "AUCTIONS", id, null, data);
    }
    return { message: "Auction updated successfully" };
  },
  async deleteAuction(id, operator) {
    await execute(`DELETE FROM auctions WHERE auction_id = ? OR id = ?`, [id, id]);
    if (operator) {
      await this.logAudit(operator.id, operator.username, "DELETE_AUCTION", "AUCTIONS", id, null, { auctionId: id });
    }
    return { message: "Auction deleted successfully" };
  },
  async updateDividend(id, data, operator) {
    const fields = [];
    const params = [];
    if (data.totalDiscount !== void 0) {
      fields.push("total_discount = ?");
      params.push(data.totalDiscount);
    }
    if (data.foremanCommission !== void 0) {
      fields.push("foreman_commission = ?");
      params.push(data.foremanCommission);
    }
    if (data.distributableDividend !== void 0) {
      fields.push("distributable_dividend = ?");
      params.push(data.distributableDividend);
    }
    if (data.dividendPerMember !== void 0) {
      fields.push("dividend_per_member = ?");
      params.push(data.dividendPerMember);
    }
    if (fields.length > 0) {
      params.push(id, id);
      await execute(`UPDATE dividends SET ${fields.join(", ")} WHERE dividend_id = ? OR id = ?`, params);
    }
    if (operator) {
      await this.logAudit(operator.id, operator.username, "UPDATE_DIVIDEND", "DIVIDENDS", id, null, data);
    }
    return { message: "Dividend updated successfully" };
  },
  async deleteDividend(id, operator) {
    await execute(`DELETE FROM dividends WHERE dividend_id = ? OR id = ?`, [id, id]);
    if (operator) {
      await this.logAudit(operator.id, operator.username, "DELETE_DIVIDEND", "DIVIDENDS", id, null, { dividendId: id });
    }
    return { message: "Dividend deleted successfully" };
  },
  async updatePrizePayment(id, data, operator) {
    const fields = [];
    const params = [];
    if (data.prizeAmount !== void 0) {
      fields.push("prize_amount = ?");
      params.push(data.prizeAmount);
    }
    if (data.paidAmount !== void 0) {
      fields.push("paid_amount = ?");
      params.push(data.paidAmount);
    }
    if (data.paymentStatus !== void 0) {
      fields.push("payment_status = ?");
      params.push(data.paymentStatus);
    }
    if (data.remarks !== void 0) {
      fields.push("remarks = ?");
      params.push(data.remarks);
    }
    if (fields.length > 0) {
      params.push(id, id);
      await execute(`UPDATE prize_payments SET ${fields.join(", ")} WHERE prize_payment_id = ? OR id = ?`, params);
    }
    if (operator) {
      await this.logAudit(operator.id, operator.username, "UPDATE_PRIZE_PAYMENT", "PRIZE_PAYMENTS", id, null, data);
    }
    return { message: "Prize payment updated successfully" };
  },
  async deletePrizePayment(id, operator) {
    await execute(`DELETE FROM prize_payments WHERE prize_payment_id = ? OR id = ?`, [id, id]);
    if (operator) {
      await this.logAudit(operator.id, operator.username, "DELETE_PRIZE_PAYMENT", "PRIZE_PAYMENTS", id, null, { prizePaymentId: id });
    }
    return { message: "Prize payment deleted successfully" };
  },
  async updateExpense(id, data, operator) {
    const fields = [];
    const params = [];
    if (data.expenseDate !== void 0) {
      fields.push("expense_date = ?");
      params.push(data.expenseDate);
    }
    if (data.category !== void 0) {
      fields.push("category = ?");
      params.push(data.category);
    }
    if (data.description !== void 0) {
      fields.push("description = ?");
      params.push(data.description);
    }
    if (data.amount !== void 0) {
      fields.push("amount = ?");
      params.push(data.amount);
    }
    if (data.paymentMode !== void 0) {
      fields.push("payment_mode = ?");
      params.push(data.paymentMode);
    }
    if (data.referenceNumber !== void 0) {
      fields.push("reference_number = ?");
      params.push(data.referenceNumber);
    }
    if (data.remarks !== void 0) {
      fields.push("remarks = ?");
      params.push(data.remarks);
    }
    if (fields.length > 0) {
      params.push(id, id);
      await execute(`UPDATE expenses SET ${fields.join(", ")} WHERE expense_id = ? OR id = ?`, params);
    }
    if (operator) {
      await this.logAudit(operator.id, operator.username, "UPDATE_EXPENSE", "EXPENSES", id, null, data);
    }
    return { message: "Expense updated successfully" };
  },
  async deleteExpense(id, operator) {
    await execute(`DELETE FROM expenses WHERE expense_id = ? OR id = ?`, [id, id]);
    if (operator) {
      await this.logAudit(operator.id, operator.username, "DELETE_EXPENSE", "EXPENSES", id, null, { expenseId: id });
    }
    return { message: "Expense deleted successfully" };
  },
  async deleteUser(id, operator) {
    await execute(`DELETE FROM users WHERE id = ?`, [id]);
    if (operator) {
      await this.logAudit(operator.id, operator.username, "DELETE_USER", "USERS", String(id), null, { targetUserId: id });
    }
    return { message: "User deleted successfully" };
  },
  async updateAuditLog(id, data, operator) {
    if (data.action !== void 0 || data.details !== void 0) {
      await execute(`UPDATE audit_logs SET action = COALESCE(?, action), details = COALESCE(?, details) WHERE id = ?`, [data.action || null, data.details || null, id]);
    }
    return { message: "Audit log updated successfully" };
  },
  async deleteAuditLog(id, operator) {
    await execute(`DELETE FROM audit_logs WHERE id = ?`, [id]);
    return { message: "Audit log deleted successfully" };
  },
  async getChitBookingList() {
    const sql = `
      SELECT 
        m.membership_id,
        m.customer_id,
        m.group_id,
        m.ticket_number,
        c.full_name AS name,
        c.mobile_number AS phone_number,
        cg.group_name,
        cg.chit_value,
        cg.duration_months AS month
      FROM memberships m
      JOIN customers c ON m.customer_id = c.customer_id
      JOIN chit_groups cg ON m.group_id = cg.group_id
      ORDER BY m.group_id ASC, m.ticket_number ASC, m.created_at ASC
    `;
    const rows = await query(sql);
    return rows.map((r, index) => {
      let groupCode = r.group_id;
      if (!groupCode.includes("/")) {
        groupCode = `${r.group_id}/001`;
      }
      const formattedTicket = String(r.ticket_number).padStart(2, "0");
      const newGroupNo = `${groupCode}/${formattedTicket}`;
      const val = Number(r.chit_value);
      const chitValueDisplay = val >= 1e5 ? val / 1e5 : val;
      return {
        sNo: index + 1,
        newGroupNo,
        name: r.name,
        phoneNumber: r.phone_number,
        chitValue: chitValueDisplay,
        month: Number(r.month),
        customerId: r.customer_id,
        groupId: r.group_id,
        membershipId: r.membership_id
      };
    });
  }
};

// server/auth.ts
var import_crypto2 = __toESM(require("crypto"), 1);
var JWT_SECRET = process.env.JWT_SECRET || "chitfund-secure-jwt-secret-key-2026";
function createToken(user) {
  const payload = {
    id: user.id,
    username: user.username,
    role: user.role,
    exp: Date.now() + 7 * 24 * 60 * 60 * 1e3
    // 7 days
  };
  const payloadStr = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const signature = import_crypto2.default.createHmac("sha256", JWT_SECRET).update(payloadStr).digest("base64url");
  return `${payloadStr}.${signature}`;
}
function verifyToken(token) {
  try {
    const [payloadStr, signature] = token.split(".");
    if (!payloadStr || !signature) return null;
    const expectedSignature = import_crypto2.default.createHmac("sha256", JWT_SECRET).update(payloadStr).digest("base64url");
    if (signature !== expectedSignature) return null;
    const payload = JSON.parse(Buffer.from(payloadStr, "base64url").toString("utf-8"));
    if (payload.exp && Date.now() > payload.exp) return null;
    return payload;
  } catch {
    return null;
  }
}
function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Authentication required. Please log in." });
  }
  const token = authHeader.split(" ")[1];
  const payload = verifyToken(token);
  if (!payload) {
    return res.status(401).json({ error: "Session expired or invalid token. Please log in again." });
  }
  db.getUserById(payload.id).then((user) => {
    if (!user || user.status !== "active") {
      return res.status(401).json({ error: "User account is inactive or not found." });
    }
    const { passwordHash: _, ...safeUser } = user;
    req.user = safeUser;
    next();
  }).catch(() => {
    res.status(500).json({ error: "Authentication error. Please try again." });
  });
}
function requireAdmin(req, res, next) {
  if (!req.user || req.user.role !== "admin") {
    return res.status(403).json({ error: "Access denied. Administrator privileges required." });
  }
  next();
}

// server/api.ts
var import_crypto3 = __toESM(require("crypto"), 1);
var apiRouter = (0, import_express.Router)();
apiRouter.post("/auth/login", async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password)
      return res.status(400).json({ error: "Username and password are required" });
    const user = await db.getUserByUsername(username);
    if (!user) return res.status(401).json({ error: "Invalid username or password" });
    const sha256Hash = import_crypto3.default.createHash("sha256").update(password).digest("hex");
    let valid = user.passwordHash === sha256Hash;
    if (!valid && user.passwordHash.startsWith("$2")) {
      const bcrypt = await import("bcryptjs").catch(() => null);
      if (bcrypt) valid = await bcrypt.compare(password, user.passwordHash.replace("$2y$", "$2b$"));
    }
    if (!valid) return res.status(401).json({ error: "Invalid username or password" });
    if (user.status !== "active") return res.status(403).json({ error: "Account deactivated. Contact administrator." });
    try {
      await db.updateLastLogin(user.id);
    } catch (e) {
    }
    try {
      await db.logAudit(user.id, user.username, "USER_LOGIN", "AUTH", String(user.id), null, { ip: req.ip });
    } catch (e) {
    }
    const { passwordHash: _, ...safeUser } = user;
    const token = createToken(safeUser);
    res.json({ message: "Login successful", token, user: safeUser });
  } catch (err) {
    res.status(500).json({ error: err.message || "Server error during login" });
  }
});
apiRouter.get("/auth/me", requireAuth, (req, res) => {
  res.json({ user: req.user });
});
apiRouter.get("/dashboard/stats", requireAuth, async (_req, res) => {
  try {
    res.json(await db.getDashboardStats());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
apiRouter.get("/customers", requireAuth, async (req, res) => {
  try {
    const { q, status } = req.query;
    res.json(await db.getCustomers(q, status));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
apiRouter.get("/customers/:id", requireAuth, async (req, res) => {
  try {
    const customer = await db.getCustomerById(req.params.id);
    if (!customer) return res.status(404).json({ error: "Customer not found" });
    const [memberships, payments, installments] = await Promise.all([
      db.getMemberships(void 0, customer.customerId),
      db.getPayments({ customerId: customer.customerId }),
      db.getInstallments({ customerId: customer.customerId })
    ]);
    res.json({ customer, memberships, payments, installments });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
apiRouter.post("/customers", requireAuth, async (req, res) => {
  try {
    const { fullName, mobileNumber } = req.body;
    if (!fullName || !mobileNumber)
      return res.status(400).json({ error: "Please provide all required customer fields." });
    res.status(201).json(await db.createCustomer(req.body, req.user));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.put("/customers/:id", requireAuth, async (req, res) => {
  try {
    res.json(await db.updateCustomer(req.params.id, req.body, req.user));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.delete("/customers/:id", requireAuth, async (req, res) => {
  try {
    res.json(await db.deleteCustomer(req.params.id, req.user));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.get("/chit-groups", requireAuth, async (req, res) => {
  try {
    res.json(await db.getChitGroups(req.query.status));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
apiRouter.get("/chit-groups/:id", requireAuth, async (req, res) => {
  try {
    const group = await db.getChitGroupById(req.params.id);
    if (!group) return res.status(404).json({ error: "Chit group not found" });
    const [members, auctions] = await Promise.all([
      db.getMemberships(group.groupId),
      db.getAuctions(group.groupId)
    ]);
    res.json({ group, members, auctions });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
apiRouter.post("/chit-groups", requireAuth, requireAdmin, async (req, res) => {
  try {
    const { groupId, groupName, chitValue, numMembers, durationMonths, startDate } = req.body;
    if (!groupId || !groupName || !chitValue || !numMembers || !durationMonths || !startDate)
      return res.status(400).json({ error: "Missing required chit group details" });
    const data = {
      ...req.body,
      groupId: req.body.groupId?.trim().toUpperCase(),
      chitValue: Number(req.body.chitValue),
      numMembers: Number(req.body.numMembers),
      durationMonths: Number(req.body.durationMonths),
      auctionDayOfMonth: Number(req.body.auctionDayOfMonth) || 10,
      foremanCommissionPercent: Number(req.body.foremanCommissionPercent) || 5
    };
    res.status(201).json(await db.createChitGroup(data, req.user));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.put("/chit-groups/:id", requireAuth, requireAdmin, async (req, res) => {
  try {
    res.json(await db.updateChitGroup(req.params.id, req.body, req.user));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.delete("/chit-groups/:id", requireAuth, requireAdmin, async (req, res) => {
  try {
    res.json(await db.deleteChitGroup(req.params.id, req.user));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.get("/memberships", requireAuth, async (req, res) => {
  try {
    const { groupId, customerId } = req.query;
    res.json(await db.getMemberships(groupId, customerId));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
apiRouter.post("/memberships", requireAuth, async (req, res) => {
  try {
    const { customerId, groupId } = req.body;
    if (!customerId || !groupId)
      return res.status(400).json({ error: "Customer ID and Chit Group ID are required" });
    res.status(201).json(await db.createMembership(req.body, req.user));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.put("/memberships/:id", requireAuth, async (req, res) => {
  try {
    res.json(await db.updateMembership(req.params.id, req.body, req.user));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.delete("/memberships/:id", requireAuth, async (req, res) => {
  try {
    res.json(await db.deleteMembership(req.params.id, req.user));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.get("/installments", requireAuth, async (req, res) => {
  try {
    const { customerId, groupId, membershipId, status } = req.query;
    res.json(await db.getInstallments({ customerId, groupId, membershipId, status }));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
apiRouter.get("/installments/:id", requireAuth, async (req, res) => {
  try {
    const inst = await db.getInstallmentById(req.params.id);
    if (!inst) return res.status(404).json({ error: "Installment not found" });
    res.json(inst);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
apiRouter.put("/installments/:id", requireAuth, async (req, res) => {
  try {
    res.json(await db.updateInstallment(req.params.id, req.body, req.user));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.delete("/installments/:id", requireAuth, async (req, res) => {
  try {
    res.json(await db.deleteInstallment(req.params.id, req.user));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.get("/payments", requireAuth, async (req, res) => {
  try {
    const { customerId, groupId, membershipId, status } = req.query;
    res.json(await db.getPayments({ customerId, groupId, membershipId, status }));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
apiRouter.post("/payments", requireAuth, async (req, res) => {
  try {
    const { installmentId, amountPaid, paymentMode, paymentDate } = req.body;
    if (!installmentId || !amountPaid || !paymentMode || !paymentDate)
      return res.status(400).json({ error: "Installment ID, amount, payment mode, and date are required" });
    const result = await db.recordPayment({ ...req.body, amountPaid: Number(amountPaid) }, req.user);
    res.status(201).json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.put("/payments/:id", requireAuth, async (req, res) => {
  try {
    res.json(await db.updatePayment(req.params.id, req.body, req.user));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.delete("/payments/:id", requireAuth, async (req, res) => {
  try {
    res.json(await db.deletePayment(req.params.id, req.user));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.get("/payments/:id", requireAuth, async (req, res) => {
  try {
    const payment = await db.getPaymentById(req.params.id);
    if (!payment) return res.status(404).json({ error: "Payment not found" });
    const [settings, installment] = await Promise.all([db.getSettings(), db.getInstallmentById(payment.installmentId)]);
    const receipt = {
      receiptNumber: payment.receiptNumber,
      paymentDate: payment.paymentDate,
      companyName: settings.companyName,
      companyAddress: settings.address,
      companyPhone: settings.phone,
      companyEmail: settings.email,
      currencySymbol: settings.currencySymbol,
      customerId: payment.customerId,
      customerName: payment.customerName || "",
      customerMobile: "",
      groupId: payment.groupId,
      groupName: payment.groupName || "",
      membershipId: payment.membershipId,
      ticketNumber: payment.ticketNumber || 0,
      monthNumber: payment.monthNumber || 1,
      installmentAmount: installment?.installmentAmount || payment.amountPaid,
      dividendDeduction: installment?.dividendDeduction || 0,
      netDueAmount: installment?.netDueAmount || payment.amountPaid,
      amountPaid: payment.amountPaid,
      previousBalance: payment.previousBalance,
      remainingBalance: payment.remainingBalance,
      paymentMode: payment.paymentMode,
      transactionReference: payment.transactionReference,
      collectedByName: payment.collectedByName || "Authorized Staff",
      remarks: payment.remarks
    };
    res.json({ payment, receipt });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
apiRouter.post("/payments/:id/reverse", requireAuth, requireAdmin, async (req, res) => {
  try {
    const { reason } = req.body;
    if (!reason?.trim()) return res.status(400).json({ error: "Reversal reason is required" });
    const result = await db.reversePayment(req.params.id, reason.trim(), req.user);
    res.json({ ...result, message: "Payment successfully reversed" });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.get("/auctions", requireAuth, async (req, res) => {
  try {
    res.json(await db.getAuctions(req.query.groupId));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
apiRouter.post("/auctions/calculate", requireAuth, async (req, res) => {
  try {
    const { chitValue, bidDiscountAmount, numMembers, commissionPercent } = req.body;
    if (!chitValue || !bidDiscountAmount || !numMembers)
      return res.status(400).json({ error: "Chit value, bid discount amount, and members count are required" });
    res.json(await db.calculateAuction({ chitValue: Number(chitValue), bidDiscountAmount: Number(bidDiscountAmount), numMembers: Number(numMembers), commissionPercent: commissionPercent ? Number(commissionPercent) : 5 }));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.post("/auctions", requireAuth, requireAdmin, async (req, res) => {
  try {
    const { groupId, auctionNumber, auctionDate, bidDiscountAmount, winnerMembershipId } = req.body;
    if (!groupId || !auctionNumber || !auctionDate || !bidDiscountAmount || !winnerMembershipId)
      return res.status(400).json({ error: "Missing required auction fields" });
    const result = await db.recordAuction({ ...req.body, auctionNumber: Number(auctionNumber), bidDiscountAmount: Number(bidDiscountAmount) }, req.user);
    res.status(201).json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.put("/auctions/:id", requireAuth, requireAdmin, async (req, res) => {
  try {
    res.json(await db.updateAuction(req.params.id, req.body, req.user));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.delete("/auctions/:id", requireAuth, requireAdmin, async (req, res) => {
  try {
    res.json(await db.deleteAuction(req.params.id, req.user));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.get("/dividends", requireAuth, async (req, res) => {
  try {
    res.json(await db.getDividends(req.query.groupId));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
apiRouter.put("/dividends/:id", requireAuth, requireAdmin, async (req, res) => {
  try {
    res.json(await db.updateDividend(req.params.id, req.body, req.user));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.delete("/dividends/:id", requireAuth, requireAdmin, async (req, res) => {
  try {
    res.json(await db.deleteDividend(req.params.id, req.user));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.get("/prize-payments", requireAuth, async (req, res) => {
  try {
    res.json(await db.getPrizePayments(req.query.status));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
apiRouter.put("/prize-payments/:id/disburse", requireAuth, requireAdmin, async (req, res) => {
  try {
    const { amountToDisburse, disbursalDate, paymentMode } = req.body;
    if (!amountToDisburse || !disbursalDate || !paymentMode)
      return res.status(400).json({ error: "Amount, disbursal date, and payment mode are required" });
    res.json(await db.disbursePrize(req.params.id, { ...req.body, amountToDisburse: Number(amountToDisburse) }, req.user));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.put("/prize-payments/:id", requireAuth, requireAdmin, async (req, res) => {
  try {
    res.json(await db.updatePrizePayment(req.params.id, req.body, req.user));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.delete("/prize-payments/:id", requireAuth, requireAdmin, async (req, res) => {
  try {
    res.json(await db.deletePrizePayment(req.params.id, req.user));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.get("/expenses", requireAuth, async (req, res) => {
  try {
    const { category, startDate, endDate } = req.query;
    res.json(await db.getExpenses(category, startDate, endDate));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
apiRouter.post("/expenses", requireAuth, async (req, res) => {
  try {
    const { expenseDate, category, description, amount } = req.body;
    if (!expenseDate || !category || !description || !amount)
      return res.status(400).json({ error: "Date, category, description, and amount are required" });
    res.status(201).json(await db.createExpense({ ...req.body, amount: Number(amount) }, req.user));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.put("/expenses/:id", requireAuth, async (req, res) => {
  try {
    res.json(await db.updateExpense(req.params.id, req.body, req.user));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.delete("/expenses/:id", requireAuth, requireAdmin, async (req, res) => {
  try {
    await db.deleteExpense(req.params.id, req.user);
    res.json({ message: "Expense deleted successfully" });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.get("/reports/collections", requireAuth, async (req, res) => {
  try {
    res.json(await db.getCollectionReport(req.query));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
apiRouter.get("/reports/outstanding", requireAuth, async (req, res) => {
  try {
    res.json(await db.getOutstandingReport(req.query.groupId));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
apiRouter.get("/reports/chit-groups", requireAuth, async (_req, res) => {
  try {
    res.json(await db.getChitGroupsReport());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
apiRouter.get("/reports/auctions", requireAuth, async (req, res) => {
  try {
    res.json(await db.getAuctionsReport(req.query.groupId));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
apiRouter.get("/reports/chit-booking-list", requireAuth, async (_req, res) => {
  try {
    res.json(await db.getChitBookingList());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
apiRouter.get("/search", requireAuth, async (req, res) => {
  try {
    res.json(await db.search(req.query.q || ""));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
apiRouter.get("/notifications", requireAuth, async (_req, res) => {
  try {
    res.json(await db.getNotifications());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
apiRouter.put("/notifications/:id/read", requireAuth, async (req, res) => {
  try {
    res.json(await db.markNotificationRead(req.params.id));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
apiRouter.get("/audit-logs", requireAuth, requireAdmin, async (_req, res) => {
  try {
    res.json(await db.getAuditLogs());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
apiRouter.put("/audit-logs/:id", requireAuth, requireAdmin, async (req, res) => {
  try {
    res.json(await db.updateAuditLog(req.params.id, req.body, req.user));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.delete("/audit-logs/:id", requireAuth, requireAdmin, async (req, res) => {
  try {
    res.json(await db.deleteAuditLog(req.params.id, req.user));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.get("/users", requireAuth, requireAdmin, async (_req, res) => {
  try {
    res.json(await db.getUsers());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
apiRouter.post("/users", requireAuth, requireAdmin, async (req, res) => {
  try {
    const { username, password, fullName } = req.body;
    if (!username || !password || !fullName)
      return res.status(400).json({ error: "Username, password, and name are required" });
    const email = req.body.email?.trim() ? req.body.email.trim() : `${username.trim().replace(/[^a-zA-Z0-9_]/g, "")}@jayapriyachits.com`;
    res.status(201).json(await db.createUser({ ...req.body, email }, req.user));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.put("/users/:id", requireAuth, requireAdmin, async (req, res) => {
  try {
    res.json(await db.updateUser(Number(req.params.id), req.body, req.user));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.delete("/users/:id", requireAuth, requireAdmin, async (req, res) => {
  try {
    res.json(await db.deleteUser(req.params.id, req.user));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.get("/settings", requireAuth, async (_req, res) => {
  try {
    res.json(await db.getSettings());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
apiRouter.put("/settings", requireAuth, requireAdmin, async (req, res) => {
  try {
    res.json(await db.updateSettings(req.body));
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});
apiRouter.get("/backup/export", requireAuth, requireAdmin, async (_req, res) => {
  res.json({ message: "Export via phpMyAdmin on xiadot.com" });
});
apiRouter.post("/backup/reset-demo", requireAuth, requireAdmin, async (_req, res) => {
  res.json({ message: "Reset not available in MySQL mode. Use phpMyAdmin." });
});
apiRouter.get("/agent/profile", requireAuth, async (req, res) => {
  try {
    const profile = await db.getAgentProfile(req.user?.id);
    res.json(profile);
  } catch (err) {
    res.status(500).json({ error: err.message || "Failed to fetch agent profile" });
  }
});
apiRouter.get("/agent/summary", requireAuth, async (req, res) => {
  try {
    const month = req.query.month;
    const summary = await db.getAgentSummary(month, req.user?.id, req.user?.role);
    res.json(summary);
  } catch (err) {
    res.status(500).json({ error: err.message || "Failed to fetch agent summary" });
  }
});
apiRouter.get("/agent/monthly-trend", requireAuth, async (_req, res) => {
  try {
    const trend = await db.getAgentMonthlyTrend();
    res.json(trend);
  } catch (err) {
    res.status(500).json({ error: err.message || "Failed to fetch monthly trend" });
  }
});
apiRouter.get("/agent/collection-sheet", requireAuth, async (req, res) => {
  try {
    const { dateType, customDate, status, search } = req.query;
    const items = await db.getAgentCollectionSheet({
      dateType,
      customDate,
      status,
      search
    }, req.user?.id, req.user?.role);
    res.json(items);
  } catch (err) {
    res.status(500).json({ error: err.message || "Failed to fetch collection sheet" });
  }
});
apiRouter.get("/agent/due-bills", requireAuth, async (req, res) => {
  try {
    const bills = await db.getAgentDueBills(req.user?.id, req.user?.role);
    res.json(bills);
  } catch (err) {
    res.status(500).json({ error: err.message || "Failed to fetch due bills" });
  }
});
apiRouter.get("/agent/receipts", requireAuth, async (req, res) => {
  try {
    const receipts = await db.getAgentReceipts(req.user?.id, req.user?.role);
    res.json(receipts);
  } catch (err) {
    res.status(500).json({ error: err.message || "Failed to fetch receipts" });
  }
});
apiRouter.post("/agent/collect-payment", requireAuth, async (req, res) => {
  try {
    const { customerId, installmentId, amount, paymentMethod, notes } = req.body;
    if (!customerId) {
      return res.status(400).json({ error: "Customer ID is required" });
    }
    const numAmount = Number(amount);
    if (!numAmount || Number.isNaN(numAmount) || numAmount <= 0) {
      return res.status(400).json({ error: "Valid payment amount greater than zero is required" });
    }
    const result = await db.collectAgentPayment(
      {
        customerId,
        installmentId,
        amount: numAmount,
        paymentMethod: paymentMethod || "cash",
        notes
      },
      req.user
    );
    res.status(201).json(result);
  } catch (err) {
    res.status(400).json({ error: err.message || "Failed to collect payment" });
  }
});
apiRouter.get("/collections/daily", requireAuth, async (req, res) => {
  try {
    const { date } = req.query;
    const data = await db.getDailyCollection(date, req.user?.id, req.user?.role);
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message || "Failed to fetch daily collection" });
  }
});
apiRouter.get("/collections/monthly", requireAuth, async (req, res) => {
  try {
    const { month } = req.query;
    const data = await db.getMonthlyCollection(month, req.user?.id, req.user?.role);
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message || "Failed to fetch monthly collection" });
  }
});
apiRouter.get("/collections/balance-sheet", requireAuth, async (req, res) => {
  try {
    const data = await db.getBalanceSheet(req.user?.id, req.user?.role);
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message || "Failed to fetch balance sheet" });
  }
});

// server.ts
import_dotenv.default.config();
async function startServer() {
  const app = (0, import_express2.default)();
  const PORT = 3e3;
  app.use((0, import_cors.default)());
  app.use(import_express2.default.json());
  app.use(import_express2.default.urlencoded({ extended: true }));
  app.use("/api", apiRouter);
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", time: (/* @__PURE__ */ new Date()).toISOString() });
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express2.default.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Chit Fund Management Server running on port ${PORT}`);
  });
}
startServer().catch((err) => {
  console.error("Failed to start Chit Fund Management server:", err);
  process.exit(1);
});
//# sourceMappingURL=server.cjs.map
