import React, { useState, useEffect } from 'react';
import {
  FileText,
  Download,
  Printer,
  Calendar,
  Filter,
  DollarSign,
  TrendingUp,
  AlertTriangle,
  Building,
  CheckCircle2,
  PieChart,
  Loader2,
  Search
} from 'lucide-react';
import { api } from '../../api/client';
import type { ChitGroup, Customer, UserRole } from '../../types';

interface ReportsViewProps {
  userRole: UserRole;
  onNavigateToCustomer: (customerId: string) => void;
}

export const ReportsView: React.FC<ReportsViewProps> = ({ userRole, onNavigateToCustomer }) => {
  const [activeTab, setActiveTab] = useState<'collections' | 'outstanding' | 'groups' | 'pnl'>('collections');
  const [loading, setLoading] = useState(false);

  // Data states
  const [collectionReport, setCollectionReport] = useState<any>(null);
  const [outstandingReport, setOutstandingReport] = useState<any>(null);
  const [groupReport, setGroupReport] = useState<any>(null);
  const [pnlReport, setPnlReport] = useState<any>(null);

  // Filters
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [selectedGroupId, setSelectedGroupId] = useState('all');
  const [groups, setGroups] = useState<ChitGroup[]>([]);

  useEffect(() => {
    api.getChitGroups().then(setGroups).catch(console.error);
  }, []);

  const loadReportData = async () => {
    try {
      setLoading(true);
      const params = {
        startDate: startDate || undefined,
        endDate: endDate || undefined,
        groupId: selectedGroupId !== 'all' ? selectedGroupId : undefined
      };

      if (activeTab === 'collections') {
        const data = await api.getCollectionReport(params);
        setCollectionReport(data);
      } else if (activeTab === 'outstanding') {
        const data = await api.getOutstandingReport(params.groupId);
        setOutstandingReport(data);
      } else if (activeTab === 'groups') {
        const data = await api.getGroupPerformanceReport();
        setGroupReport(data);
      } else if (activeTab === 'pnl') {
        // Load collections, expenses, and auctions to compute company P&L
        const [dash, exps, aucs] = await Promise.all([
          api.getDashboardSummary(),
          api.getExpenses(),
          api.getAuctions()
        ]);
        const totalCommission = aucs.reduce((s: number, a: any) => s + (a.foremanCommission || 0), 0);
        const totalExpenses = exps.reduce((s: number, e: any) => s + (e.amount || 0), 0);
        const netProfit = totalCommission - totalExpenses;
        setPnlReport({
          totalCommission,
          totalExpenses,
          netProfit,
          expenses: exps,
          auctions: aucs,
          summary: dash
        });
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadReportData();
  }, [activeTab, selectedGroupId]);

  // CSV Export utility
  const exportToCSV = (filename: string, rows: any[]) => {
    if (!rows || rows.length === 0) {
      alert('No data to export');
      return;
    }
    const headers = Object.keys(rows[0]);
    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [
        headers.join(','),
        ...rows.map((r) =>
          headers
            .map((h) => {
              const val = r[h] !== undefined && r[h] !== null ? String(r[h]) : '';
              return `"${val.replace(/"/g, '""')}"`;
            })
            .join(',')
        )
      ].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${filename}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900 font-sans">
            Financial & Operational Reports
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Audit collection ledgers, defaulters tracking, scheme performance, and company profit & loss
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="print-report-btn"
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-lg shadow-2xs transition"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Report</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex overflow-x-auto gap-1 bg-slate-100 p-1.5 rounded-xl text-xs font-semibold whitespace-nowrap scrollbar-none">
        <button
          id="tab-report-collections"
          onClick={() => setActiveTab('collections')}
          className={`px-3.5 sm:px-4 py-2 rounded-lg transition shrink-0 ${
            activeTab === 'collections' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Daily / Monthly Collections
        </button>
        <button
          id="tab-report-outstanding"
          onClick={() => setActiveTab('outstanding')}
          className={`px-3.5 sm:px-4 py-2 rounded-lg transition shrink-0 ${
            activeTab === 'outstanding' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Outstanding Dues & Defaulters
        </button>
        <button
          id="tab-report-groups"
          onClick={() => setActiveTab('groups')}
          className={`px-3.5 sm:px-4 py-2 rounded-lg transition shrink-0 ${
            activeTab === 'groups' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Chit Schemes Efficiency
        </button>
        <button
          id="tab-report-pnl"
          onClick={() => setActiveTab('pnl')}
          className={`px-3.5 sm:px-4 py-2 rounded-lg transition shrink-0 ${
            activeTab === 'pnl' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Company Profit & Loss
        </button>
      </div>

      {/* Filter Toolbar (For Collections & Outstanding) */}
      {(activeTab === 'collections' || activeTab === 'outstanding') && (
        <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-3 rounded-xl border border-slate-200 shadow-xs text-xs">
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500">Group:</span>
              <select
                value={selectedGroupId}
                onChange={(e) => setSelectedGroupId(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-slate-700"
              >
                <option value="all">All Chit Groups</option>
                {groups.map((g) => (
                  <option key={g.groupId} value={g.groupId}>
                    {g.groupName}
                  </option>
                ))}
              </select>
            </div>

            {activeTab === 'collections' && (
              <div className="flex items-center gap-2">
                <span className="text-slate-500">Date Range:</span>
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 text-slate-700"
                />
                <span className="text-slate-400">to</span>
                <input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 text-slate-700"
                />
                <button
                  onClick={loadReportData}
                  className="px-3 py-1 bg-amber-600 text-white font-semibold rounded-lg hover:bg-amber-700"
                >
                  Apply
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 1: COLLECTIONS REPORT */}
      {activeTab === 'collections' && (
        <div className="space-y-4">
          {collectionReport && (
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                <span className="text-slate-400 text-[10px] uppercase font-semibold block">Total Amount Collected</span>
                <span className="text-xl font-bold font-mono text-emerald-800 mt-1 block">
                  ₹{collectionReport.totalCollected.toLocaleString()}
                </span>
                <span className="text-[11px] text-slate-500 font-mono">{collectionReport.paymentCount} receipts issued</span>
              </div>
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                <span className="text-slate-400 text-[10px] uppercase font-semibold block">Cash Receipts</span>
                <span className="text-xl font-bold font-mono text-slate-900 mt-1 block">
                  ₹{(collectionReport.byPaymentMode?.Cash || 0).toLocaleString()}
                </span>
              </div>
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                <span className="text-slate-400 text-[10px] uppercase font-semibold block">UPI Transfers</span>
                <span className="text-xl font-bold font-mono text-slate-900 mt-1 block">
                  ₹{(collectionReport.byPaymentMode?.UPI || 0).toLocaleString()}
                </span>
              </div>
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                <span className="text-slate-400 text-[10px] uppercase font-semibold block">Bank Transfers</span>
                <span className="text-xl font-bold font-mono text-slate-900 mt-1 block">
                  ₹{(collectionReport.byPaymentMode?.['Bank Transfer'] || 0).toLocaleString()}
                </span>
              </div>
            </div>
          )}

          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <h3 className="font-bold text-slate-900 text-xs sm:text-sm">Detailed Collection Transactions</h3>
              <button
                onClick={() =>
                  exportToCSV(
                    `chitfund_collections_${new Date().toISOString().split('T')[0]}`,
                    collectionReport?.payments || []
                  )
                }
                className="inline-flex items-center gap-1 text-amber-700 hover:text-amber-800 font-semibold text-xs"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export CSV</span>
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-4">Receipt #</th>
                    <th className="py-2.5 px-4">Date</th>
                    <th className="py-2.5 px-4">Subscriber</th>
                    <th className="py-2.5 px-4">Scheme & Ticket</th>
                    <th className="py-2.5 px-4 text-right">Amount (₹)</th>
                    <th className="py-2.5 px-4">Mode</th>
                    <th className="py-2.5 px-4">Cashier</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono">
                  {loading ? (
                    <tr>
                      <td colSpan={7} className="text-center py-8 text-slate-400 font-sans">
                        <Loader2 className="w-5 h-5 animate-spin mx-auto mb-2 text-amber-600" />
                        Loading collection transactions...
                      </td>
                    </tr>
                  ) : !collectionReport?.payments || collectionReport.payments.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="text-center py-8 text-slate-400 font-sans">
                        No collection transactions match the date and scheme filters.
                      </td>
                    </tr>
                  ) : (
                    collectionReport.payments.map((p: any) => (
                      <tr key={p.receiptNumber || p.id} className="hover:bg-slate-50/80">
                        <td className="py-2.5 px-4 font-bold text-slate-900">{p.receiptNumber}</td>
                        <td className="py-2.5 px-4 text-slate-600">{p.paymentDate}</td>
                        <td className="py-2.5 px-4 font-sans font-medium text-slate-900">{p.customerName}</td>
                        <td className="py-2.5 px-4 font-sans text-slate-700">{p.groupName} (T#{p.ticketNumber})</td>
                        <td className="py-2.5 px-4 text-right font-bold text-emerald-800">₹{p.amountPaid.toLocaleString()}</td>
                        <td className="py-2.5 px-4 font-sans">{p.paymentMode}</td>
                        <td className="py-2.5 px-4 font-sans text-slate-600">{p.collectedByName}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: OUTSTANDING DUES & DEFAULTERS */}
      {activeTab === 'outstanding' && (
        <div className="space-y-4">
          {outstandingReport && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                <span className="text-slate-400 text-[10px] uppercase font-semibold block">Total Outstanding Dues</span>
                <span className="text-xl font-bold font-mono text-amber-900 mt-1 block">
                  ₹{outstandingReport.totalOutstanding.toLocaleString()}
                </span>
                <span className="text-[11px] text-slate-500 font-mono">{outstandingReport.installmentsCount} unpaid installments</span>
              </div>
              <div className="bg-white p-4 rounded-xl border border-rose-200 shadow-xs">
                <span className="text-rose-700 text-[10px] uppercase font-semibold block">Critical Overdue Dues</span>
                <span className="text-xl font-bold font-mono text-rose-800 mt-1 block">
                  ₹{outstandingReport.overdueAmount.toLocaleString()}
                </span>
                <span className="text-[11px] text-rose-600 font-mono">{outstandingReport.overdueCount} installments past due date</span>
              </div>
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
                <span className="text-slate-400 text-[10px] uppercase font-semibold block">Defaulter Subscribers</span>
                <span className="text-xl font-bold font-mono text-slate-900 mt-1 block">
                  {outstandingReport.defaulters?.length || 0} Members
                </span>
                <span className="text-[11px] text-slate-500">Requires follow-up calls</span>
              </div>
            </div>
          )}

          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <h3 className="font-bold text-slate-900 text-xs sm:text-sm">Subscribers Outstanding Ledger</h3>
              <button
                onClick={() =>
                  exportToCSV(
                    `chitfund_outstanding_${new Date().toISOString().split('T')[0]}`,
                    outstandingReport?.defaulters || []
                  )
                }
                className="inline-flex items-center gap-1 text-amber-700 hover:text-amber-800 font-semibold text-xs"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export CSV</span>
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-4">Subscriber</th>
                    <th className="py-2.5 px-4">Mobile</th>
                    <th className="py-2.5 px-4">Chit Scheme</th>
                    <th className="py-2.5 px-4 text-center">Ticket #</th>
                    <th className="py-2.5 px-4 text-center">Month #</th>
                    <th className="py-2.5 px-4">Due Date</th>
                    <th className="py-2.5 px-4 text-right">Net Due (₹)</th>
                    <th className="py-2.5 px-4 text-right">Remaining Balance (₹)</th>
                    <th className="py-2.5 px-4 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono">
                  {loading ? (
                    <tr>
                      <td colSpan={9} className="text-center py-8 text-slate-400 font-sans">
                        <Loader2 className="w-5 h-5 animate-spin mx-auto mb-2 text-amber-600" />
                        Loading outstanding ledger...
                      </td>
                    </tr>
                  ) : !outstandingReport?.defaulters || outstandingReport.defaulters.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="text-center py-8 text-slate-400 font-sans">
                        All members are up to date! No pending dues.
                      </td>
                    </tr>
                  ) : (
                    outstandingReport.defaulters.map((d: any) => (
                      <tr key={d.installmentId || d.id} className="hover:bg-slate-50/80">
                        <td className="py-2.5 px-4 font-sans">
                          <button
                            onClick={() => onNavigateToCustomer(d.customerId)}
                            className="font-bold text-slate-900 hover:text-amber-700 hover:underline block text-left"
                          >
                            {d.customerName}
                          </button>
                        </td>
                        <td className="py-2.5 px-4 text-slate-600">{d.mobileNumber}</td>
                        <td className="py-2.5 px-4 font-sans">{d.groupName}</td>
                        <td className="py-2.5 px-4 text-center font-bold text-amber-900">#{d.ticketNumber}</td>
                        <td className="py-2.5 px-4 text-center">M#{d.monthNumber}</td>
                        <td className="py-2.5 px-4 text-slate-600">{d.dueDate}</td>
                        <td className="py-2.5 px-4 text-right">₹{d.netDueAmount.toLocaleString()}</td>
                        <td className="py-2.5 px-4 text-right font-bold text-amber-900">₹{d.balanceAmount.toLocaleString()}</td>
                        <td className="py-2.5 px-4 text-center font-sans">
                          <span
                            className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                              d.status === 'Overdue'
                                ? 'bg-rose-50 text-rose-700 border border-rose-200'
                                : 'bg-amber-50 text-amber-700 border border-amber-200'
                            }`}
                          >
                            {d.status}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: CHIT SCHEMES EFFICIENCY */}
      {activeTab === 'groups' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
            <div>
              <h3 className="font-bold text-slate-900 text-xs sm:text-sm">Chit Group Collection & Recovery Matrix</h3>
              <p className="text-[11px] text-slate-500">Expected vs Actual Collections across all running schemes</p>
            </div>
            <button
              onClick={() =>
                exportToCSV(
                  `chitfund_groups_matrix_${new Date().toISOString().split('T')[0]}`,
                  groupReport?.groups || []
                )
              }
              className="inline-flex items-center gap-1 text-amber-700 hover:text-amber-800 font-semibold text-xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Scheme Code & Name</th>
                  <th className="py-3 px-4 text-right">Chit Value (₹)</th>
                  <th className="py-3 px-4 text-center">Enrollment</th>
                  <th className="py-3 px-4 text-right">Expected Dues (₹)</th>
                  <th className="py-3 px-4 text-right">Actual Collected (₹)</th>
                  <th className="py-3 px-4 text-right">Outstanding (₹)</th>
                  <th className="py-3 px-4 text-center">Recovery %</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                {loading ? (
                  <tr>
                    <td colSpan={7} className="text-center py-8 text-slate-400 font-sans">
                      <Loader2 className="w-5 h-5 animate-spin mx-auto mb-2 text-amber-600" />
                      Loading scheme matrix...
                    </td>
                  </tr>
                ) : !groupReport?.groups || groupReport.groups.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="text-center py-8 text-slate-400 font-sans">
                      No chit schemes found.
                    </td>
                  </tr>
                ) : (
                  groupReport.groups.map((g: any) => (
                    <tr key={g.groupId || String(g.id)} className="hover:bg-slate-50/80">
                      <td className="py-3 px-4 font-sans">
                        <span className="font-bold text-slate-900 block">{g.groupName}</span>
                        <span className="text-slate-400 text-[10px] font-mono">{g.groupId}</span>
                      </td>
                      <td className="py-3 px-4 text-right font-medium">₹{g.chitValue.toLocaleString()}</td>
                      <td className="py-3 px-4 text-center font-sans">
                        {g.currentMembersCount} / {g.numMembers} Seats
                      </td>
                      <td className="py-3 px-4 text-right">₹{g.expectedCollection.toLocaleString()}</td>
                      <td className="py-3 px-4 text-right font-bold text-emerald-800">
                        ₹{g.actualCollection.toLocaleString()}
                      </td>
                      <td className="py-3 px-4 text-right font-bold text-amber-900">
                        ₹{g.outstandingBalance.toLocaleString()}
                      </td>
                      <td className="py-3 px-4 text-center font-sans">
                        <div className="flex items-center justify-center gap-2">
                          <div className="w-16 bg-slate-100 rounded-full h-2 overflow-hidden">
                            <div
                              className="bg-emerald-600 h-2 rounded-full"
                              style={{ width: `${Math.min(100, g.collectionEfficiency)}%` }}
                            />
                          </div>
                          <span className="font-bold font-mono text-[11px] text-slate-800">
                            {g.collectionEfficiency}%
                          </span>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: COMPANY PROFIT & LOSS */}
      {activeTab === 'pnl' && pnlReport && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white p-4 rounded-xl border border-emerald-200 shadow-xs">
              <span className="text-emerald-700 text-[10px] uppercase font-semibold block">Total Foreman Commission</span>
              <span className="text-2xl font-bold font-mono text-emerald-900 mt-1 block">
                ₹{pnlReport.totalCommission.toLocaleString()}
              </span>
              <p className="text-[11px] text-slate-500 mt-1">Company revenue earned from auctions</p>
            </div>

            <div className="bg-white p-4 rounded-xl border border-rose-200 shadow-xs">
              <span className="text-rose-700 text-[10px] uppercase font-semibold block">Operational Expenses</span>
              <span className="text-2xl font-bold font-mono text-rose-900 mt-1 block">
                ₹{pnlReport.totalExpenses.toLocaleString()}
              </span>
              <p className="text-[11px] text-slate-500 mt-1">Rent, salaries, stationery, utilities</p>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
              <span className="text-slate-500 text-[10px] uppercase font-semibold block">Net Operating Profit</span>
              <span
                className={`text-2xl font-bold font-mono mt-1 block ${
                  pnlReport.netProfit >= 0 ? 'text-emerald-800' : 'text-rose-800'
                }`}
              >
                ₹{pnlReport.netProfit.toLocaleString()}
              </span>
              <p className="text-[11px] text-slate-500 mt-1">Foreman Commission minus Office Expenses</p>
            </div>
          </div>

          {/* Audit Statement Breakdown */}
          <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-xs space-y-3 text-xs">
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Chit Fund Company Financial Health Summary</span>
            </h3>
            <p className="text-slate-600 text-[11px] leading-relaxed">
              This financial ledger reconciles all subscriber installment inflows, auction commission gains, and branch overheads. Chit funds are governed under Section 21 of the Chit Funds Act, ensuring foreman commission cannot exceed 5% of the gross chit value.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
