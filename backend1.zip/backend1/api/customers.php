<?php
// ============================================================
// CUSTOMERS API
// GET    /backend/api/customers.php          - list all
// GET    /backend/api/customers.php?id=CUST001
// POST   /backend/api/customers.php          - create
// PUT    /backend/api/customers.php?id=CUST001
// DELETE /backend/api/customers.php?id=CUST001
// ============================================================
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/helpers.php';

setCorsHeaders();
$pdo    = Database::getInstance();
$method = getMethod();
$id     = $_GET['id'] ?? null;

switch ($method) {

    // ---- LIST / GET ONE ----
    case 'GET':
        if ($id) {
            $stmt = $pdo->prepare("SELECT * FROM customers WHERE customer_id = ?");
            $stmt->execute([$id]);
            $c = $stmt->fetch();
            if (!$c) jsonResponse(false, 'Customer not found', null, 404);
            jsonResponse(true, '', ['customer' => mapCustomer($c)]);
        }

        $search = $_GET['search'] ?? '';
        $status = $_GET['status'] ?? '';
        $sql    = "SELECT * FROM customers WHERE 1=1";
        $params = [];

        if ($search) {
            $sql .= " AND (full_name LIKE ? OR mobile_number LIKE ? OR customer_id LIKE ?)";
            $like = "%$search%";
            $params = array_merge($params, [$like, $like, $like]);
        }
        if ($status) {
            $sql .= " AND status = ?";
            $params[] = $status;
        }
        $sql .= " ORDER BY created_at DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();
        jsonResponse(true, '', ['customers' => array_map('mapCustomer', $rows)]);
        break;

    // ---- CREATE ----
    case 'POST':
        $b = getRequestBody();
        validateCustomer($b);

        // Generate customer_id
        $stmt  = $pdo->query("SELECT COUNT(*) FROM customers");
        $count = (int)$stmt->fetchColumn() + 1;
        $cid   = 'CUST' . str_pad($count, 4, '0', STR_PAD_LEFT);

        $pdo->prepare("
            INSERT INTO customers
              (customer_id, full_name, mobile_number, alternate_mobile, email, dob, gender,
               address, city, pincode, id_proof_type, id_proof_number,
               nominee_name, nominee_relationship, nominee_mobile, joining_date, status, remarks)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        ")->execute([
            $cid,
            $b['fullName'], $b['mobileNumber'], $b['alternateMobile'] ?? null,
            $b['email'] ?? null, $b['dob'] ?? null, $b['gender'] ?? 'Male',
            $b['address'], $b['city'], $b['pincode'],
            $b['idProofType'], $b['idProofNumber'],
            $b['nomineeName'], $b['nomineeRelationship'], $b['nomineeMobile'],
            $b['joiningDate'], $b['status'] ?? 'active', $b['remarks'] ?? null
        ]);

        $stmt = $pdo->prepare("SELECT * FROM customers WHERE customer_id = ?");
        $stmt->execute([$cid]);
        jsonResponse(true, 'Customer created successfully', ['customer' => mapCustomer($stmt->fetch())], 201);
        break;

    // ---- UPDATE ----
    case 'PUT':
        if (!$id) jsonResponse(false, 'Customer ID required', null, 400);
        $b = getRequestBody();

        $pdo->prepare("
            UPDATE customers SET
              full_name=?, mobile_number=?, alternate_mobile=?, email=?, dob=?, gender=?,
              address=?, city=?, pincode=?, id_proof_type=?, id_proof_number=?,
              nominee_name=?, nominee_relationship=?, nominee_mobile=?,
              joining_date=?, status=?, remarks=?
            WHERE customer_id=?
        ")->execute([
            $b['fullName'], $b['mobileNumber'], $b['alternateMobile'] ?? null,
            $b['email'] ?? null, $b['dob'] ?? null, $b['gender'] ?? 'Male',
            $b['address'], $b['city'], $b['pincode'],
            $b['idProofType'], $b['idProofNumber'],
            $b['nomineeName'], $b['nomineeRelationship'], $b['nomineeMobile'],
            $b['joiningDate'], $b['status'] ?? 'active', $b['remarks'] ?? null,
            $id
        ]);

        $stmt = $pdo->prepare("SELECT * FROM customers WHERE customer_id = ?");
        $stmt->execute([$id]);
        jsonResponse(true, 'Customer updated successfully', ['customer' => mapCustomer($stmt->fetch())]);
        break;

    // ---- DELETE ----
    case 'DELETE':
        if (!$id) jsonResponse(false, 'Customer ID required', null, 400);
        $pdo->prepare("DELETE FROM customers WHERE customer_id = ?")->execute([$id]);
        jsonResponse(true, 'Customer deleted successfully');
        break;

    default:
        jsonResponse(false, 'Method not allowed', null, 405);
}

function mapCustomer(array $row): array {
    return [
        'id'                  => (int)$row['id'],
        'customerId'          => $row['customer_id'],
        'fullName'            => $row['full_name'],
        'mobileNumber'        => $row['mobile_number'],
        'alternateMobile'     => $row['alternate_mobile'],
        'email'               => $row['email'],
        'dob'                 => $row['dob'],
        'gender'              => $row['gender'],
        'address'             => $row['address'],
        'city'                => $row['city'],
        'pincode'             => $row['pincode'],
        'idProofType'         => $row['id_proof_type'],
        'idProofNumber'       => $row['id_proof_number'],
        'nomineeName'         => $row['nominee_name'],
        'nomineeRelationship' => $row['nominee_relationship'],
        'nomineeMobile'       => $row['nominee_mobile'],
        'joiningDate'         => $row['joining_date'],
        'status'              => $row['status'],
        'remarks'             => $row['remarks'],
        'createdAt'           => $row['created_at'],
        'updatedAt'           => $row['updated_at'],
    ];
}

function validateCustomer(array $b): void {
    $required = ['fullName','mobileNumber','address','city','pincode','idProofType','idProofNumber','nomineeName','nomineeRelationship','nomineeMobile','joiningDate'];
    foreach ($required as $f) {
        if (empty($b[$f])) jsonResponse(false, "Field '$f' is required", null, 400);
    }
}
