<?php
// ============================================================
// INSTALLMENTS API
// ============================================================
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/helpers.php';

setCorsHeaders();
$pdo    = Database::getInstance();
$method = getMethod();
$id     = $_GET['id'] ?? null;

switch ($method) {
    case 'GET':
        $sql    = "
            SELECT i.*, c.full_name AS customer_name, cg.group_name
            FROM installments i
            LEFT JOIN customers c ON i.customer_id = c.customer_id
            LEFT JOIN chit_groups cg ON i.group_id = cg.group_id
            WHERE 1=1
        ";
        $params = [];
        if ($id) {
            $sql .= " AND i.installment_id=?"; $params[] = $id;
        }
        if (!empty($_GET['membershipId'])) { $sql .= " AND i.membership_id=?"; $params[] = $_GET['membershipId']; }
        if (!empty($_GET['status']))       { $sql .= " AND i.status=?";         $params[] = $_GET['status']; }
        $sql .= " ORDER BY i.due_date ASC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();
        if ($id) {
            jsonResponse(true, '', ['installment' => mapInstallment($rows[0] ?? null)]);
        }
        jsonResponse(true, '', ['installments' => array_map('mapInstallment', $rows)]);
        break;

    case 'POST':
        $b     = getRequestBody();
        $stmt  = $pdo->query("SELECT COUNT(*) FROM installments");
        $count = (int)$stmt->fetchColumn() + 1;
        $iid   = 'INST' . str_pad($count, 6, '0', STR_PAD_LEFT);
        $net   = (float)$b['installmentAmount'] - (float)($b['dividendDeduction'] ?? 0);
        $pdo->prepare("
            INSERT INTO installments
              (installment_id, membership_id, customer_id, group_id, month_number,
               due_date, installment_amount, dividend_deduction, net_due_amount, status)
            VALUES (?,?,?,?,?,?,?,?,?,'Pending')
        ")->execute([
            $iid, $b['membershipId'], $b['customerId'], $b['groupId'], $b['monthNumber'],
            $b['dueDate'], $b['installmentAmount'], $b['dividendDeduction'] ?? 0, $net
        ]);
        jsonResponse(true, 'Installment created', ['installmentId' => $iid], 201);
        break;

    case 'PUT':
        if (!$id) jsonResponse(false, 'Installment ID required', null, 400);
        $b = getRequestBody();
        $pdo->prepare("
            UPDATE installments SET
              paid_amount=?, payment_date=?, payment_mode=?, receipt_number=?, status=?, remarks=?
            WHERE installment_id=?
        ")->execute([
            $b['paidAmount'], $b['paymentDate'], $b['paymentMode'] ?? null,
            $b['receiptNumber'] ?? null, $b['status'], $b['remarks'] ?? null, $id
        ]);
        jsonResponse(true, 'Installment updated');
        break;

    default:
        jsonResponse(false, 'Method not allowed', null, 405);
}

function mapInstallment(array $r): array {
    return [
        'id'                 => (int)$r['id'],
        'installmentId'      => $r['installment_id'],
        'membershipId'       => $r['membership_id'],
        'customerId'         => $r['customer_id'],
        'customerName'       => $r['customer_name'] ?? null,
        'groupId'            => $r['group_id'],
        'groupName'          => $r['group_name'] ?? null,
        'monthNumber'        => (int)$r['month_number'],
        'dueDate'            => $r['due_date'],
        'installmentAmount'  => (float)$r['installment_amount'],
        'dividendDeduction'  => (float)$r['dividend_deduction'],
        'netDueAmount'       => (float)$r['net_due_amount'],
        'paidAmount'         => (float)$r['paid_amount'],
        'balanceAmount'      => (float)$r['net_due_amount'] - (float)$r['paid_amount'],
        'paymentDate'        => $r['payment_date'],
        'paymentMode'        => $r['payment_mode'],
        'receiptNumber'      => $r['receipt_number'],
        'status'             => $r['status'],
        'remarks'            => $r['remarks'],
        'createdAt'          => $r['created_at'],
        'updatedAt'          => $r['updated_at'],
    ];
}
