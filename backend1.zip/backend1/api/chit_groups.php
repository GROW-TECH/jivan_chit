<?php
// ============================================================
// CHIT GROUPS API - Full CRUD
// ============================================================
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/helpers.php';

setCorsHeaders();
$pdo    = Database::getInstance();
$method = getMethod();
$id     = $_GET['id'] ?? null;

switch ($method) {
    case 'GET':
        if ($id) {
            $stmt = $pdo->prepare("SELECT * FROM chit_groups WHERE group_id = ?");
            $stmt->execute([$id]);
            $g = $stmt->fetch();
            if (!$g) jsonResponse(false, 'Group not found', null, 404);
            jsonResponse(true, '', ['group' => mapGroup($g)]);
        }
        $stmt = $pdo->query("SELECT * FROM chit_groups ORDER BY created_at DESC");
        jsonResponse(true, '', ['groups' => array_map('mapGroup', $stmt->fetchAll())]);
        break;

    case 'POST':
        $b = getRequestBody();
        $stmt  = $pdo->query("SELECT COUNT(*) FROM chit_groups");
        $count = (int)$stmt->fetchColumn() + 1;
        $gid   = 'GRP' . str_pad($count, 4, '0', STR_PAD_LEFT);

        $pdo->prepare("
            INSERT INTO chit_groups
              (group_id, group_name, chit_value, num_members, monthly_installment, duration_months,
               start_date, end_date, auction_day_of_month, auction_frequency,
               foreman_commission_percent, status, description)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
        ")->execute([
            $gid, $b['groupName'], $b['chitValue'], $b['numMembers'],
            $b['monthlyInstallment'], $b['durationMonths'],
            $b['startDate'], $b['endDate'],
            $b['auctionDayOfMonth'] ?? 10, $b['auctionFrequency'] ?? 'Monthly',
            $b['foremanCommissionPercent'] ?? 5.00, $b['status'] ?? 'Upcoming',
            $b['description'] ?? null
        ]);

        $stmt = $pdo->prepare("SELECT * FROM chit_groups WHERE group_id = ?");
        $stmt->execute([$gid]);
        jsonResponse(true, 'Chit group created', ['group' => mapGroup($stmt->fetch())], 201);
        break;

    case 'PUT':
        if (!$id) jsonResponse(false, 'Group ID required', null, 400);
        $b = getRequestBody();
        $pdo->prepare("
            UPDATE chit_groups SET
              group_name=?, chit_value=?, num_members=?, monthly_installment=?, duration_months=?,
              start_date=?, end_date=?, auction_day_of_month=?, auction_frequency=?,
              foreman_commission_percent=?, status=?, description=?
            WHERE group_id=?
        ")->execute([
            $b['groupName'], $b['chitValue'], $b['numMembers'], $b['monthlyInstallment'],
            $b['durationMonths'], $b['startDate'], $b['endDate'],
            $b['auctionDayOfMonth'] ?? 10, $b['auctionFrequency'] ?? 'Monthly',
            $b['foremanCommissionPercent'] ?? 5.00, $b['status'] ?? 'Upcoming',
            $b['description'] ?? null, $id
        ]);
        $stmt = $pdo->prepare("SELECT * FROM chit_groups WHERE group_id = ?");
        $stmt->execute([$id]);
        jsonResponse(true, 'Chit group updated', ['group' => mapGroup($stmt->fetch())]);
        break;

    case 'DELETE':
        if (!$id) jsonResponse(false, 'Group ID required', null, 400);
        $pdo->prepare("DELETE FROM chit_groups WHERE group_id = ?")->execute([$id]);
        jsonResponse(true, 'Chit group deleted');
        break;

    default:
        jsonResponse(false, 'Method not allowed', null, 405);
}

function mapGroup(array $r): array {
    return [
        'id'                       => (int)$r['id'],
        'groupId'                  => $r['group_id'],
        'groupName'                => $r['group_name'],
        'chitValue'                => (float)$r['chit_value'],
        'numMembers'               => (int)$r['num_members'],
        'monthlyInstallment'       => (float)$r['monthly_installment'],
        'durationMonths'           => (int)$r['duration_months'],
        'startDate'                => $r['start_date'],
        'endDate'                  => $r['end_date'],
        'auctionDayOfMonth'        => (int)$r['auction_day_of_month'],
        'auctionFrequency'         => $r['auction_frequency'],
        'foremanCommissionPercent' => (float)$r['foreman_commission_percent'],
        'status'                   => $r['status'],
        'description'              => $r['description'],
        'createdAt'                => $r['created_at'],
        'updatedAt'                => $r['updated_at'],
    ];
}
