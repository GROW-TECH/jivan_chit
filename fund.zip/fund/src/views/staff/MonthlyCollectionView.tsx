import React, { useState, useEffect } from 'react';
import { Calendar, RefreshCw, DollarSign, TrendingUp, Activity, PieChart } from 'lucide-react';
import { api } from '../../api/client';

export const MonthlyCollectionView: React.FC<{ userRole: string }> = ({ userRole }) => {
  const [month, setMonth] = useState(() => new Date().toISOString().slice(0, 7));
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await api.getMonthlyCollection(month);
      setData(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [month]);

  return (
    <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Monthly Collection</h1>
          <p className="text-sm text-slate-500">Comprehensive monthly transaction analysis</p>
        </div>
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <input 
            type="month" 
            value={month} 
            onChange={(e) => setMonth(e.target.value)}
            className="px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white"
          />
          <button onClick={fetchData} className="p-2 border border-slate-300 rounded-lg hover:bg-slate-50 transition">
            <RefreshCw className={`w-4 h-4 text-slate-600 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-20"><RefreshCw className="w-8 h-8 text-amber-500 animate-spin" /></div>
      ) : data ? (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-4">
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-slate-500 uppercase tracking-wider">Total Monthly Collection</p>
                <p className="text-4xl font-bold text-slate-900 mt-2">₹{data.totalCollected?.toLocaleString()}</p>
              </div>
              <div className="w-16 h-16 rounded-2xl bg-emerald-100 flex items-center justify-center text-emerald-600">
                <DollarSign className="w-8 h-8" />
              </div>
            </div>
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-slate-500 uppercase tracking-wider">Commission Earned (5%)</p>
                <p className="text-4xl font-bold text-amber-600 mt-2">₹{data.commissionEarned?.toLocaleString()}</p>
              </div>
              <div className="w-16 h-16 rounded-2xl bg-amber-100 flex items-center justify-center text-amber-600">
                <PieChart className="w-8 h-8" />
              </div>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
            <div className="p-4 border-b border-slate-200 bg-slate-50 font-semibold text-slate-800">
              Monthly Transactions ({data.transactions?.length || 0})
            </div>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-slate-200 text-sm">
                <thead className="bg-slate-50">
                  <tr>
                    <th className="px-4 py-3 text-left font-medium text-slate-500">Date & Time</th>
                    <th className="px-4 py-3 text-left font-medium text-slate-500">Customer Details</th>
                    <th className="px-4 py-3 text-right font-medium text-slate-500">Target/Due</th>
                    <th className="px-4 py-3 text-right font-medium text-slate-500">Collected</th>
                    <th className="px-4 py-3 text-right font-medium text-slate-500">Outstanding</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 bg-white">
                  {data.transactions?.map((t: any) => (
                    <tr key={t.id} className="hover:bg-slate-50 transition">
                      <td className="px-4 py-3">
                        <p className="font-medium text-slate-900">{t.date}</p>
                        <p className="text-xs text-slate-500">{t.time} • {t.day}</p>
                      </td>
                      <td className="px-4 py-3">
                        <p className="font-medium text-slate-900">{t.customerName}</p>
                        <p className="text-xs text-slate-500">{t.groupName} • {t.agentName}</p>
                      </td>
                      <td className="px-4 py-3 text-right text-slate-600">₹{t.dueAmount?.toLocaleString()}</td>
                      <td className="px-4 py-3 text-right font-medium text-emerald-600">₹{t.amountPaid?.toLocaleString()}</td>
                      <td className="px-4 py-3 text-right">
                        <span className={`font-medium ${t.outstandingBalance > 0 ? 'text-rose-600' : 'text-slate-500'}`}>
                          ₹{t.outstandingBalance?.toLocaleString()}
                        </span>
                      </td>
                    </tr>
                  ))}
                  {!data.transactions?.length && (
                    <tr>
                      <td colSpan={5} className="px-4 py-8 text-center text-slate-500">No collections for this month.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      ) : (
        <div className="text-center py-12 text-slate-500">Failed to load data</div>
      )}
    </div>
  );
};
