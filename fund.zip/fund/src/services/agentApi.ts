import type {
  AgentCollectionFilters,
  AgentCollectionSummary,
  AgentCustomer,
  AgentDailySummary,
  AgentDueBill,
  AgentMonthlySummary,
  AgentMonthlyTrendPoint,
  AgentProfile,
  AgentReceipt,
  CollectPaymentInput,
  CollectionPayment,
  CollectionSheetItem,
  PaymentMethod
} from '../types/agent';
import { getStoredToken } from '../api/client';

export const AGENT_ID = 'agent-001';
const MONTH_TARGET = 350000;
const COMMISSION_RATE = 0.05;

const pad2 = (n: number) => String(n).padStart(2, '0');
const toDateKey = (d: Date) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
const monthKeyOf = (d: Date) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}`;

export const TODAY_KEY = toDateKey(new Date());
export const CURRENT_MONTH_KEY = monthKeyOf(new Date());

export function formatAmount(value: number): string {
  return `₹${(Number.isFinite(value) ? Math.round(value) : 0).toLocaleString('en-IN')}`;
}

export function formatDate(iso: string): string {
  if (!iso) return '-';
  const d = new Date(`${iso.slice(0, 10)}T00:00:00`);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

export function formatDateTime(iso: string): string {
  if (!iso) return '-';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  const date = d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
  const time = d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
  return `${date}, ${time}`;
}

export function monthLabel(key: string): string {
  const [y, m] = (key || CURRENT_MONTH_KEY).split('-').map(Number);
  if (!y || !m) return key;
  return new Date(y, m - 1, 1).toLocaleDateString('en-IN', { month: 'short', year: 'numeric' });
}

// -------------------------------------------------------------
// HTTP Client helper for Agent API (Fixed for Subfolder Deployment)
// -------------------------------------------------------------
async function agentRequest<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getStoredToken();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...((options.headers as Record<string, string>) || {})
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  // Changed from `/api${endpoint}` to `api${endpoint}` to support subfolder hosting
  const response = await fetch(`api${endpoint}`, {
    ...options,
    headers
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.error || data.message || 'An error occurred while communicating with the server.');
  }

  if (data && typeof data === 'object' && 'data' in data && 'success' in data) {
    return data.data as T;
  }

  return data as T;
}

// -------------------------------------------------------------
// Fallback Mock Data Generator (Used only if offline/unreachable)
// -------------------------------------------------------------
const GROUPS = [
  { code: 'SRI-101', installment: 10000, members: 8 },
  { code: 'SRI-102', installment: 12000, members: 7 },
  { code: 'SRI-103', installment: 8000, members: 6 },
  { code: 'SRI-104', installment: 15000, members: 5 }
];

const CUSTOMER_NAMES = [
  'Mohan Varma', 'Priya Sharma', 'Arjun Nair', 'Divya Krishnan', 'Karthik Rao',
  'Lakshmi Menon', 'Suresh Babu', 'Anita Desai', 'Vikram Singh', 'Meena Kumari',
  'Rahul Jain', 'Sneha Reddy', 'Ganesh Iyer', 'Pooja Patel', 'Sanjay Gupta',
  'Rekha Devi', 'Amit Malhotra', 'Saritha Pillai', 'Deepak Chopra', 'Kavitha Nair',
  'Naveen Kumar', 'Sunita Verma', 'Prakash Rao', 'Jyothi Lakshmi', 'Ramesh Menon', 'Anjali Sharma'
];

const fallbackItems: CollectionSheetItem[] = [];
const fallbackReceipts: AgentReceipt[] = [];

function initFallbackData() {
  if (fallbackItems.length > 0) return;
  let idx = 0;
  for (const group of GROUPS) {
    for (let m = 1; m <= group.members; m++) {
      const name = CUSTOMER_NAMES[idx % CUSTOMER_NAMES.length];
      const customerId = `CUS-${String(idx + 1).padStart(3, '0')}`;
      const due = group.installment;
      const isPaid = idx % 3 === 0;
      const paid = isPaid ? due : idx % 3 === 1 ? Math.round(due * 0.4) : 0;
      const pending = due - paid;
      const status = isPaid ? 'paid' : idx % 5 === 0 ? 'overdue' : 'pending';
      const dueDate = toDateKey(new Date());

      fallbackItems.push({
        id: `INST-${idx + 1}`,
        customerId,
        customerName: name,
        phone: `+91 98${pad2(idx)}5 43210`,
        chitGroupCode: group.code,
        ticketNumber: String(m),
        dueDate,
        dueInstallmentAmount: due,
        paidAmount: paid,
        pendingBalance: pending,
        status,
        currentInstallment: 1 + (idx % 6)
      });
      idx++;
    }
  }
}

// -------------------------------------------------------------
// Primary Agent API Service (Dynamic Backend Integration)
// -------------------------------------------------------------
export const agentApi = {
  async getAgentProfile(agentId: string = AGENT_ID): Promise<AgentProfile> {
    try {
      const res = await agentRequest<AgentProfile>('/agent/profile');
      return {
        id: res?.id || agentId,
        name: res?.name || 'Field Agent',
        phone: res?.phone || '+91 98765 43210',
        area: res?.area || 'North Zone & Regional Field',
        assignedCustomers: res?.assignedCustomers ?? 26
      };
    } catch {
      return {
        id: agentId,
        name: 'Field Agent',
        phone: '+91 98765 43210',
        area: 'North Zone & Regional Field',
        assignedCustomers: 26
      };
    }
  },

  async getAgentCollectionSummary(month: string = CURRENT_MONTH_KEY): Promise<AgentCollectionSummary> {
    try {
      return await agentRequest<AgentCollectionSummary>(`/agent/summary?month=${encodeURIComponent(month)}`);
    } catch {
      initFallbackData();
      const collected = fallbackItems.reduce((acc, i) => acc + i.paidAmount, 0);
      const target = MONTH_TARGET;
      return {
        todayCashCollection: Math.round(collected * 0.6),
        todayOnlineCollection: Math.round(collected * 0.4),
        todayTotalCollection: collected,
        todayCustomersCollected: fallbackItems.filter((i) => i.paidAmount > 0).length,
        todayPendingCollections: fallbackItems.filter((i) => i.status === 'pending').length,
        todayOverdueCollections: fallbackItems.filter((i) => i.status === 'overdue').length,
        monthlyCollection: collected,
        monthlyTarget: target,
        pendingBalance: fallbackItems.reduce((acc, i) => acc + i.pendingBalance, 0),
        pendingCustomersCount: fallbackItems.filter((i) => i.pendingBalance > 0).length,
        commissionEarned: Math.round(collected * COMMISSION_RATE),
        commissionRate: COMMISSION_RATE,
        collectedInstallments: fallbackItems.filter((i) => i.status === 'paid').length,
        pendingInstallments: fallbackItems.filter((i) => i.status === 'pending').length,
        overdueInstallments: fallbackItems.filter((i) => i.status === 'overdue').length,
        remainingTargetAmount: Math.max(0, target - collected),
        targetAchievedPercent: Math.min(100, Math.round((collected / target) * 100)),
        month
      };
    }
  },

  async getAgentMonthlyTrend(): Promise<AgentMonthlyTrendPoint[]> {
    try {
      const res = await agentRequest<any>('/agent/monthly-trend');
      if (Array.isArray(res) && res.length > 0) return res;
      if (res && Array.isArray(res.data) && res.data.length > 0) return res.data;
      throw new Error('Invalid trend response format');
    } catch {
      const now = new Date();
      const trend: AgentMonthlyTrendPoint[] = [];
      const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      for (let i = 5; i >= 0; i--) {
        const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
        const k = monthKeyOf(d);
        trend.push({
          month: k,
          label: monthNames[d.getMonth()],
          collected: 220000 + i * 24000,
          target: MONTH_TARGET
        });
      }
      return trend;
    }
  },

  async getAgentCollectionSheet(
    _agentId: string = AGENT_ID,
    filters: AgentCollectionFilters
  ): Promise<CollectionSheetItem[]> {
    try {
      const params = new URLSearchParams();
      if (filters.dateType) params.append('dateType', filters.dateType);
      if (filters.customDate) params.append('customDate', filters.customDate);
      if (filters.status) params.append('status', filters.status);
      if (filters.search) params.append('search', filters.search);

      const res = await agentRequest<any>(`/agent/collection-sheet?${params.toString()}`);
      if (Array.isArray(res)) return res;
      if (res && Array.isArray(res.items)) return res.items;
      if (res && Array.isArray(res.data)) return res.data;
      throw new Error('Invalid collection sheet response format');
    } catch {
      initFallbackData();
      return fallbackItems.filter((i) => {
        if (filters.status && filters.status !== 'all' && i.status !== filters.status) return false;
        if (filters.search) {
          const s = filters.search.toLowerCase();
          return (
            i.customerName.toLowerCase().includes(s) ||
            i.phone.includes(s) ||
            i.chitGroupCode.toLowerCase().includes(s)
          );
        }
        return true;
      });
    }
  },

  async getAgentCustomers(agentId: string = AGENT_ID): Promise<AgentCustomer[]> {
    try {
      const sheet = await this.getAgentCollectionSheet(agentId, { dateType: 'today', customDate: '', status: 'all', search: '' });
      return (Array.isArray(sheet) ? sheet : []).map((s) => ({
        id: s.customerId,
        name: s.customerName,
        phone: s.phone,
        chitGroupCode: s.chitGroupCode,
        ticketNumber: s.ticketNumber,
        assignedAgentId: agentId,
        totalDueAmount: s.dueInstallmentAmount,
        totalPaidAmount: s.paidAmount,
        outstandingBalance: s.pendingBalance
      }));
    } catch {
      initFallbackData();
      return fallbackItems.map((s) => ({
        id: s.customerId,
        name: s.customerName,
        phone: s.phone,
        chitGroupCode: s.chitGroupCode,
        ticketNumber: s.ticketNumber,
        assignedAgentId: agentId,
        totalDueAmount: s.dueInstallmentAmount,
        totalPaidAmount: s.paidAmount,
        outstandingBalance: s.pendingBalance
      }));
    }
  },

  async getAgentDueBills(_agentId: string = AGENT_ID): Promise<AgentDueBill[]> {
    try {
      const res = await agentRequest<any>('/agent/due-bills');
      if (Array.isArray(res)) return res;
      if (res && Array.isArray(res.data)) return res.data;
      if (res && Array.isArray(res.bills)) return res.bills;
      throw new Error('Invalid due bills format');
    } catch {
      initFallbackData();
      return fallbackItems
        .filter((i) => i.pendingBalance > 0)
        .map((i) => ({
          id: i.id,
          customerId: i.customerId,
          customerName: i.customerName,
          phone: i.phone,
          chitGroupCode: i.chitGroupCode,
          ticketNumber: i.ticketNumber,
          currentInstallment: i.currentInstallment,
          dueAmount: i.dueInstallmentAmount,
          paidAmount: i.paidAmount,
          outstandingBalance: i.pendingBalance,
          arrears: i.status === 'overdue' ? i.pendingBalance : 0,
          dueDate: i.dueDate,
          status: i.status
        }));
    }
  },

  async getAgentReceipts(_agentId: string = AGENT_ID): Promise<AgentReceipt[]> {
    try {
      const res = await agentRequest<any>('/agent/receipts');
      if (Array.isArray(res)) return res;
      if (res && Array.isArray(res.data)) return res.data;
      if (res && Array.isArray(res.receipts)) return res.receipts;
      throw new Error('Invalid receipts format');
    } catch {
      return fallbackReceipts;
    }
  },

  async collectAgentPayment(
    input: CollectPaymentInput
  ): Promise<{ payment: CollectionPayment; receipt: AgentReceipt }> {
    try {
      const response = await agentRequest<{ payment: CollectionPayment; receipt: AgentReceipt }>(
        '/agent/collect-payment',
        {
          method: 'POST',
          body: JSON.stringify(input)
        }
      );
      return response;
    } catch (err: any) {
      const errorMsg = err.message || 'Payment collection failed. Please check connection.';
      throw new Error(errorMsg);
    }
  },

  async generateAgentReceipt(receiptNumberOrId: string): Promise<AgentReceipt> {
    const receipts = await this.getAgentReceipts();
    const found = receipts.find(
      (r) => r.receiptNumber === receiptNumberOrId || (r as any).id === receiptNumberOrId
    );
    if (!found) {
      throw new Error('Receipt not found. Please try again.');
    }
    return found;
  }
};

export function getAgentCollectionSheet(
  agentId: string,
  filters: AgentCollectionFilters
): Promise<{ items: CollectionSheetItem[] }> {
  return agentApi.getAgentCollectionSheet(agentId, filters).then((items) => ({ items }));
}

export async function getAgentDailyCollectionSummary(date: string = TODAY_KEY): Promise<AgentDailySummary> {
  const summary = await agentApi.getAgentCollectionSummary(date.slice(0, 7));
  return {
    date,
    totalCustomers: summary.pendingCustomersCount + summary.todayCustomersCollected,
    collectedCustomers: summary.todayCustomersCollected,
    pendingCollections: summary.todayPendingCollections,
    overdueCollections: summary.todayOverdueCollections,
    cashCollection: summary.todayCashCollection,
    onlineCollection: summary.todayOnlineCollection,
    totalCollection: summary.todayTotalCollection
  };
}

export function getAgentMonthlyCollectionSummary(month: string = CURRENT_MONTH_KEY): Promise<AgentMonthlySummary> {
  return agentApi.getAgentCollectionSummary(month).then((s) => ({
    month: s.month,
    collected: s.monthlyCollection,
    target: s.monthlyTarget,
    targetAchievedPercent: s.targetAchievedPercent,
    remainingTargetAmount: s.remainingTargetAmount,
    collectedInstallments: s.collectedInstallments,
    pendingInstallments: s.pendingInstallments,
    overdueInstallments: s.overdueInstallments
  }));
}

export function downloadCollectionSheetCsv(items: CollectionSheetItem[], filename = 'collection_sheet.csv') {
  const headers = ['Customer ID', 'Customer Name', 'Phone', 'Chit Group', 'Ticket #', 'Due Date', 'Due Amount', 'Paid Amount', 'Pending Balance', 'Status'];
  const rows = items.map((i) => [
    `"${i.customerId}"`,
    `"${i.customerName}"`,
    `"${i.phone}"`,
    `"${i.chitGroupCode}"`,
    `"${i.ticketNumber}"`,
    `"${i.dueDate}"`,
    i.dueInstallmentAmount,
    i.paidAmount,
    i.pendingBalance,
    `"${i.status}"`
  ]);

  const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function downloadAgentReceipt(receipt: AgentReceipt) {
  const content = `================================================
SRI CHIT FUNDS - COLLECTION RECEIPT
================================================
Receipt No:      ${receipt.receiptNumber}
Date & Time:     ${formatDateTime(receipt.collectedAt)}
------------------------------------------------
Customer Name:   ${receipt.customerName}
Customer ID:     ${receipt.customerId}
Phone:           ${receipt.phone}
Chit Group:      ${receipt.chitGroupCode}
Ticket Number:   #${receipt.ticketNumber}
------------------------------------------------
Amount Paid:     ${formatAmount(receipt.amountCollected)}
Payment Method:  ${receipt.paymentMethod.toUpperCase()}
Remaining Due:   ${formatAmount(receipt.remainingBalance)}
Collected By:    ${receipt.agentName}
${receipt.notes ? `Notes:           ${receipt.notes}\n` : ''}------------------------------------------------
Thank you for your payment.
Computer Generated Receipt.
================================================`;

  const blob = new Blob([content], { type: 'text/plain;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `Receipt_${receipt.receiptNumber}.txt`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}