<?php
// ============================================================
// EXPENSES API
// ============================================================
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/helpers.php';

setCorsHeaders();
$pdo    = Database::getInstance();
$method = getMethod();
$id     = $_GET['id'] ?? null;

switch ($method) {
    case 'GET':
        $sql    = "SELECT e.*, u.full_name AS created_by_name FROM expenses e LEFT JOIN users u ON e.created_by_user_id = u.id WHERE 1=1";
        $params = [];
        if ($id) { $sql .= " AND e.expense_id=?"; $params[] = $id; }
        if (!empty($_GET['category'])) { $sql .= " AND e.category=?"; $params[] = $_GET['category']; }
        $sql .= " ORDER BY e.expense_date DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();
        if ($id) jsonResponse(true, '', ['expense' => mapExpense($rows[0] ?? null)]);
        jsonResponse(true, '', ['expenses' => array_map('mapExpense', $rows)]);
        break;

    case 'POST':
        $b     = getRequestBody();
        $stmt  = $pdo->query("SELECT COUNT(*) FROM expenses");
        $count = (int)$stmt->fetchColumn() + 1;
        $eid   = 'EXP' . date('Ymd') . str_pad($count, 4, '0', STR_PAD_LEFT);
        $pdo->prepare("
            INSERT INTO expenses (expense_id, expense_date, category, description, amount, payment_mode, reference_number, remarks, created_by_user_id)
            VALUES (?,?,?,?,?,?,?,?,?)
        ")->execute([
            $eid, $b['expenseDate'], $b['category'], $b['description'], $b['amount'],
            $b['paymentMode'] ?? 'Cash', $b['referenceNumber'] ?? null,
            $b['remarks'] ?? null, $b['createdByUserId'] ?? 1
        ]);
        jsonResponse(true, 'Expense recorded', ['expenseId' => $eid], 201);
        break;

    case 'DELETE':
        if (!$id) jsonResponse(false, 'Expense ID required', null, 400);
        $pdo->prepare("DELETE FROM expenses WHERE expense_id=?")->execute([$id]);
        jsonResponse(true, 'Expense deleted');
        break;

    default:
        jsonResponse(false, 'Method not allowed', null, 405);
}

function mapExpense(array $r): array {
    return [
        'id'              => (int)$r['id'],
        'expenseId'       => $r['expense_id'],
        'expenseDate'     => $r['expense_date'],
        'category'        => $r['category'],
        'description'     => $r['description'],
        'amount'          => (float)$r['amount'],
        'paymentMode'     => $r['payment_mode'],
        'referenceNumber' => $r['reference_number'],
        'remarks'         => $r['remarks'],
        'createdByUserId' => (int)$r['created_by_user_id'],
        'createdByName'   => $r['created_by_name'] ?? null,
        'createdAt'       => $r['created_at'],
    ];
}
