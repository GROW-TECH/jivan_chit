import React, { useState, useEffect } from 'react';
import {
  Users,
  Search,
  Plus,
  Edit2,
  Eye,
  Filter,
  Ticket,
  Receipt,
  Building,
  UserPlus,
  X,
  Loader2,
  CheckCircle2,
  Calendar,
  Phone,
  MapPin,
  FileText
} from 'lucide-react';
import { api } from '../../api/client';
import type { Customer, Membership, Payment, Installment, ChitGroup, PaymentReceipt, UserRole } from '../../types';

interface CustomersViewProps {
  initialCustomerId?: string;
  userRole: UserRole;
  onOpenReceipt: (receipt: PaymentReceipt) => void;
  onNavigateToGroup: (groupId: string) => void;
}

export const CustomersView: React.FC<CustomersViewProps> = ({
  initialCustomerId,
  userRole,
  onOpenReceipt,
  onNavigateToGroup
}) => {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  // Customer Detail Drawer state
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(initialCustomerId || null);
  const [selectedCustomerData, setSelectedCustomerData] = useState<{
    customer: Customer;
    memberships: Membership[];
    payments: Payment[];
    installments: Installment[];
  } | null>(null);
  const [loadingDetails, setLoadingDetails] = useState(false);

  // Add / Edit Modal state
  const [showFormModal, setShowFormModal] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [formSubmitting, setFormSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Enroll in Group Modal state
  const [showEnrollModal, setShowEnrollModal] = useState(false);
  const [availableGroups, setAvailableGroups] = useState<ChitGroup[]>([]);
  const [enrollGroupId, setEnrollGroupId] = useState('');
  const [enrollTicketNumber, setEnrollTicketNumber] = useState('');
  const [allowDuplicate, setAllowDuplicate] = useState(false);
  const [enrollSubmitting, setEnrollSubmitting] = useState(false);
  const [enrollError, setEnrollError] = useState<string | null>(null);

  // Form Fields
  const [formData, setFormData] = useState<Partial<Customer>>({
    fullName: '',
    mobileNumber: '',
    alternateMobile: '',
    email: '',
    dob: '1990-01-01',
    gender: 'Male',
    address: '',
    city: 'Bangalore',
    pincode: '560001',
    idProofType: 'Aadhaar',
    idProofNumber: '',
    nomineeName: '',
    nomineeRelationship: 'Spouse',
    nomineeMobile: '',
    joiningDate: new Date().toISOString().split('T')[0],
    status: 'active',
    remarks: ''
  });

  const loadCustomers = async () => {
    try {
      setLoading(true);
      const data = await api.getCustomers(searchQuery, statusFilter !== 'all' ? statusFilter : undefined);
      setCustomers(data);
    } catch (err: any) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCustomers();
  }, [searchQuery, statusFilter]);

  const loadCustomerDetails = async (id: string) => {
    setSelectedCustomerId(id);
    setLoadingDetails(true);
    try {
      const data = await api.getCustomerById(id);
      setSelectedCustomerData(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingDetails(false);
    }
  };

  useEffect(() => {
    if (initialCustomerId) {
      loadCustomerDetails(initialCustomerId);
    }
  }, [initialCustomerId]);

  const handleOpenAdd = () => {
    setEditingCustomer(null);
    setFormData({
      fullName: '',
      mobileNumber: '',
      alternateMobile: '',
      email: '',
      dob: '1990-01-01',
      gender: 'Male',
      address: '',
      city: 'Bangalore',
      pincode: '560001',
      idProofType: 'Aadhaar',
      idProofNumber: '',
      nomineeName: '',
      nomineeRelationship: 'Spouse',
      nomineeMobile: '',
      joiningDate: new Date().toISOString().split('T')[0],
      status: 'active',
      remarks: ''
    });
    setFormError(null);
    setShowFormModal(true);
  };

  const handleOpenEdit = (c: Customer) => {
    setEditingCustomer(c);
    setFormData({ ...c });
    setFormError(null);
    setShowFormModal(true);
  };

  const handleSaveCustomer = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormSubmitting(true);
    setFormError(null);
    try {
      if (editingCustomer) {
        await api.updateCustomer(editingCustomer.customerId, formData);
      } else {
        await api.createCustomer(formData);
      }
      setShowFormModal(false);
      loadCustomers();
      if (selectedCustomerId) {
        loadCustomerDetails(selectedCustomerId);
      }
    } catch (err: any) {
      setFormError(err.message || 'Failed to save customer');
    } finally {
      setFormSubmitting(false);
    }
  };

  const handleOpenEnrollModal = async () => {
    try {
      const groups = await api.getChitGroups();
      setAvailableGroups(groups.filter((g) => g.status !== 'Completed' && g.status !== 'Cancelled'));
      if (groups.length > 0) setEnrollGroupId(groups[0].groupId);
      setEnrollTicketNumber('');
      setAllowDuplicate(false);
      setEnrollError(null);
      setShowEnrollModal(true);
    } catch (err: any) {
      alert('Failed to load chit groups');
    }
  };

  const handleEnrollSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCustomerId || !enrollGroupId) return;

    setEnrollSubmitting(true);
    setEnrollError(null);
    try {
      await api.createMembership({
        customerId: selectedCustomerId,
        groupId: enrollGroupId,
        ticketNumber: enrollTicketNumber ? Number(enrollTicketNumber) : undefined,
        isDuplicateAllowed: allowDuplicate
      });
      setShowEnrollModal(false);
      loadCustomerDetails(selectedCustomerId);
      loadCustomers();
    } catch (err: any) {
      setEnrollError(err.message || 'Failed to enroll member in group');
    } finally {
      setEnrollSubmitting(false);
    }
  };

  const handleViewReceipt = async (receiptNum: string) => {
    try {
      const res = await api.getPaymentReceipt(receiptNum);
      onOpenReceipt(res.receipt);
    } catch (err: any) {
      alert(err.message || 'Failed to load receipt');
    }
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900 font-sans">
            Customer Directory
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage subscriber KYC profiles, contact details, nominee information, and enrolled chit groups
          </p>
        </div>

        <button
          id="add-customer-btn"
          onClick={handleOpenAdd}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold rounded-lg shadow-xs transition shrink-0"
        >
          <UserPlus className="w-4 h-4" />
          <span>Add New Customer</span>
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white p-3 rounded-xl border border-slate-200 shadow-xs">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            id="customer-search-input"
            type="text"
            placeholder="Search by name, ID, mobile, city..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Filter className="w-3.5 h-3.5 text-slate-400" />
          <span className="text-xs text-slate-500">Status:</span>
          <select
            id="customer-status-filter"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-slate-700 focus:outline-none"
          >
            <option value="all">All Accounts ({customers.length})</option>
            <option value="active">Active Only</option>
            <option value="inactive">Inactive Only</option>
          </select>
        </div>
      </div>

      {/* Mobile Customer Cards (< md) */}
      <div className="md:hidden space-y-3">
        {loading ? (
          <div className="text-center py-10 bg-white rounded-xl border border-slate-200 text-slate-400">
            <Loader2 className="w-5 h-5 animate-spin mx-auto mb-2 text-amber-600" />
            Loading subscriber records...
          </div>
        ) : customers.length === 0 ? (
          <div className="text-center py-10 bg-white rounded-xl border border-slate-200 text-slate-400 text-xs">
            No customers found. Try adjusting your search query or add a new customer.
          </div>
        ) : (
          customers.map((c) => (
            <div
              key={c.customerId}
              className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3"
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-xs text-amber-900 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                      {c.customerId}
                    </span>
                    <span
                      className={`uppercase font-mono px-2 py-0.5 rounded text-[10px] font-semibold ${
                        c.status === 'active'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : 'bg-slate-100 text-slate-600 border border-slate-200'
                      }`}
                    >
                      {c.status}
                    </span>
                  </div>
                  <h3 className="text-sm font-bold text-slate-900 mt-1.5">{c.fullName}</h3>
                  <p className="text-[11px] text-slate-500">{c.gender} • Joined {c.joiningDate}</p>
                </div>
                <span className="inline-flex items-center gap-1 font-mono font-bold text-amber-900 bg-amber-100/70 px-2 py-0.5 rounded text-[11px] shrink-0">
                  <Ticket className="w-3 h-3 text-amber-700" />
                  {c.totalMemberships || 0} Chits
                </span>
              </div>

              <div className="grid grid-cols-1 xs:grid-cols-2 gap-2 bg-slate-50 p-2.5 rounded-lg text-xs">
                <div>
                  <span className="text-[10px] text-slate-400 font-semibold uppercase block">Contact</span>
                  <span className="font-mono text-slate-800 font-medium block">{c.mobileNumber}</span>
                  <span className="text-slate-500 text-[11px] truncate block">{c.city} - {c.pincode}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 font-semibold uppercase block">KYC & Nominee</span>
                  <span className="font-mono text-[11px] text-slate-700 block truncate">{c.idProofType}: {c.idProofNumber}</span>
                  <span className="text-slate-500 text-[11px] truncate block">{c.nomineeName} ({c.nomineeRelationship})</span>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-1 border-t border-slate-100">
                <button
                  onClick={() => handleOpenEdit(c)}
                  className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg inline-flex items-center gap-1 min-h-[36px]"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                  <span>Edit</span>
                </button>
                <button
                  onClick={() => loadCustomerDetails(c.customerId)}
                  className="px-3 py-1.5 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-lg inline-flex items-center gap-1 min-h-[36px]"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>View Statement</span>
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Desktop Customers Table (>= md) */}
      <div className="hidden md:block bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Customer ID</th>
                <th className="py-3 px-4">Full Name</th>
                <th className="py-3 px-4">Contact & City</th>
                <th className="py-3 px-4">ID Proof / Nominee</th>
                <th className="py-3 px-4">Chits Enrolled</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan={7} className="text-center py-10 text-slate-400">
                    <Loader2 className="w-5 h-5 animate-spin mx-auto mb-2 text-amber-600" />
                    Loading subscriber records...
                  </td>
                </tr>
              ) : customers.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-10 text-slate-400">
                    No customers found. Try adjusting your search query or add a new customer.
                  </td>
                </tr>
              ) : (
                customers.map((c) => (
                  <tr key={c.customerId} className="hover:bg-slate-50/80 transition">
                    <td className="py-3 px-4 font-mono font-bold text-slate-900">
                      {c.customerId}
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-bold text-slate-900 block text-xs">{c.fullName}</span>
                      <span className="text-[11px] text-slate-500">{c.gender} • Joined {c.joiningDate}</span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-mono text-slate-800 font-medium block">{c.mobileNumber}</span>
                      <span className="text-slate-500 text-[11px]">{c.city} - {c.pincode}</span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-mono text-[11px] text-slate-700 block">
                        {c.idProofType}: {c.idProofNumber}
                      </span>
                      <span className="text-slate-500 text-[11px]">Nominee: {c.nomineeName} ({c.nomineeRelationship})</span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="inline-flex items-center gap-1 font-mono font-bold text-amber-900 bg-amber-100/70 px-2 py-0.5 rounded text-[11px]">
                        <Ticket className="w-3 h-3 text-amber-700" />
                        {c.totalMemberships || 0} Tickets
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`inline-block uppercase font-mono px-2 py-0.5 rounded text-[10px] font-semibold ${
                          c.status === 'active'
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-slate-100 text-slate-600 border border-slate-200'
                        }`}
                      >
                        {c.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          id={`view-customer-${c.customerId}`}
                          onClick={() => loadCustomerDetails(c.customerId)}
                          className="p-1.5 text-slate-600 hover:text-amber-700 hover:bg-amber-50 rounded-md transition"
                          title="View Details & Statement"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          id={`edit-customer-${c.customerId}`}
                          onClick={() => handleOpenEdit(c)}
                          className="p-1.5 text-slate-600 hover:text-blue-700 hover:bg-blue-50 rounded-md transition"
                          title="Edit Customer"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* CUSTOMER PROFILE & STATEMENT DRAWER */}
      {selectedCustomerId && selectedCustomerData && (
        <div id="customer-drawer-backdrop" className="fixed inset-0 z-50 overflow-hidden bg-slate-900/50 backdrop-blur-xs">
          <div className="absolute inset-y-0 right-0 max-w-full flex pl-0 sm:pl-10">
            <div className="w-screen max-w-2xl bg-white shadow-2xl border-l border-slate-200 flex flex-col">
              {/* Drawer Header */}
              <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50 shrink-0">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-800 flex items-center justify-center font-bold text-base border border-amber-500/20 shrink-0">
                    {selectedCustomerData.customer.fullName.charAt(0)}
                  </div>
                  <div className="min-w-0">
                    <h2 className="text-base font-bold text-slate-900 truncate">{selectedCustomerData.customer.fullName}</h2>
                    <p className="text-xs text-slate-500 font-mono truncate">
                      ID: {selectedCustomerData.customer.customerId} • Joined {selectedCustomerData.customer.joiningDate}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1 sm:gap-2 shrink-0">
                  <button
                    onClick={() => handleOpenEdit(selectedCustomerData.customer)}
                    className="p-2 min-h-[40px] min-w-[40px] flex items-center justify-center text-slate-600 hover:text-slate-900 hover:bg-slate-200/60 rounded-lg"
                    title="Edit profile"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setSelectedCustomerId(null)}
                    className="p-2 min-h-[40px] min-w-[40px] flex items-center justify-center text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 rounded-lg"
                    aria-label="Close"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Drawer Content */}
              <div className="flex-1 overflow-y-auto p-5 space-y-6 text-xs">
                {/* Profile Meta Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200/80">
                  <div>
                    <span className="text-slate-400 text-[10px] uppercase tracking-wider font-semibold block">Contact Info</span>
                    <p className="text-slate-900 font-medium mt-1 font-mono">{selectedCustomerData.customer.mobileNumber}</p>
                    {selectedCustomerData.customer.email && (
                      <p className="text-slate-600 break-all">{selectedCustomerData.customer.email}</p>
                    )}
                    <p className="text-slate-500 mt-1">{selectedCustomerData.customer.address}, {selectedCustomerData.customer.city} - {selectedCustomerData.customer.pincode}</p>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px] uppercase tracking-wider font-semibold block">KYC & Nominee</span>
                    <p className="text-slate-900 font-medium mt-1 font-mono">
                      {selectedCustomerData.customer.idProofType}: {selectedCustomerData.customer.idProofNumber}
                    </p>
                    <p className="text-slate-700 mt-1 font-medium">
                      Nominee: {selectedCustomerData.customer.nomineeName} ({selectedCustomerData.customer.nomineeRelationship})
                    </p>
                    <p className="text-slate-500 font-mono">Ph: {selectedCustomerData.customer.nomineeMobile}</p>
                  </div>
                </div>

                {/* Enrolled Chit Groups Section */}
                <div>
                  <div className="flex items-center justify-between mb-3 gap-2">
                    <div className="flex items-center gap-1.5 text-slate-900 font-bold text-sm">
                      <Ticket className="w-4 h-4 text-amber-700 shrink-0" />
                      <span>Enrolled Chit Memberships ({selectedCustomerData.memberships.length})</span>
                    </div>
                    <button
                      onClick={handleOpenEnrollModal}
                      className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-semibold bg-amber-600 hover:bg-amber-700 text-white rounded-lg transition shrink-0 min-h-[36px]"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Enroll in Group</span>
                    </button>
                  </div>

                  {selectedCustomerData.memberships.length === 0 ? (
                    <div className="text-center py-6 bg-slate-50 rounded-xl border border-slate-200 text-slate-400">
                      No active chit memberships for this customer.
                    </div>
                  ) : (
                    <div className="space-y-2.5">
                      {selectedCustomerData.memberships.map((m) => (
                        <div
                          key={m.membershipId}
                          className="p-3.5 bg-white border border-slate-200 rounded-xl shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-2.5"
                        >
                          <div>
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="font-bold text-slate-900 text-xs">{m.groupName}</span>
                              <span className="bg-amber-100 text-amber-900 text-[10px] font-mono font-bold px-1.5 py-0.2 rounded">
                                Ticket #{m.ticketNumber}
                              </span>
                              {m.isPrized && (
                                <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-1.5 py-0.2 rounded">
                                  Prized (Month #{m.prizedAuctionNumber})
                                </span>
                              )}
                            </div>
                            <div className="flex flex-wrap items-center gap-2 sm:gap-4 text-slate-500 text-[11px] mt-1 font-mono">
                              <span>Chit Value: ₹{m.chitValue?.toLocaleString()}</span>
                              <span className="hidden sm:inline">•</span>
                              <span>Total Paid: ₹{m.totalPaid?.toLocaleString()}</span>
                              <span className="hidden sm:inline">•</span>
                              <span className="text-amber-800">Pending: ₹{m.totalPending?.toLocaleString()}</span>
                            </div>
                          </div>
                          <button
                            onClick={() => onNavigateToGroup(m.groupId)}
                            className="text-xs text-amber-700 hover:underline font-semibold self-end sm:self-auto"
                          >
                            View Group →
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Customer Payment History Table */}
                <div>
                  <div className="flex items-center gap-1.5 text-slate-900 font-bold text-sm mb-3">
                    <Receipt className="w-4 h-4 text-emerald-700" />
                    <span>Payment Receipts Ledger</span>
                  </div>

                  {selectedCustomerData.payments.length === 0 ? (
                    <div className="text-center py-6 bg-slate-50 rounded-xl border border-slate-200 text-slate-400">
                      No payments recorded yet for this customer.
                    </div>
                  ) : (
                    <div className="border border-slate-200 rounded-xl overflow-hidden">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
                          <tr>
                            <th className="py-2.5 px-3">Receipt #</th>
                            <th className="py-2.5 px-3">Date</th>
                            <th className="py-2.5 px-3">Group & Ticket</th>
                            <th className="py-2.5 px-3 text-right">Amount</th>
                            <th className="py-2.5 px-3">Mode</th>
                            <th className="py-2.5 px-3 text-center">Receipt</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {selectedCustomerData.payments.map((p) => (
                            <tr key={p.id || p.receiptNumber} className="hover:bg-slate-50/80">
                              <td className="py-2.5 px-3 font-mono font-medium text-slate-900">{p.receiptNumber}</td>
                              <td className="py-2.5 px-3 text-slate-600">{p.paymentDate}</td>
                              <td className="py-2.5 px-3 text-slate-700">{p.groupName} (T#{p.ticketNumber})</td>
                              <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900">
                                ₹{p.amountPaid.toLocaleString()}
                              </td>
                              <td className="py-2.5 px-3 text-slate-600">{p.paymentMode}</td>
                              <td className="py-2.5 px-3 text-center">
                                <button
                                  onClick={() => handleViewReceipt(p.receiptNumber)}
                                  className="text-emerald-700 hover:text-emerald-800 font-semibold text-xs"
                                >
                                  View
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ADD / EDIT CUSTOMER MODAL */}
      {showFormModal && (
        <div id="customer-form-backdrop" className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
          <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-200 my-auto max-h-[92vh] flex flex-col">
            <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50 shrink-0">
              <h3 className="font-bold text-slate-900 text-sm sm:text-base">
                {editingCustomer ? 'Edit Customer KYC Details' : 'Register New Chit Subscriber'}
              </h3>
              <button
                onClick={() => setShowFormModal(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200/50"
                aria-label="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveCustomer} className="p-4 sm:p-6 space-y-4 text-xs overflow-y-auto flex-1">
              {formError && (
                <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs">
                  {formError}
                </div>
              )}

              {/* Personal Info */}
              <div className="font-semibold text-slate-900 border-b border-slate-100 pb-1 text-xs uppercase tracking-wider">
                Personal Information
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-medium mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    value={formData.fullName || ''}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs focus:ring-1 focus:ring-amber-500"
                    placeholder="e.g. Anand Kumar"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-medium mb-1">Mobile Number *</label>
                  <input
                    type="tel"
                    required
                    value={formData.mobileNumber || ''}
                    onChange={(e) => setFormData({ ...formData, mobileNumber: e.target.value })}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-mono focus:ring-1 focus:ring-amber-500"
                    placeholder="e.g. 9876543210"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-medium mb-1">Alternate Contact</label>
                  <input
                    type="tel"
                    value={formData.alternateMobile || ''}
                    onChange={(e) => setFormData({ ...formData, alternateMobile: e.target.value })}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-mono focus:ring-1 focus:ring-amber-500"
                    placeholder="Optional"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-medium mb-1">Email Address</label>
                  <input
                    type="email"
                    value={formData.email || ''}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs focus:ring-1 focus:ring-amber-500"
                    placeholder="subscriber@example.com"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-medium mb-1">Gender</label>
                  <select
                    value={formData.gender || 'Male'}
                    onChange={(e) => setFormData({ ...formData, gender: e.target.value as any })}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs bg-white"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-700 font-medium mb-1">Date of Birth</label>
                  <input
                    type="date"
                    value={formData.dob || ''}
                    onChange={(e) => setFormData({ ...formData, dob: e.target.value })}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs"
                  />
                </div>
              </div>

              {/* Address */}
              <div className="font-semibold text-slate-900 border-b border-slate-100 pb-1 pt-2 text-xs uppercase tracking-wider">
                Address Details
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-3">
                  <label className="block text-slate-700 font-medium mb-1">Street Address *</label>
                  <input
                    type="text"
                    required
                    value={formData.address || ''}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs focus:ring-1 focus:ring-amber-500"
                    placeholder="e.g. #45, 2nd Cross, Indira Nagar"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-medium mb-1">City *</label>
                  <input
                    type="text"
                    required
                    value={formData.city || ''}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs"
                    placeholder="e.g. Bangalore"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-medium mb-1">Pincode *</label>
                  <input
                    type="text"
                    required
                    value={formData.pincode || ''}
                    onChange={(e) => setFormData({ ...formData, pincode: e.target.value })}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-mono"
                    placeholder="e.g. 560038"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-medium mb-1">Status</label>
                  <select
                    value={formData.status || 'active'}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs bg-white font-mono"
                  >
                    <option value="active">active</option>
                    <option value="inactive">inactive</option>
                  </select>
                </div>
              </div>

              {/* KYC & Nominee */}
              <div className="font-semibold text-slate-900 border-b border-slate-100 pb-1 pt-2 text-xs uppercase tracking-wider">
                KYC Identity & Nominee
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-medium mb-1">ID Proof Type *</label>
                  <select
                    value={formData.idProofType || 'Aadhaar'}
                    onChange={(e) => setFormData({ ...formData, idProofType: e.target.value as any })}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs bg-white"
                  >
                    <option value="Aadhaar">Aadhaar Card</option>
                    <option value="PAN">PAN Card</option>
                    <option value="Voter ID">Voter ID</option>
                    <option value="Passport">Passport</option>
                    <option value="Driving License">Driving License</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-700 font-medium mb-1">ID Proof Number *</label>
                  <input
                    type="text"
                    required
                    value={formData.idProofNumber || ''}
                    onChange={(e) => setFormData({ ...formData, idProofNumber: e.target.value })}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-mono"
                    placeholder="e.g. 4589 1234 9876"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-medium mb-1">Nominee Name *</label>
                  <input
                    type="text"
                    required
                    value={formData.nomineeName || ''}
                    onChange={(e) => setFormData({ ...formData, nomineeName: e.target.value })}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs"
                    placeholder="e.g. Sunita Kumar"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-medium mb-1">Nominee Relationship *</label>
                  <select
                    value={formData.nomineeRelationship || 'Spouse'}
                    onChange={(e) => setFormData({ ...formData, nomineeRelationship: e.target.value })}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs bg-white"
                  >
                    <option value="Spouse">Spouse</option>
                    <option value="Father">Father</option>
                    <option value="Mother">Mother</option>
                    <option value="Son">Son</option>
                    <option value="Daughter">Daughter</option>
                    <option value="Brother">Brother</option>
                    <option value="Sister">Sister</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowFormModal(false)}
                  className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={formSubmitting}
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-bold shadow-xs flex items-center gap-1.5"
                >
                  {formSubmitting && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  <span>{editingCustomer ? 'Save Changes' : 'Register Customer'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ENROLL CUSTOMER IN CHIT GROUP MODAL */}
      {showEnrollModal && (
        <div id="enroll-modal-backdrop" className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-3 sm:p-4 overflow-y-auto">
          <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-200 my-auto max-h-[92vh] flex flex-col">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between bg-slate-50 shrink-0">
              <h3 className="font-bold text-slate-900 text-sm">Enroll Subscriber in Chit Group</h3>
              <button
                onClick={() => setShowEnrollModal(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200/50"
                aria-label="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleEnrollSubmit} className="p-4 sm:p-5 space-y-4 text-xs overflow-y-auto flex-1">
              {enrollError && (
                <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs">
                  {enrollError}
                </div>
              )}

              <div>
                <label className="block text-slate-700 font-medium mb-1">Select Chit Group *</label>
                <select
                  required
                  value={enrollGroupId}
                  onChange={(e) => setEnrollGroupId(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs bg-white"
                >
                  {availableGroups.map((g) => (
                    <option key={g.groupId} value={g.groupId}>
                      {g.groupName} ({g.groupId}) • ₹{g.chitValue.toLocaleString()} ({g.currentMembersCount}/{g.numMembers})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">Ticket Number (Optional)</label>
                <input
                  type="number"
                  min="1"
                  max="100"
                  value={enrollTicketNumber}
                  onChange={(e) => setEnrollTicketNumber(e.target.value)}
                  placeholder="Leave empty to auto-assign next available"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono"
                />
                <p className="text-[10px] text-slate-400 mt-1">If left blank, system assigns the next free ticket.</p>
              </div>

              <div className="p-3 bg-amber-50/60 border border-amber-200/60 rounded-lg">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={allowDuplicate}
                    onChange={(e) => setAllowDuplicate(e.target.checked)}
                    className="w-4 h-4 text-amber-600 rounded border-slate-300"
                  />
                  <span className="text-slate-700 font-medium text-xs">Allow multiple tickets in this same chit group</span>
                </label>
                <p className="text-[10px] text-slate-500 mt-1 pl-6">
                  Check this if the subscriber wants to hold more than 1 ticket in this group.
                </p>
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowEnrollModal(false)}
                  className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={enrollSubmitting}
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-bold shadow-xs flex items-center gap-1.5"
                >
                  {enrollSubmitting && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  <span>Confirm Enrollment</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
