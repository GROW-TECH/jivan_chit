<?php
// ============================================================
// USERS MANAGEMENT API
// ============================================================
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/helpers.php';

setCorsHeaders();
$pdo    = Database::getInstance();
$method = getMethod();
$id     = $_GET['id'] ?? null;

switch ($method) {
    case 'GET':
        if ($id) {
            $stmt = $pdo->prepare("SELECT id, username, full_name, email, role, status, last_login, created_at, updated_at FROM users WHERE id = ?");
            $stmt->execute([$id]);
            $u = $stmt->fetch();
            if (!$u) jsonResponse(false, 'User not found', null, 404);
            jsonResponse(true, '', ['user' => mapUser($u)]);
        }
        $stmt = $pdo->query("SELECT id, username, full_name, email, role, status, last_login, created_at, updated_at FROM users ORDER BY created_at DESC");
        jsonResponse(true, '', ['users' => array_map('mapUser', $stmt->fetchAll())]);
        break;

    case 'POST':
        $b = getRequestBody();
        if (empty($b['username']) || empty($b['password']) || empty($b['fullName']) || empty($b['email'])) {
            jsonResponse(false, 'username, password, fullName, email are required', null, 400);
        }
        $hash = password_hash($b['password'], PASSWORD_DEFAULT);
        $pdo->prepare("
            INSERT INTO users (username, password_hash, full_name, email, role, status)
            VALUES (?,?,?,?,?,?)
        ")->execute([
            $b['username'], $hash, $b['fullName'], $b['email'],
            $b['role'] ?? 'staff', $b['status'] ?? 'active'
        ]);
        $lid  = $pdo->lastInsertId();
        $stmt = $pdo->prepare("SELECT id, username, full_name, email, role, status, last_login, created_at, updated_at FROM users WHERE id=?");
        $stmt->execute([$lid]);
        jsonResponse(true, 'User created', ['user' => mapUser($stmt->fetch())], 201);
        break;

    case 'PUT':
        if (!$id) jsonResponse(false, 'User ID required', null, 400);
        $b   = getRequestBody();
        $sql = "UPDATE users SET full_name=?, email=?, role=?, status=?";
        $params = [$b['fullName'], $b['email'], $b['role'] ?? 'staff', $b['status'] ?? 'active'];
        if (!empty($b['password'])) {
            $sql .= ", password_hash=?";
            $params[] = password_hash($b['password'], PASSWORD_DEFAULT);
        }
        $sql .= " WHERE id=?";
        $params[] = $id;
        $pdo->prepare($sql)->execute($params);
        $stmt = $pdo->prepare("SELECT id, username, full_name, email, role, status, last_login, created_at, updated_at FROM users WHERE id=?");
        $stmt->execute([$id]);
        jsonResponse(true, 'User updated', ['user' => mapUser($stmt->fetch())]);
        break;

    case 'DELETE':
        if (!$id) jsonResponse(false, 'User ID required', null, 400);
        $pdo->prepare("UPDATE users SET status='inactive' WHERE id=?")->execute([$id]);
        jsonResponse(true, 'User deactivated');
        break;

    default:
        jsonResponse(false, 'Method not allowed', null, 405);
}

function mapUser(array $r): array {
    return [
        'id'        => (int)$r['id'],
        'username'  => $r['username'],
        'fullName'  => $r['full_name'],
        'email'     => $r['email'],
        'role'      => $r['role'],
        'status'    => $r['status'],
        'lastLogin' => $r['last_login'],
        'createdAt' => $r['created_at'],
        'updatedAt' => $r['updated_at'],
    ];
}
