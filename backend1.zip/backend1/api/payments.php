<?php
// ============================================================
// PAYMENTS API - Full CRUD
// ============================================================
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/helpers.php';

setCorsHeaders();
$pdo    = Database::getInstance();
$method = getMethod();
$id     = $_GET['id'] ?? null;

switch ($method) {
    case 'GET':
        if ($id) {
            $stmt = $pdo->prepare("
                SELECT p.*, c.full_name AS customer_name, cg.group_name,
                       u.full_name AS collected_by_name
                FROM payments p
                LEFT JOIN customers c ON p.customer_id = c.customer_id
                LEFT JOIN chit_groups cg ON p.group_id = cg.group_id
                LEFT JOIN users u ON p.collected_by_user_id = u.id
                WHERE p.receipt_number = ?
            ");
            $stmt->execute([$id]);
            $p = $stmt->fetch();
            if (!$p) jsonResponse(false, 'Payment not found', null, 404);
            jsonResponse(true, '', ['payment' => mapPayment($p)]);
        }

        $sql  = "
            SELECT p.*, c.full_name AS customer_name, cg.group_name,
                   u.full_name AS collected_by_name
            FROM payments p
            LEFT JOIN customers c ON p.customer_id = c.customer_id
            LEFT JOIN chit_groups cg ON p.group_id = cg.group_id
            LEFT JOIN users u ON p.collected_by_user_id = u.id
            WHERE 1=1
        ";
        $params = [];
        if (!empty($_GET['customerId'])) {
            $sql .= " AND p.customer_id = ?";
            $params[] = $_GET['customerId'];
        }
        if (!empty($_GET['groupId'])) {
            $sql .= " AND p.group_id = ?";
            $params[] = $_GET['groupId'];
        }
        $sql .= " ORDER BY p.payment_date DESC, p.created_at DESC";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        jsonResponse(true, '', ['payments' => array_map('mapPayment', $stmt->fetchAll())]);
        break;

    case 'POST':
        $b = getRequestBody();
        // Generate receipt number
        $stmt  = $pdo->query("SELECT COUNT(*) FROM payments");
        $count = (int)$stmt->fetchColumn() + 1;
        $rec   = 'REC' . date('Ymd') . str_pad($count, 4, '0', STR_PAD_LEFT);

        $pdo->prepare("
            INSERT INTO payments
              (receipt_number, installment_id, membership_id, customer_id, group_id,
               amount_paid, previous_balance, remaining_balance, payment_mode,
               transaction_reference, payment_date, collected_by_user_id, status, remarks)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        ")->execute([
            $rec, $b['installmentId'], $b['membershipId'], $b['customerId'], $b['groupId'],
            $b['amountPaid'], $b['previousBalance'] ?? 0, $b['remainingBalance'] ?? 0,
            $b['paymentMode'] ?? 'Cash', $b['transactionReference'] ?? null,
            $b['paymentDate'], $b['collectedByUserId'] ?? 1,
            $b['status'] ?? 'active', $b['remarks'] ?? null
        ]);

        $stmt = $pdo->prepare("
            SELECT p.*, c.full_name AS customer_name, cg.group_name, u.full_name AS collected_by_name
            FROM payments p
            LEFT JOIN customers c ON p.customer_id = c.customer_id
            LEFT JOIN chit_groups cg ON p.group_id = cg.group_id
            LEFT JOIN users u ON p.collected_by_user_id = u.id
            WHERE p.receipt_number = ?
        ");
        $stmt->execute([$rec]);
        jsonResponse(true, 'Payment recorded', ['payment' => mapPayment($stmt->fetch())], 201);
        break;

    case 'PUT':
        if (!$id) jsonResponse(false, 'Receipt number required', null, 400);
        $b = getRequestBody();
        $pdo->prepare("
            UPDATE payments SET status=?, reversal_reason=?, remarks=? WHERE receipt_number=?
        ")->execute([$b['status'] ?? 'active', $b['reversalReason'] ?? null, $b['remarks'] ?? null, $id]);
        jsonResponse(true, 'Payment updated');
        break;

    default:
        jsonResponse(false, 'Method not allowed', null, 405);
}

function mapPayment(array $r): array {
    return [
        'id'                   => (int)$r['id'],
        'receiptNumber'        => $r['receipt_number'],
        'installmentId'        => $r['installment_id'],
        'membershipId'         => $r['membership_id'],
        'customerId'           => $r['customer_id'],
        'customerName'         => $r['customer_name'] ?? null,
        'groupId'              => $r['group_id'],
        'groupName'            => $r['group_name'] ?? null,
        'amountPaid'           => (float)$r['amount_paid'],
        'previousBalance'      => (float)$r['previous_balance'],
        'remainingBalance'     => (float)$r['remaining_balance'],
        'paymentMode'          => $r['payment_mode'],
        'transactionReference' => $r['transaction_reference'],
        'paymentDate'          => $r['payment_date'],
        'collectedByUserId'    => (int)$r['collected_by_user_id'],
        'collectedByName'      => $r['collected_by_name'] ?? null,
        'status'               => $r['status'],
        'reversalReason'       => $r['reversal_reason'],
        'remarks'              => $r['remarks'],
        'createdAt'            => $r['created_at'],
        'updatedAt'            => $r['updated_at'],
    ];
}
